﻿
namespace WinFormsApp1
{
    partial class Requisites
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.ChsBtn = new System.Windows.Forms.Button();
            this.DelBtn = new System.Windows.Forms.Button();
            this.EdBtn = new System.Windows.Forms.Button();
            this.NewBtn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.RequisitesGridView = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.RequisitesGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.ChsBtn);
            this.panel1.Controls.Add(this.DelBtn);
            this.panel1.Controls.Add(this.EdBtn);
            this.panel1.Controls.Add(this.NewBtn);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 387);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 63);
            this.panel1.TabIndex = 0;
            // 
            // ChsBtn
            // 
            this.ChsBtn.Location = new System.Drawing.Point(703, 20);
            this.ChsBtn.Name = "ChsBtn";
            this.ChsBtn.Size = new System.Drawing.Size(85, 23);
            this.ChsBtn.TabIndex = 3;
            this.ChsBtn.Text = "Выбрать";
            this.ChsBtn.UseVisualStyleBackColor = true;
            // 
            // DelBtn
            // 
            this.DelBtn.Location = new System.Drawing.Point(214, 20);
            this.DelBtn.Name = "DelBtn";
            this.DelBtn.Size = new System.Drawing.Size(87, 23);
            this.DelBtn.TabIndex = 2;
            this.DelBtn.Text = "Удалить";
            this.DelBtn.UseVisualStyleBackColor = true;
            this.DelBtn.Click += new System.EventHandler(this.DelBtn_Click);
            // 
            // EdBtn
            // 
            this.EdBtn.Location = new System.Drawing.Point(107, 20);
            this.EdBtn.Name = "EdBtn";
            this.EdBtn.Size = new System.Drawing.Size(101, 23);
            this.EdBtn.TabIndex = 1;
            this.EdBtn.Text = "Изменить";
            this.EdBtn.UseVisualStyleBackColor = true;
            this.EdBtn.Click += new System.EventHandler(this.EdBtn_Click);
            // 
            // NewBtn
            // 
            this.NewBtn.Location = new System.Drawing.Point(14, 20);
            this.NewBtn.Name = "NewBtn";
            this.NewBtn.Size = new System.Drawing.Size(87, 23);
            this.NewBtn.TabIndex = 0;
            this.NewBtn.Text = "Добавить";
            this.NewBtn.UseVisualStyleBackColor = true;
            this.NewBtn.Click += new System.EventHandler(this.NewBtn_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.RequisitesGridView);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(800, 387);
            this.panel2.TabIndex = 1;
            // 
            // RequisitesGridView
            // 
            this.RequisitesGridView.AllowUserToAddRows = false;
            this.RequisitesGridView.AllowUserToDeleteRows = false;
            this.RequisitesGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.RequisitesGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RequisitesGridView.Location = new System.Drawing.Point(0, 0);
            this.RequisitesGridView.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.RequisitesGridView.MultiSelect = false;
            this.RequisitesGridView.Name = "RequisitesGridView";
            this.RequisitesGridView.ReadOnly = true;
            this.RequisitesGridView.RowHeadersWidth = 51;
            this.RequisitesGridView.RowTemplate.Height = 29;
            this.RequisitesGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.RequisitesGridView.Size = new System.Drawing.Size(800, 387);
            this.RequisitesGridView.TabIndex = 1;
            // 
            // Requisites
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Requisites";
            this.Text = "Реквизиты";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.RequisitesGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView RequisitesGridView;
        private System.Windows.Forms.Button DelBtn;
        private System.Windows.Forms.Button EdBtn;
        private System.Windows.Forms.Button NewBtn;
        private System.Windows.Forms.Button ChsBtn;
    }
}