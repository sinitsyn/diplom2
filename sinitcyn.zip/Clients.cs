﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WinFormsApp1
{
    public partial class Clients : Form
    {
        private int op;
        private SqlConnection sqlConnection = null;
        private SqlDataAdapter SqlDataAdapter = null;
        private SqlCommandBuilder SqlCommandBuilder = null;

        string filter;
        Boolean f_active = false;
        public int client_id=-1;
        public string client_name = "";
        DataSet dataSet;

        public Clients(int cmd)
        {
            op = cmd;
            InitializeComponent();
            dataSet = CreateDataSet();
            ClientsGridView.DataSource = dataSet.Tables["dbo.Clients"];
            Set_ColumnHeader();
            //LoadData();
        }

        private DataSet CreateDataSet(string newSql = "")
        {
            string connectionString = main.connectionString;
            using (SqlConnection conn = new
                   SqlConnection(connectionString))
            {
                conn.Close();

                conn.Open();
                //MessageBox.Show("Успешное подключение !");
                using (SqlCommand cmd = new SqlCommand("SELECT C.*, T.NAME as TOWN_NAME FROM dbo.Clients C "+
                                                        "INNER JOIN TOWNS T on T.ID = C.TownsID "+
                                                        "WHERE C.ID = C.ID " + newSql, conn))
                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    // Объекты‐адаптеры умеют взаимодействовать  
                    // с конкретными серверами баз данных  
                    adapter.TableMappings.Add("Table", "dbo.Clients");
                    adapter.SelectCommand = cmd;
                    DataSet dataSet = new DataSet("dbo.Clients");
                    // Поместить все строки в набор данных  
                    adapter.Fill(dataSet);
                    return dataSet;
                }

            }
        }

        private void Set_ColumnHeader()
        {
            //обзываем
            ClientsGridView.Columns["FName"].DisplayIndex = 0;
            ClientsGridView.Columns["FName"].HeaderText = "Название";
            ClientsGridView.Columns["Address"].DisplayIndex = 1;
            ClientsGridView.Columns["Address"].HeaderText = "Адрес";
            //ClientsGridView.Columns["Person"].DisplayIndex = 2;
            //ClientsGridView.Columns["Person"].HeaderText = "Ч/Л";
            //if (ClientsGridView.Columns["Person"].Visible == true) ClientsGridView.Columns["Person"].Visible = false;
            ClientsGridView.Columns["Phone"].DisplayIndex = 3;
            ClientsGridView.Columns["Phone"].HeaderText = "Телефон";
            ClientsGridView.Columns["TOWN_NAME"].DisplayIndex = 4;
            ClientsGridView.Columns["TOWN_NAME"].HeaderText = "Город";


            //ClientsGridView.Columns["ID"].DisplayIndex = ClientsGridView.Columns.Count - 1;
            //ClientsGridView.Columns["ID"].Visible = false;
            if (ClientsGridView.Columns["ID"].Visible == true) ClientsGridView.Columns["ID"].Visible = false;
            if (ClientsGridView.Columns["TOWNSID"].Visible == true) ClientsGridView.Columns["TOWNSID"].Visible = false;
            //ClientsGridView.Columns["City"].DisplayIndex = ClientsGridView.Columns.Count - 1;
            //if (ClientsGridView.Columns["City"].Visible == true) ClientsGridView.Columns["City"].Visible = false;
        }

        

        private void New_btn_Click(object sender, EventArgs e)
        {
            int row = ClientsGridView.RowCount;
            Clients_edit ce = new Clients_edit (1, 0, "", "", "", 0);

            ce.ShowDialog();
            GridR(0);
            Set_ColumnHeader();
            //ClientsGridView.CurrentCell = ClientsGridView.Rows[row+1].Cells[1];
        }

        private void edit_btn_Click(object sender, EventArgs e)
        {
            ClientsGridView.Focus();
            int row = ClientsGridView.CurrentRow.Index;
            int ID = Convert.ToInt32(dataSet.Tables[0].Rows[row]["ID"].ToString());
            //string FNameVal = ClientsGridView.CurrentRow.Cells["FName"].Value.ToString();
            //string FNameVal = Convert.ToString(dataSet.Tables[0].Rows[ClientsGridView.CurrentRow.Index]["FName"].ToString());
            string FNameVal = Convert.ToString(dataSet.Tables[0].Rows[row]["FName"].ToString());
            //string AddressVal = ClientsGridView.CurrentRow.Cells["Address"].Value.ToString();
            string AddressVal = dataSet.Tables[0].Rows[ClientsGridView.CurrentRow.Index]["Address"].ToString();
            //string PhoneVal = ClientsGridView.CurrentRow.Cells["Phone"].Value.ToString();
            string PhoneVal = dataSet.Tables[0].Rows[ClientsGridView.CurrentRow.Index]["Phone"].ToString();
            int Towns_ID = Convert.ToInt32(dataSet.Tables[0].Rows[row]["TownsID"].ToString());
            //int PersonVal = Convert.ToInt32(ClientsGridView.CurrentRow.Cells["Person"].Value.ToString()); ;
            // int PersonVal = Convert.ToInt32(dataSet.Tables[0].Rows[ClientsGridView.CurrentRow.Index]["Person"].ToString());
            Clients_edit ce = new Clients_edit(2, ID, FNameVal, AddressVal, PhoneVal, Towns_ID);
            ce.ShowDialog();
            GridR(1);
            Set_ColumnHeader();
            ClientsGridView.CurrentCell = ClientsGridView.Rows[row].Cells[2];
        }

        private void Del_btn_Click(object sender, EventArgs e)
        {
            int row = ClientsGridView.CurrentRow.Index;
            //int ID = Convert.ToInt32( ClientsGridView.CurrentRow.Cells["ID"].Value.ToString());
            int ID = Convert.ToInt32(dataSet.Tables[0].Rows[row]["ID"].ToString());
            string connectionString = main.connectionString;
            using (SqlConnection conn = new
                   SqlConnection(connectionString))
            {
                conn.Close();

                conn.Open();
                //MessageBox.Show("Успешное подключение !");
                using (SqlCommand cmd = new SqlCommand("DELETE FROM dbo.Clients where ID=@ID", conn))
                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {

                    cmd.Parameters.Add(new SqlParameter("@ID", ID));
                    // Здесь используется метод ExecuteNonQuery(), потому  
                    // что мы не выдаем запрос на чтение строк во время  
                    // вставки 
                    int rowsAffected = cmd.ExecuteNonQuery();
                    MessageBox.Show(rowsAffected.ToString() + " rows affected by delete");
                }
                

            }
            //   goods_editF ge = new goods_editF(3, ID);
            //   ge.ShowDialog();
            GridR(2);
            Set_ColumnHeader();
            if (row-1>1) ClientsGridView.CurrentCell = ClientsGridView.Rows[row-1].Cells[2];
        }

        private void GridR(int op)
        {
          ///  int row = ClientsGridView.CurrentRow.Index;
            string w = "";
            ClientsGridView.DataSource = null;
            /*if (fname != null && fname != "") w = w + " AND FNAME='" + fname + "' ";
            if (price1 > 0) w = w + " AND Price>" + price1;
            if (price2 > 0) w = w + " AND Price<" + price2;
            if (priceOut1 > 0) w = w + " AND PriceOut>" + PriceOut1Val.ToString();
            if (priceOut2 > 0) w = w + " AND PriceOut<" + PriceOut2Val.ToString();
            if (vat! > 0) w = w + " AND VAT=" + VATVal.ToString();


            // dataSet = CreateDataSet("WHERE FNAME='"+FNameVal+"'"); //установка фильтра*/
            dataSet = CreateDataSet(" " + w); //установка фильтра
            ClientsGridView.DataSource = dataSet.Tables["dbo.Clients"];
            //  GoodsDataGridView.CurrentCell= GoodsDataGridView.Rows[GoodsDataGridView.RowCount-1].Cells[0];
            /*if (op == 0)
                ClientsGridView.CurrentCell = ClientsGridView.Rows[ClientsGridView.RowCount-1].Cells[0]; //добавление
            if (op==1)
                ClientsGridView.CurrentCell = ClientsGridView.Rows[row].Cells[0];
            if (op == 2)
                ClientsGridView.CurrentCell = ClientsGridView.Rows[row -1].Cells[0];*/
            Set_ColumnHeader();
        }

        private void ChooseBtn_Click(object sender, EventArgs e)
        {
            ClientsGridView.Focus();
            client_id =Convert.ToInt32(dataSet.Tables[0].Rows[ClientsGridView.CurrentRow.Index]["ID"].ToString());
            //client_id = Convert.ToInt32(ClientsGridView.CurrentRow.Cells["ID"].Value.ToString());
            //client_name = ClientsGridView.CurrentRow.Cells["FName"].Value.ToString();
            client_name = dataSet.Tables[0].Rows[ClientsGridView.CurrentRow.Index]["FName"].ToString();
            if (op>0) this.Close();
        }
    }
    
}
