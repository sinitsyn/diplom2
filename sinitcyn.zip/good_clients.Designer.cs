﻿
namespace WinFormsApp1
{
    partial class GoodClientsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title1 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.GoodLab = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.PrnBtn = new System.Windows.Forms.Button();
            this.BuildBtn = new System.Windows.Forms.Button();
            this.GoodsMoveDataGridView = new System.Windows.Forms.DataGridView();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GoodsMoveDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // GoodLab
            // 
            this.GoodLab.AutoSize = true;
            this.GoodLab.Location = new System.Drawing.Point(232, 25);
            this.GoodLab.Name = "GoodLab";
            this.GoodLab.Size = new System.Drawing.Size(20, 17);
            this.GoodLab.TabIndex = 13;
            this.GoodLab.Text = "...";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(197, 16);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(29, 29);
            this.button1.TabIndex = 12;
            this.button1.Text = "...";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(144, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 17);
            this.label1.TabIndex = 11;
            this.label1.Text = "Товар";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.GoodLab);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.PrnBtn);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.BuildBtn);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 516);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1318, 69);
            this.panel1.TabIndex = 14;
            // 
            // PrnBtn
            // 
            this.PrnBtn.Location = new System.Drawing.Point(1212, 20);
            this.PrnBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PrnBtn.Name = "PrnBtn";
            this.PrnBtn.Size = new System.Drawing.Size(94, 23);
            this.PrnBtn.TabIndex = 6;
            this.PrnBtn.Text = "Печать";
            this.PrnBtn.UseVisualStyleBackColor = true;
            this.PrnBtn.Click += new System.EventHandler(this.PrnBtn_Click);
            // 
            // BuildBtn
            // 
            this.BuildBtn.Location = new System.Drawing.Point(17, 22);
            this.BuildBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BuildBtn.Name = "BuildBtn";
            this.BuildBtn.Size = new System.Drawing.Size(94, 23);
            this.BuildBtn.TabIndex = 1;
            this.BuildBtn.Text = "Построить";
            this.BuildBtn.UseVisualStyleBackColor = true;
            this.BuildBtn.Click += new System.EventHandler(this.BuildBtn_Click);
            // 
            // GoodsMoveDataGridView
            // 
            this.GoodsMoveDataGridView.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.GoodsMoveDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GoodsMoveDataGridView.Location = new System.Drawing.Point(481, -4);
            this.GoodsMoveDataGridView.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GoodsMoveDataGridView.Name = "GoodsMoveDataGridView";
            this.GoodsMoveDataGridView.RowHeadersWidth = 51;
            this.GoodsMoveDataGridView.RowTemplate.Height = 29;
            this.GoodsMoveDataGridView.Size = new System.Drawing.Size(800, 516);
            this.GoodsMoveDataGridView.TabIndex = 17;
            this.GoodsMoveDataGridView.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.GoodsMoveDataGridView_DataBindingComplete);
            // 
            // chart1
            // 
            chartArea1.Area3DStyle.Enable3D = true;
            chartArea1.AxisY.IsLabelAutoFit = false;
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            this.chart1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chart1.Location = new System.Drawing.Point(0, 0);
            this.chart1.Name = "chart1";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Bar;
            series1.IsXValueIndexed = true;
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            series1.YValuesPerPoint = 2;
            this.chart1.Series.Add(series1);
            this.chart1.Size = new System.Drawing.Size(1318, 516);
            this.chart1.TabIndex = 18;
            this.chart1.Text = "chart1";
            title1.DockedToChartArea = "ChartArea1";
            title1.DockingOffset = -50;
            title1.IsDockedInsideChartArea = false;
            title1.Name = "Title1";
            title1.Text = "График";
            this.chart1.Titles.Add(title1);
            this.chart1.Visible = false;
            // 
            // GoodClientsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1318, 585);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.GoodsMoveDataGridView);
            this.Controls.Add(this.panel1);
            this.Name = "GoodClientsForm";
            this.Text = "диаграмма попупки товара";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GoodsMoveDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label GoodLab;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button PrnBtn;
        private System.Windows.Forms.Button BuildBtn;
        private System.Windows.Forms.DataGridView GoodsMoveDataGridView;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
    }
}