﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Clients_edit : Form
    {
        private SqlConnection sqlConnection = null;
        private SqlDataAdapter SqlDataAdapter = null;
        private SqlCommandBuilder SqlCommandBuilder = null;
        //операция
        private int op;
        private int id = -1;
        private string FName = "";
        private string Address = "";
        private string Phone = "";
        private int TownsID = -1;
        private string TownsName = "";

        //private int Person = 0;

        public Clients_edit(int op_cmd, int IdVal = -1, string FNameVal = "", string AddressVal = "", string PhoneVal="", int Towns_ID=-1)
        {
            op = op_cmd;
            id = IdVal;
            FName = FNameVal;
            Address = AddressVal;
            Phone = PhoneVal;
            TownsID = Towns_ID;
            //Person = PersonVal;
            InitializeComponent();
            string commandText = "SELECT * FROM dbo.TOWNS where ID=@Towns_ID;";

            using (SqlConnection connection = new SqlConnection(main.connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand(commandText, connection);

                command.Parameters.Add("@Towns_ID", SqlDbType.VarChar);
                command.Parameters["@Towns_ID"].Value = TownsID;

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        TownsName = reader.GetString(1); //Название города
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = main.connectionString;
            switch (op) //операция
            {
                case 1: //добавление новой записи
                    string commandText = "INSERT INTO dbo.Clients (FName,Address,Phone,TownsID) VALUES (@FName,@Address,@Phone,@TownsID);";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand command = new SqlCommand(commandText, connection);
                        command.Parameters.Add("@FNAME", SqlDbType.VarChar);
                        command.Parameters["@FNAME"].Value = FNameTBox.Text;

                        command.Parameters.Add("@Address", SqlDbType.VarChar);
                        command.Parameters["@Address"].Value = AddrressTB.Text;

                        command.Parameters.Add("@Phone", SqlDbType.VarChar);
                        command.Parameters["@Phone"].Value = PhoneTB.Text;

                        command.Parameters.Add("@TownsID", SqlDbType.VarChar);
                        command.Parameters["@TownsID"].Value = TownsID;

                        /*int p;
                        if (PersonCB.Checked == true)
                            p = 1;
                        else
                            p = 0;

                        command.Parameters.Add("@Person", SqlDbType.Int);
                        command.Parameters["@Person"].Value = p;*/

                        try
                        {
                            connection.Open();
                            Int32 rowsAffected = command.ExecuteNonQuery();
                            MessageBox.Show(rowsAffected.ToString() + " rows affected by insert");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }


                    break;
                case 2: //редактирование
                   
                    commandText = "UPDATE dbo.Clients set FName=@FName," +
                                "Address=@Address," +
                                "Phone=@Phone," +
                                "TOWNSID=@TOWNSID"+
                                " WHERE ID=@ID";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand command = new SqlCommand(commandText, connection);
                        command.Parameters.Add("@FNAME", SqlDbType.VarChar);
                        command.Parameters["@FNAME"].Value = FNameTBox.Text;

                        command.Parameters.Add("@Address", SqlDbType.VarChar);
                        command.Parameters["@Address"].Value = AddrressTB.Text;

                        command.Parameters.Add("@Phone", SqlDbType.VarChar);
                        command.Parameters["@Phone"].Value = PhoneTB.Text;

                        command.Parameters.Add("@TownsID", SqlDbType.VarChar);
                        command.Parameters["@TownsID"].Value = TownsID;

                        /*int p;
                        if (PersonCB.Checked == true)
                            p = 1;
                        else
                            p = 0;
                        
                        command.Parameters.Add("@Person", SqlDbType.Int);
                        command.Parameters["@Person"].Value = p;*/

                        command.Parameters.Add("@ID", SqlDbType.Int);
                        command.Parameters["@ID"].Value = id;

                        try
                        {
                            connection.Open();
                            Int32 rowsAffected = command.ExecuteNonQuery();
                            MessageBox.Show(rowsAffected.ToString() + " rows affected by update");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }

                    break;
                case 3: //удаление
                    
                    using (SqlConnection conn = new
                           SqlConnection(connectionString))
                    {

                        conn.Open();
                        using (SqlCommand cmd = new SqlCommand("DELETE FROM dbo.Clients" +
                            " WHERE ID=@ID", conn))
                        using (SqlDataAdapter adapter = new SqlDataAdapter())
                        {
                            try
                            {
                                cmd.Parameters.Add(new SqlParameter("@ID", id));
                                // Здесь используется метод ExecuteNonQuery(), потому  
                                // что мы не выдаем запрос на чтение строк во время  
                                // вставки 
                                int rowsAffected = cmd.ExecuteNonQuery();
                                MessageBox.Show(rowsAffected.ToString() + " rows affected to delete");
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }
                        }

                    }
                    break;

                default:
                    break;
            }

            this.Close();
            this.Dispose();
        }

        private void Clients_edit_Load(object sender, EventArgs e)
        {
            FNameTBox.Text = FName;
            AddrressTB.Text = Address;
            PhoneTB.Text = Phone;
            Towns_nameTB.Text = TownsName;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Dispose();
        }

        private void TownBtn_Click(object sender, EventArgs e)
        {
            Towns T = new Towns(1);
            T.ShowDialog();
            TownsID = T.TownsId;
            Towns_nameTB.Text = T.TownsName;
        }
    }
    
}
