﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class goods_editF : Form
    {
        private SqlConnection sqlConnection = null;
        private SqlDataAdapter SqlDataAdapter = null;
        private SqlCommandBuilder SqlCommandBuilder = null;
        //операция
        private int op;
        private int id = -1;
        private string FName = "";
        private double Price = 0;
        private double PriceOut = 0;
        private int VAT = 0;
        private int GRP_ID = 0;


        public goods_editF(int op_cmd,int Id=-1, string FNameVal = "",double PriceVal=0, double PriceOutVal =0, int VATVal=0, int grp_id=0)
        {
            op = op_cmd;
            id = Id;
            FName = FNameVal;
            Price = PriceVal;
            PriceOut = PriceOutVal;
            VAT = VATVal;
            GRP_ID = grp_id;
            InitializeComponent();
        }

        private void goods_edit_Load(object sender, EventArgs e) //установка переданных значений
        {
            FNameTBox.Text = FName;
            PriceTBox.Text = Convert.ToString(Price);
            PriceOutTBox.Text = Convert.ToString(PriceOut);
            VATTBox.Text = Convert.ToString(VAT);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Dispose();
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            string connectionString = main.connectionString;
            switch (op) //операция
            {
                case 1: //добавление новой записи
                 
                    using (SqlConnection conn = new
                           SqlConnection(connectionString))
                    {

                        conn.Open();
                        using (SqlCommand cmd = new SqlCommand("INSERT INTO dbo.Goods (FName,Price,Price_Out,VAT,Groups_ID) VALUES (@FName,@Price,@Price_Out,@VAT,@Groups_ID)", conn))
                        using (SqlDataAdapter adapter = new SqlDataAdapter())
                        {
                            cmd.Parameters.Add(new SqlParameter("@FName", FNameTBox.Text));
                            cmd.Parameters.Add(new SqlParameter("@Price", Convert.ToDouble(PriceTBox.Text)));
                            cmd.Parameters.Add(new SqlParameter("@Price_Out", Convert.ToDouble(PriceOutTBox.Text)));
                            cmd.Parameters.Add(new SqlParameter("@VAT", VATTBox.Text));
                            cmd.Parameters.Add(new SqlParameter("@Groups_ID", GRP_ID));
                            // Здесь используется метод ExecuteNonQuery(), потому  
                            // что мы не выдаем запрос на чтение строк во время  
                            // вставки 
                            int rowsAffected = cmd.ExecuteNonQuery();
                            MessageBox.Show(rowsAffected.ToString()+" rows affected by insert");
                        }

                    }
                    break;
                case 2: //редактирование
                  
                    using (SqlConnection conn = new
                           SqlConnection(connectionString))
                    {

                        conn.Open();
                        using (SqlCommand cmd = new SqlCommand("UPDATE dbo.Goods set FName=@FName," +
                            "                                                        Price=@Price," +
                            "                                                        Price_Out=@Price_Out," +
                            "                                                        VAT=@VAT" +
                            " WHERE ID=@ID", conn))
                        using (SqlDataAdapter adapter = new SqlDataAdapter())
                        {
                            cmd.Parameters.Add(new SqlParameter("@FName", FNameTBox.Text));
                            cmd.Parameters.Add(new SqlParameter("@Price", Convert.ToDouble(PriceTBox.Text)));
                            cmd.Parameters.Add(new SqlParameter("@Price_Out", Convert.ToDouble(PriceOutTBox.Text)));
                            cmd.Parameters.Add(new SqlParameter("@VAT", VATTBox.Text));
                            cmd.Parameters.Add(new SqlParameter("@ID", id));
                            // Здесь используется метод ExecuteNonQuery(), потому  
                            // что мы не выдаем запрос на чтение строк во время  
                            // вставки 
                            int rowsAffected = cmd.ExecuteNonQuery();
                            MessageBox.Show(rowsAffected.ToString() + " rows affected by update");
                        }

                    }
                    break;
                case 3: //удаление
                  
                    using (SqlConnection conn = new
                           SqlConnection(connectionString))
                    {

                        conn.Open();
                        using (SqlCommand cmd = new SqlCommand("DELETE FROM dbo.Goods" +
                            " WHERE ID=@ID", conn))
                        using (SqlDataAdapter adapter = new SqlDataAdapter())
                        {
                            cmd.Parameters.Add(new SqlParameter("@ID", id));
                            // Здесь используется метод ExecuteNonQuery(), потому  
                            // что мы не выдаем запрос на чтение строк во время  
                            // вставки 
                            int rowsAffected = cmd.ExecuteNonQuery();
                            MessageBox.Show(rowsAffected.ToString() + " rows affected to delete");
                        }

                    }
                    break;

                default:
                    break;
            }

            this.Close();
            this.Dispose();
        }
    }
}
