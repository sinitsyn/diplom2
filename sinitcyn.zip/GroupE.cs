﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class GroupE : Form
    {
        public int OP;
        public int P_G_ID;
        public string ParentName="";
        public int ID = 0;
        public string GName = "";
        public int Tables_ID;
        public string TName = "";



        public GroupE(int op_cmd, int tables_id, int p_g_id=0, int id = 0)
        {
            /*op_cmd
             * 1-вставка
             * 2-исправление
             p_g_id родитель?
             Tables_ID - таблица*/
            ID = id;
            OP = op_cmd;
            P_G_ID = p_g_id;
            Tables_ID = tables_id;
            
            using (SqlConnection conn = new
                           SqlConnection(main.connectionString))
            {

                conn.Open();
                /*имя таблицы для группы*/
                SqlCommand cmd = new SqlCommand("select T.Name from Tables T where T.ID = @tables_id", conn);
                SqlParameter idParam = new SqlParameter("@tables_id", tables_id);
                // добавляем параметр к команде
                cmd.Parameters.Add(idParam);
                
                //читаем название таблицы
                using (SqlDataReader reader = cmd.ExecuteReader())
                {

                    while (reader.Read())
                    {
                        TName = reader["Name"].ToString();
                    }
                }
                /*имя группы-предка*/
                if (P_G_ID>0) {
                    cmd = new SqlCommand("select G.* from Groups G where G.ID = @ID", conn);
                    // создаем параметр для имени
                    idParam = new SqlParameter("@ID", P_G_ID);
                    // добавляем параметр к команде
                    cmd.Parameters.Add(idParam);
                    //читаем имя предка
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {

                        while (reader.Read())
                        {
                            ParentName = reader["Name"].ToString();
                        }
                    }

                }
                /*имя редактируемойго элемента*/
                if (ID > 0)
                {
                    cmd = new SqlCommand("select G.* from Groups G where G.ID = @ID", conn);
                    // создаем параметр для имени
                    idParam = new SqlParameter("@ID", ID);
                    // добавляем параметр к команде
                    cmd.Parameters.Add(idParam);
                    //читаем имя группы
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {

                        while (reader.Read())
                        {
                            GName = reader["Name"].ToString();
                        }
                    }

                }

            }
          
            InitializeComponent();
        }

        private void OKbtn_Click(object sender, EventArgs e)
        {
            string connectionString = main.connectionString;
            string commandText = "";
            switch (OP) //операция
            {
                case 1: //добавление новой записи
                    commandText = "INSERT INTO dbo.Groups (P_G_ID,Tables_ID,Name) VALUES (@P_G_ID,@Tables_ID,@Name);";
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand command = new SqlCommand(commandText, connection);
                        command.Parameters.Add("@Tables_ID", SqlDbType.VarChar);
                        command.Parameters["@Tables_ID"].Value = Tables_ID;

                        command.Parameters.Add("@P_G_ID", SqlDbType.VarChar);
                        command.Parameters["@P_G_ID"].Value = P_G_ID;

                        command.Parameters.Add("@Name", SqlDbType.VarChar);
                        command.Parameters["@Name"].Value = GrpNameTB.Text;

                        try
                        {
                            connection.Open();
                            Int32 rowsAffected = command.ExecuteNonQuery();
                            MessageBox.Show(rowsAffected.ToString() + " rows affected by insert");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }
                    

                    break;
                case 2: //редактирование записи
                    commandText = "UPDATE dbo.Groups set P_G_ID=@P_G_ID,Tables_ID=@Tables_ID,Name=@Name where ID=@ID;";
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand command = new SqlCommand(commandText, connection);
                        command.Parameters.Add("@Tables_ID", SqlDbType.VarChar);
                        command.Parameters["@Tables_ID"].Value = Tables_ID;

                        command.Parameters.Add("@P_G_ID", SqlDbType.VarChar);
                        command.Parameters["@P_G_ID"].Value = P_G_ID;

                        command.Parameters.Add("@Name", SqlDbType.VarChar);
                        command.Parameters["@Name"].Value = GrpNameTB.Text;

                        command.Parameters.Add("@ID", SqlDbType.VarChar);
                        command.Parameters["@ID"].Value = ID;


                        try
                        {
                            connection.Open();
                            Int32 rowsAffected = command.ExecuteNonQuery();
                            MessageBox.Show(rowsAffected.ToString() + " rows affected by update");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }

                    break;

                default:
                    break;
            }
            this.Close();
            this.Dispose();
        }

        private void GroupE_Load(object sender, EventArgs e)
        {
            TNameLbl.Text = TName;
            ParentLbl.Text = ParentName+"("+ P_G_ID.ToString();
            GrpNameTB.Text = GName;
        }
    }
}
