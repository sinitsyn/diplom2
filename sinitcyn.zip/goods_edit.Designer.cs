﻿
namespace WinFormsApp1
{
    partial class goods_editF
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.FNameLab = new System.Windows.Forms.Label();
            this.FNameTBox = new System.Windows.Forms.TextBox();
            this.PriceLab = new System.Windows.Forms.Label();
            this.PriceTBox = new System.Windows.Forms.TextBox();
            this.PriceOutTBox = new System.Windows.Forms.TextBox();
            this.PriceOutLab = new System.Windows.Forms.Label();
            this.VATTBox = new System.Windows.Forms.TextBox();
            this.VATLab = new System.Windows.Forms.Label();
            this.SaveBtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.GRPtreeView = new System.Windows.Forms.TreeView();
            this.SuspendLayout();
            // 
            // FNameLab
            // 
            this.FNameLab.AutoSize = true;
            this.FNameLab.Location = new System.Drawing.Point(23, 25);
            this.FNameLab.Name = "FNameLab";
            this.FNameLab.Size = new System.Drawing.Size(72, 17);
            this.FNameLab.TabIndex = 0;
            this.FNameLab.Text = "Название";
            // 
            // FNameTBox
            // 
            this.FNameTBox.Location = new System.Drawing.Point(154, 19);
            this.FNameTBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.FNameTBox.Name = "FNameTBox";
            this.FNameTBox.Size = new System.Drawing.Size(400, 22);
            this.FNameTBox.TabIndex = 1;
            // 
            // PriceLab
            // 
            this.PriceLab.AutoSize = true;
            this.PriceLab.Location = new System.Drawing.Point(23, 56);
            this.PriceLab.Name = "PriceLab";
            this.PriceLab.Size = new System.Drawing.Size(43, 17);
            this.PriceLab.TabIndex = 2;
            this.PriceLab.Text = "Цена";
            // 
            // PriceTBox
            // 
            this.PriceTBox.Location = new System.Drawing.Point(154, 50);
            this.PriceTBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PriceTBox.Name = "PriceTBox";
            this.PriceTBox.Size = new System.Drawing.Size(139, 22);
            this.PriceTBox.TabIndex = 3;
            this.PriceTBox.Text = "0";
            // 
            // PriceOutTBox
            // 
            this.PriceOutTBox.Location = new System.Drawing.Point(154, 84);
            this.PriceOutTBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PriceOutTBox.Name = "PriceOutTBox";
            this.PriceOutTBox.Size = new System.Drawing.Size(139, 22);
            this.PriceOutTBox.TabIndex = 5;
            this.PriceOutTBox.Text = "0";
            // 
            // PriceOutLab
            // 
            this.PriceOutLab.AutoSize = true;
            this.PriceOutLab.Location = new System.Drawing.Point(23, 90);
            this.PriceOutLab.Name = "PriceOutLab";
            this.PriceOutLab.Size = new System.Drawing.Size(126, 17);
            this.PriceOutLab.TabIndex = 4;
            this.PriceOutLab.Text = "Цена реализации";
            // 
            // VATTBox
            // 
            this.VATTBox.Location = new System.Drawing.Point(154, 120);
            this.VATTBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.VATTBox.Name = "VATTBox";
            this.VATTBox.Size = new System.Drawing.Size(139, 22);
            this.VATTBox.TabIndex = 7;
            this.VATTBox.Text = "0";
            // 
            // VATLab
            // 
            this.VATLab.AutoSize = true;
            this.VATLab.Location = new System.Drawing.Point(23, 126);
            this.VATLab.Name = "VATLab";
            this.VATLab.Size = new System.Drawing.Size(38, 17);
            this.VATLab.TabIndex = 6;
            this.VATLab.Text = "НДС";
            // 
            // SaveBtn
            // 
            this.SaveBtn.Location = new System.Drawing.Point(363, 307);
            this.SaveBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.SaveBtn.Name = "SaveBtn";
            this.SaveBtn.Size = new System.Drawing.Size(94, 23);
            this.SaveBtn.TabIndex = 8;
            this.SaveBtn.Text = "Сохранить";
            this.SaveBtn.UseVisualStyleBackColor = true;
            this.SaveBtn.Click += new System.EventHandler(this.SaveBtn_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(463, 307);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(94, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "Отмена";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 170);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 17);
            this.label1.TabIndex = 10;
            this.label1.Text = "Группа";
            this.label1.Visible = false;
            // 
            // GRPtreeView
            // 
            this.GRPtreeView.Location = new System.Drawing.Point(154, 170);
            this.GRPtreeView.Name = "GRPtreeView";
            this.GRPtreeView.Size = new System.Drawing.Size(139, 130);
            this.GRPtreeView.TabIndex = 11;
            this.GRPtreeView.Visible = false;
            // 
            // goods_editF
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(581, 341);
            this.Controls.Add(this.GRPtreeView);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.SaveBtn);
            this.Controls.Add(this.VATTBox);
            this.Controls.Add(this.VATLab);
            this.Controls.Add(this.PriceOutTBox);
            this.Controls.Add(this.PriceOutLab);
            this.Controls.Add(this.PriceTBox);
            this.Controls.Add(this.PriceLab);
            this.Controls.Add(this.FNameTBox);
            this.Controls.Add(this.FNameLab);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "goods_editF";
            this.Text = "Изменение товара";
            this.Load += new System.EventHandler(this.goods_edit_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label FNameLab;
        private System.Windows.Forms.TextBox FNameTBox;
        private System.Windows.Forms.Label PriceLab;
        private System.Windows.Forms.TextBox PriceTBox;
        private System.Windows.Forms.TextBox PriceOutTBox;
        private System.Windows.Forms.Label PriceOutLab;
        private System.Windows.Forms.TextBox VATTBox;
        private System.Windows.Forms.Label VATLab;
        private System.Windows.Forms.Button SaveBtn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TreeView GRPtreeView;
    }
}