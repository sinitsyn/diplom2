﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Pass_Form : Form
    {
        public Pass_Form()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string commandText = "SELECT * from PASSWORDS where NAME=@USER and PASS=@PASS";

            using (SqlConnection connection = new SqlConnection(main.connectionString))
            {
                SqlCommand command = new SqlCommand(commandText, connection);
                command.Parameters.Add("@USER", SqlDbType.VarChar);
                command.Parameters["@USER"].Value = User_tB.Text;

                command.Parameters.Add("@PASS", SqlDbType.VarChar);
                command.Parameters["@PASS"].Value = Pass_tB.Text;

                try
                {
                    connection.Open();
                    Int32 rowsAffected = command.ExecuteNonQuery();
                    MessageBox.Show(rowsAffected.ToString() + " rows affected by insert");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }


        }

        private DataSet CreateDataSet()
        {
            string connectionString = main.connectionString;
            using (SqlConnection conn = new
                   SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM dbo.PASSWORDS", conn))
                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    // Объекты‐адаптеры умеют взаимодействовать  
                    // с конкретными серверами баз данных  
                    adapter.TableMappings.Add("Table", "dbo.PASSWORDS");
                    adapter.SelectCommand = cmd;
                    DataSet dataSet = new DataSet("dbo.PASSWORDS");
                    // Поместить все строки в набор данных  
                    adapter.Fill(dataSet);
                    return dataSet;
                }

            }
        }
    }
}
