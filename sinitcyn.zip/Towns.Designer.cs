﻿
namespace WinFormsApp1
{
    partial class Towns
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.ChooseBtn = new System.Windows.Forms.Button();
            this.DelBtn = new System.Windows.Forms.Button();
            this.EditBtn = new System.Windows.Forms.Button();
            this.NewBtn = new System.Windows.Forms.Button();
            this.TownsGridView = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TownsGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.ChooseBtn);
            this.panel1.Controls.Add(this.DelBtn);
            this.panel1.Controls.Add(this.EditBtn);
            this.panel1.Controls.Add(this.NewBtn);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 384);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(800, 66);
            this.panel1.TabIndex = 0;
            // 
            // ChooseBtn
            // 
            this.ChooseBtn.Location = new System.Drawing.Point(694, 23);
            this.ChooseBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ChooseBtn.Name = "ChooseBtn";
            this.ChooseBtn.Size = new System.Drawing.Size(94, 23);
            this.ChooseBtn.TabIndex = 6;
            this.ChooseBtn.Text = "Выбрать";
            this.ChooseBtn.UseVisualStyleBackColor = true;
            this.ChooseBtn.Click += new System.EventHandler(this.ChooseBtn_Click);
            // 
            // DelBtn
            // 
            this.DelBtn.Location = new System.Drawing.Point(213, 23);
            this.DelBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DelBtn.Name = "DelBtn";
            this.DelBtn.Size = new System.Drawing.Size(94, 23);
            this.DelBtn.TabIndex = 5;
            this.DelBtn.Text = "Удалить";
            this.DelBtn.UseVisualStyleBackColor = true;
            this.DelBtn.Click += new System.EventHandler(this.DelBtn_Click);
            // 
            // EditBtn
            // 
            this.EditBtn.Location = new System.Drawing.Point(113, 23);
            this.EditBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.EditBtn.Name = "EditBtn";
            this.EditBtn.Size = new System.Drawing.Size(94, 23);
            this.EditBtn.TabIndex = 4;
            this.EditBtn.Text = "Изменить";
            this.EditBtn.UseVisualStyleBackColor = true;
            this.EditBtn.Click += new System.EventHandler(this.EditBtn_Click);
            // 
            // NewBtn
            // 
            this.NewBtn.Location = new System.Drawing.Point(13, 23);
            this.NewBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.NewBtn.Name = "NewBtn";
            this.NewBtn.Size = new System.Drawing.Size(94, 23);
            this.NewBtn.TabIndex = 3;
            this.NewBtn.Text = "Новый";
            this.NewBtn.UseVisualStyleBackColor = true;
            this.NewBtn.Click += new System.EventHandler(this.NewBtn_Click);
            // 
            // TownsGridView
            // 
            this.TownsGridView.AllowUserToAddRows = false;
            this.TownsGridView.AllowUserToDeleteRows = false;
            this.TownsGridView.AllowUserToOrderColumns = true;
            this.TownsGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.TownsGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TownsGridView.Location = new System.Drawing.Point(0, 0);
            this.TownsGridView.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.TownsGridView.Name = "TownsGridView";
            this.TownsGridView.ReadOnly = true;
            this.TownsGridView.RowHeadersWidth = 51;
            this.TownsGridView.RowTemplate.Height = 29;
            this.TownsGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.TownsGridView.Size = new System.Drawing.Size(800, 384);
            this.TownsGridView.TabIndex = 4;
            // 
            // Towns
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.TownsGridView);
            this.Controls.Add(this.panel1);
            this.Name = "Towns";
            this.Text = "Города";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.TownsGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView TownsGridView;
        private System.Windows.Forms.Button DelBtn;
        private System.Windows.Forms.Button EditBtn;
        private System.Windows.Forms.Button NewBtn;
        private System.Windows.Forms.Button ChooseBtn;
    }
}