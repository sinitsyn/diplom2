﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Towns : Form
    {
        private int op;
        private SqlConnection sqlConnection = null;
        private SqlDataAdapter SqlDataAdapter = null;
        private SqlCommandBuilder SqlCommandBuilder = null;
        private SqlTransaction t;
        public int TownsId = -1;
        public string TownsName = "";

        string filter;
        DataSet dataSet;

        public Towns(int op_cmd)
        {
            op = op_cmd;
            dataSet = CreateDataSet();
            InitializeComponent();
            TownsGridView.DataSource = dataSet.Tables["dbo.Towns"];
            LoadData();
            Set_ColumnHeader();
            TownsGridView.Focus();
        }

        private DataSet CreateDataSet(string newSql = "")
        {
            string connectionString = main.connectionString;
            using (SqlConnection conn = new
                   SqlConnection(connectionString))
            {
                conn.Close();

                conn.Open();
                //MessageBox.Show("Успешное подключение !");
                using (SqlCommand cmd = new SqlCommand("SELECT T.* FROM dbo.Towns T WHERE T.ID=T.ID " + newSql, conn))
                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    // Объекты‐адаптеры умеют взаимодействовать  
                    // с конкретными серверами баз данных  
                    adapter.TableMappings.Add("Table", "dbo.Towns");
                    adapter.SelectCommand = cmd;
                    DataSet dataSet = new DataSet("dbo.Output_Doc");
                    // Поместить все строки в набор данных  
                    adapter.Fill(dataSet);
                    return dataSet;
                }

            }
        }

        private void LoadData()
        {
            if (op == 0)
            {

            }
        }

        private void ChooseBtn_Click(object sender, EventArgs e)
        {
            TownsGridView.Focus();
            TownsId = Convert.ToInt32(dataSet.Tables[0].Rows[TownsGridView.CurrentRow.Index]["ID"].ToString());
            TownsName = dataSet.Tables[0].Rows[TownsGridView.CurrentRow.Index]["NAME"].ToString();

            if (op > 0) this.Close();
        }

        private void NewBtn_Click(object sender, EventArgs e)
        {
            int row = TownsGridView.RowCount;
            Town_Edit ce = new Town_Edit(1);
            ce.ShowDialog();
            GridR(0);
            Set_ColumnHeader();
            //TownsGridView.CurrentCell = TownsGridView.Rows[row].Cells[2];
        }

        private void GridR(int op)
        {
            string w = "";
            TownsGridView.DataSource = null;
            
            dataSet = CreateDataSet(" " + w); //установка фильтра
            TownsGridView.DataSource = dataSet.Tables["dbo.Towns"];
            
            Set_ColumnHeader();
        }

        private void Set_ColumnHeader()
        {
            //обзываем
            TownsGridView.Columns["Name"].DisplayIndex = 0;
            TownsGridView.Columns["Name"].HeaderText = "Название";
            

            
            if (TownsGridView.Columns["ID"].Visible == true) TownsGridView.Columns["ID"].Visible = false;
            
        }

        private void EditBtn_Click(object sender, EventArgs e)
        {
            TownsGridView.Focus();
            int row = TownsGridView.CurrentRow.Index;
            int ID = Convert.ToInt32(dataSet.Tables[0].Rows[row]["ID"].ToString());
            //string FNameVal = ClientsGridView.CurrentRow.Cells["FName"].Value.ToString();
            //string FNameVal = Convert.ToString(dataSet.Tables[0].Rows[ClientsGridView.CurrentRow.Index]["FName"].ToString());
            string NameVal = Convert.ToString(dataSet.Tables[0].Rows[row]["Name"].ToString());
            
            Town_Edit ce = new Town_Edit(2, ID, NameVal);
            ce.ShowDialog();
            GridR(1);
            Set_ColumnHeader();
            TownsGridView.CurrentCell = TownsGridView.Rows[row].Cells[1];
        }

        private void DelBtn_Click(object sender, EventArgs e)
        {
            int row = TownsGridView.CurrentRow.Index;


            //int ID = Convert.ToInt32( ClientsGridView.CurrentRow.Cells["ID"].Value.ToString());
            int ID = Convert.ToInt32(dataSet.Tables[0].Rows[row]["ID"].ToString());
            string connectionString = main.connectionString;
            using (SqlConnection conn = new
                   SqlConnection(connectionString))
            {
                conn.Close();

                conn.Open();
                //MessageBox.Show("Успешное подключение !");
                using (SqlCommand cmd = new SqlCommand("DELETE FROM dbo.Towns where ID=@ID", conn))
                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {

                    cmd.Parameters.Add(new SqlParameter("@ID", ID));
                    // Здесь используется метод ExecuteNonQuery(), потому  
                    // что мы не выдаем запрос на чтение строк во время  
                    // вставки 
                    int rowsAffected = cmd.ExecuteNonQuery();
                    MessageBox.Show(rowsAffected.ToString() + " rows affected by delete");
                }


            }
            //   goods_editF ge = new goods_editF(3, ID);
            //   ge.ShowDialog();
            GridR(2);
            Set_ColumnHeader();
            if (row >0 )  TownsGridView.CurrentCell = TownsGridView.Rows[row - 1].Cells[1];
        }


    }
}
