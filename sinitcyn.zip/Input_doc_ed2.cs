﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Input_doc_ed2 : Form
    {
        string connectionString = main.connectionString;
        public bool Commit = false;

        private SqlConnection conn;
        private SqlDataAdapter sqlDataAdapter;
        private SqlCommandBuilder sqlCommandBuilder;

        private DataSet dataSet;
        private SqlTransaction t; 
        private int ClientsID = -1;
        private int Input_Doc_ID = -1;
        private int num = -1;
        private DateTime Date;
        private string Client_Name = "";
        private int cmd = 0;
        private double sum = 0;
        private double VAT = 0;

        public Input_doc_ed2(int cmd, int doc_id = -1) //создание формы
        {
            conn = new SqlConnection(connectionString);
            conn.Open();
            //InitializeComponent();
            t = conn.BeginTransaction();

            sqlDataAdapter = new SqlDataAdapter();
            Input_Doc_ID = doc_id;
            this.cmd = cmd;
            string sqlExpression = "";
            switch (cmd)
            {
                case 0: //new doc
                    sqlExpression = "select COALESCE(max(id.Bill_Num), 0) as num from Input_Doc id";
                    SqlCommand command = new SqlCommand(sqlExpression, conn);
                    command.Transaction = t;

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            num = reader.GetInt32(0); //"Bill_num"
                        }
                    }
                    break;
                case 1: //edit
                    sqlExpression = "select ID.*, C.FName from dbo.Input_Doc ID, dbo.Clients C where ID.ID = @ID and ID.client_id = C.ID";
                    SqlCommand command1 = new SqlCommand(sqlExpression, conn);
                    command1.Transaction = t;
                    // создаем параметр для имени
                    SqlParameter idParam = new SqlParameter("@ID", Input_Doc_ID);
                    // добавляем параметр к команде
                    command1.Parameters.Add(idParam);

                    using (SqlDataReader reader = command1.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            num = reader.GetInt32(1); //"Bill_num"
                            Client_Name = reader.GetString(6); //"FName"
                            ClientsID = reader.GetInt32(2); //"Client_ID"
                            Date = reader.GetDateTime(5); //"Data"
                        }
                    }
                    break;
            }
            InitializeComponent();
            //Set_ColumnHeader();
        }

        private void Set_ColumnHeader()
        {
            /*переименовывание*/
            if (InputGoogsGridView.Columns["ID"].Visible == true) InputGoogsGridView.Columns["ID"].Visible = false;
            if (InputGoogsGridView.Columns["Input_Doc_ID"].Visible == true) InputGoogsGridView.Columns["Input_Doc_ID"].Visible = false;
            if (InputGoogsGridView.Columns["GoodsID"].Visible == true) InputGoogsGridView.Columns["GoodsID"].Visible = false;
            //if (InputGoogsGridView.Columns["GoodsId"].Visible == true) InputGoogsGridView.Columns["GoodsId"].Visible = false;
            //InputGoogsGridView.Columns["Input_Doc_ID"].Visible = false;
            //InputGoogsGridView.Columns["Goods_ID"].Visible = false;
            //InputGoogsGridView.Columns["GoodsId"].Visible = false;

            InputGoogsGridView.Columns["FNAME"].DisplayIndex = 0;
            InputGoogsGridView.Columns["FNAME"].HeaderText = "Название";
            InputGoogsGridView.Columns["Count"].DisplayIndex = 1;
            InputGoogsGridView.Columns["Count"].HeaderText = "Количество";
            InputGoogsGridView.Columns["Price"].DisplayIndex = 2;
            InputGoogsGridView.Columns["Price"].HeaderText = "Цена";
            InputGoogsGridView.Columns["Price"].CellTemplate.Style.Format = "N2";
            InputGoogsGridView.Columns["SUM"].DisplayIndex = 3;
            InputGoogsGridView.Columns["SUM"].HeaderText = "Сумма";
            InputGoogsGridView.Columns["Sum"].CellTemplate.Style.Format = "N2";
            InputGoogsGridView.Columns["VAT"].DisplayIndex = 4;
            InputGoogsGridView.Columns["VAT"].HeaderText = "НДС%";
            InputGoogsGridView.Columns["VAT"].CellTemplate.Style.Format = "N2";
            InputGoogsGridView.Columns["S_VAT"].DisplayIndex = 5;
            InputGoogsGridView.Columns["S_VAT"].HeaderText = "В.т.ч. НДС";
            InputGoogsGridView.Columns["S_VAT"].CellTemplate.Style.Format = "N2";
        }


        private string GetSql() //товарная часть
        {
            /* return "SELECT IG.*,IG.price * IG.count as SUM,G.FNAME,G.VAT,cast((IG.PRICE/(100+G.VAT)*G.VAT)*IG.count as numeric(10,2)) as S_VAT,cast((IG.PRICE-(IG.PRICE/(100+G.VAT)*G.VAT)) as numeric(10,2)) as PRICE_WV FROM dbo.Input_Goods IG,Goods G WHERE IG.Goods_id=G.ID and IG.Input_Doc_ID =" + Input_Doc_ID;*/

            /*return "SELECT IG.*,IG.price * IG.count as SUM,G.FNAME,G.VAT,cast((IG.PRICE/(100+G.VAT)*G.VAT)*IG.count as numeric(10,2)) as S_VAT,cast((IG.PRICE-(IG.PRICE/(100+G.VAT)*G.VAT)) as numeric(10,2)) as PRICE_WV FROM dbo.Input_Goods IG,Goods G WHERE IG.Goods_id=G.ID and IG.Input_Doc_ID =" + Input_Doc_ID;*/

            /* return "SELECT IG.*,IG.price * IG.count as SUM,G.FNAME,G.VAT,  cast((IG.Price * IG.Count) / (100 + G.VAT) * G.VAT as numeric(10, 2)) as S_VAT FROM dbo.Input_Goods IG, Goods G WHERE IG.Goods_id = G.ID IG,Goods G WHERE IG.Goods_id=G.ID and IG.Input_Doc_ID =" + Input_Doc_ID;*/
          
            return "SELECT IG.*,IG.price * IG.count as SUM,G.FNAME,G.VAT,cast((IG.Price * IG.Count) / (100 + G.VAT) *G.VAT as numeric(10, 2)) as S_VAT FROM dbo.Input_Goods IG, Goods G WHERE IG.Goodsid = G.ID and IG.Input_Doc_ID =" + Input_Doc_ID;
            /*cast((IG.PRICE/(100+G.VAT)*G.VAT) as numeric(10,2)) as R_VAT,
            cast((IG.PRICE/(100+G.VAT)*G.VAT) as numeric(10,2))*IG.count as S_VAT,
            cast((IG.PRICE-(IG.PRICE/(100+G.VAT)*G.VAT)) as numeric(10,2)) as PRICE_WV FROM dbo.Input_Goods IG,Goods G WHERE IG.Goods_id=G.ID*/
        }

        private void GridR() //заполнение грида
        {
            int r = 0;
            int ind = 0; //выделенная строка
            //if (dataSet.Tables[0].Rows.Count > 0)
              //  ind = InputGoogsGridView.CurrentCell.RowIndex; 
             
            sqlDataAdapter = new SqlDataAdapter(GetSql(), conn);
            sqlDataAdapter.SelectCommand.Transaction = t;
            DataSet ds = new DataSet();
            sqlDataAdapter.Fill(ds);
            InputGoogsGridView.DataSource = ds.Tables[0];
            InputGoogsGridView.Columns["Id"].ReadOnly = true;
          //  if (ind>0) InputGoogsGridView.CurrentCell = InputGoogsGridView.Rows[ind+1].Cells[1]; //возврат на выделенную строку
            /*  switch (g_cmd)
              {
                  case 1:
                      InputGoogsGridView.CurrentCell = InputGoogsGridView.Rows[InputGoogsGridView.RowCount - 1].Cells[1]; //добавление
                      break;
                  case 2:
                      InputGoogsGridView.CurrentCell = InputGoogsGridView.Rows[r].Cells[1];//редактирование
                      break;
                  case 3:
                      InputGoogsGridView.CurrentCell = InputGoogsGridView.Rows[r - 1].Cells[1];//удаление
                      break;
                  default:
                      break;
              }*/
            //Set_ColumnHeader();
        }

        private void  CalcSum(ref double sum, ref double VAT)
        {
            string sqlExpression = "SELECT sum(IG.price * IG.count) as SUM, sum(IG.PRICE/(100+G.VAT)*G.VAT*IG.count) as S_VAT  FROM dbo.Input_Goods IG,Goods G WHERE IG.GoodsId=G.ID and IG.Input_Doc_ID=@Input_Doc_ID";
            //double sum = 0;
            SqlCommand command = new SqlCommand(sqlExpression, conn);
            command.Transaction = t;
            SqlParameter Param1 = new SqlParameter("@input_doc_id", Input_Doc_ID);
            command.Parameters.Add(Param1);

            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    if (!reader.IsDBNull(0))
                    {
                        sum = Convert.ToDouble(reader.GetDecimal(0));
                        //VAT = Convert.ToDouble(reader.GetDecimal(1));
                        VAT = Math.Round(Convert.ToDouble(reader.GetDecimal(1)), 2);
                    }
                    else
                    {
                        sum = 0;
                        VAT = 0;
                    }

                    /*sum = 0;
                    if (reader.GetDecimal(0) != null) sum = Convert.ToDouble(reader.GetDecimal(0)); //"sum"*/
                }
            }
            //return sum;
        }

        private void RecalcSaldo() //обновление остатков
        {
           /* string sqlExpression = "update GOODS set Balance=((select COALESCE(sum(count),0) from Input_Goods IG where IG.Goods_ID=GOODS.ID)-(select COALESCE(sum(count),0) from Output_Goods OG where OG.Goods_ID=GOODS.ID))";
                    
            try
            {
                SqlCommand command = new SqlCommand(sqlExpression, conn);
                command.Transaction = t;
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }*/
        }

        private void UpdateSum(int id, int num, DateTime date, int ClientsID/*, double sum, double VAT*/)
        {
            string sqlExpression = "UPDATE dbo.Input_Doc set Bill_Num=@Bill_Num, Data=@Data,Client_id=@Client_id,sum=@sum,VAT=@VAT where ID=@ID";
            double sum = 0;
            double VAT = 0;
            try
            {
                SqlCommand commandadd = new SqlCommand(sqlExpression, conn);
                commandadd.Transaction = t;
                SqlParameter idParam = new SqlParameter("@ID", id);
                // добавляем параметр к команде
                commandadd.Parameters.Add(idParam);
                SqlParameter numParam = new SqlParameter("@Bill_Num", num);
                // добавляем параметр к команде
                commandadd.Parameters.Add(numParam);
                // создаем параметр для возраста
                SqlParameter dateParam = new SqlParameter("@Data", date);
                // добавляем параметр к команде
                commandadd.Parameters.Add(dateParam);
                // создаем параметр для клиента
                SqlParameter clientParam = new SqlParameter("@Client_id", ClientsID);
                // добавляем параметр к команде
                commandadd.Parameters.Add(clientParam);
                CalcSum(ref sum, ref VAT);
                
                // создаем параметр для суммы
                SqlParameter sumParam = new SqlParameter("@SUM", sum);
                // добавляем параметр к команде
                commandadd.Parameters.Add(sumParam);
                // создаем параметр для НДС
                SqlParameter VatParam = new SqlParameter("@VAT", VAT);
                // добавляем параметр к команде
                commandadd.Parameters.Add(VatParam);
                int rowsAffected = commandadd.ExecuteNonQuery();
                MessageBox.Show(rowsAffected.ToString() + " rows affected by update id=" + id.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

     


        private void NewDocBtn_Click(object sender, EventArgs e) //новый документ
        {
            if (cmd == 0) //если новый документ
            {
                if (ClientsID == -1) return;
                string sqlExpression = "INSERT INTO dbo.Input_Doc(Bill_Num, Data,Client_id) VALUES(@Bill_Num, @Data,@Client_id);SET @id=SCOPE_IDENTITY()";
                try
                {
                    num = Convert.ToInt32(BilNumTB.Text);
                    Date = DateTP.Value;

                    SqlCommand commandadd = new SqlCommand(sqlExpression, conn);
                    commandadd.Transaction = t;
                    SqlParameter numParam = new SqlParameter("@Bill_Num", num);
                    // добавляем параметр к команде
                    commandadd.Parameters.Add(numParam);
                    // создаем параметр для даты
                    SqlParameter dateParam = new SqlParameter("@Data", Date);
                    // добавляем параметр к команде
                    commandadd.Parameters.Add(dateParam);
                    // создаем параметр для клиента
                    SqlParameter clientParam = new SqlParameter("@Client_id", ClientsID);
                    // добавляем параметр к команде
                    commandadd.Parameters.Add(clientParam);
                    // параметр для id
                    SqlParameter idParam = new SqlParameter
                    {
                        ParameterName = "@id",
                        SqlDbType = SqlDbType.Int,
                        Direction = ParameterDirection.Output // параметр выходной
                    };
                    commandadd.Parameters.Add(idParam);

                    int rowsAffected = commandadd.ExecuteNonQuery();
                    Input_Doc_ID = Convert.ToInt32(idParam.Value);
                    MessageBox.Show(rowsAffected.ToString() + " rows affected by insert id=" + idParam.Value.ToString());
                    good_panel.Visible = true;
                    GridR();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            if (cmd == 1) //если изменение документа
            {
                string sqlExpression = "UPDATE dbo.Input_Doc set Bill_Num=@Bill_Num, Data=@Data,Client_id=@Client_id where ID=@ID;";
                try
                {
                    int num = Convert.ToInt32(BilNumTB.Text);
                    Date = DateTP.Value;

                    SqlCommand commandadd = new SqlCommand(sqlExpression, conn);
                    commandadd.Transaction = t;
                    SqlParameter numParam = new SqlParameter("@Bill_Num", num);
                    // добавляем параметр к команде
                    commandadd.Parameters.Add(numParam);
                    // создаем параметр для возраста
                    SqlParameter dateParam = new SqlParameter("@Data", Date);
                    // добавляем параметр к команде
                    commandadd.Parameters.Add(dateParam);
                    // создаем параметр для клиента
                    SqlParameter clientParam = new SqlParameter("@Client_id", ClientsID);
                    // добавляем параметр к команде
                    commandadd.Parameters.Add(clientParam);
                    // параметр для id
                    SqlParameter idParam = new SqlParameter("@id", Input_Doc_ID);
                    // добавляем параметр к команде
                    commandadd.Parameters.Add(idParam);

                    int rowsAffected = commandadd.ExecuteNonQuery();
                    MessageBox.Show(rowsAffected.ToString() + " rows affected");
                    GridR();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            //Set_ColumnHeader();
        }

        private void button1_Click(object sender, EventArgs e) //OK
        {
           num = Convert.ToInt32(BilNumTB.Text);
           Date = DateTP.Value;
           //RecalcSaldo();
           double sum = -1, VAT = -1;
           CalcSum(ref sum, ref VAT);
           Recalc_Doc_Stocks();
           UpdateSum(Input_Doc_ID, num, Date, ClientsID/*, sum, VAT*/);
           try
            {
                t.Commit();
                Commit = true;
            }
            catch (Exception ex2)
            {
                MessageBox.Show("Error commit: " + ex2.Message);
                Commit = false;
            }
            this.Close();
            this.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            try
            {
                t.Rollback();
            }
            catch (Exception ex2)
            {
                MessageBox.Show("Error rollback: " + ex2.Message);
            }
            Commit = false;
            this.Close();
            this.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Clients c = new Clients(1);
            c.ShowDialog();
            if (c.client_id > -1)
            {
                ClientsID = c.client_id;
                ClientLab.Text = c.client_name;
                Client_Name = c.client_name;
            }
            return;
        }

        

private void button4_Click(object sender, EventArgs e)
        {
            Input_doc_good i = new Input_doc_good(0);
            i.ShowDialog();
            if (i.ok == true)
            {
                int Goods_ID = i.Id;
                int Count = i.Count;
                double Price = i.Price;

               string sqlExpression = "INSERT INTO dbo.Input_Goods(input_doc_id, goodsid,price,count) VALUES(@input_doc_id, @goodsid,@price,@count)";
                try
                {
                    SqlCommand command = new SqlCommand(sqlExpression, conn);
                    command.Transaction = t;
                    // создаем параметр для имени
                    SqlParameter input_doc_idParam = new SqlParameter("@input_doc_id", Input_Doc_ID);
                    // добавляем параметр к команде
                    command.Parameters.Add(input_doc_idParam);
                    // создаем параметр для возраста
                    SqlParameter Goods_ID_Param = new SqlParameter("@goodsid", Goods_ID);
                    // добавляем параметр к команде
                    command.Parameters.Add(Goods_ID_Param);
                    // создаем параметр для клиента
                    SqlParameter priceParam = new SqlParameter("@price", Price);
                    // добавляем параметр к команде
                    command.Parameters.Add(priceParam);
                    // создаем параметр для клиента
                    SqlParameter countParam = new SqlParameter("@count", Count);
                    // добавляем параметр к команде
                    command.Parameters.Add(countParam);
                    int number = command.ExecuteNonQuery();
                    MessageBox.Show(number.ToString() + " rows affected by insert");
                    GridR();
                    double sum=-1, VAT=-1;
                    CalcSum(ref sum, ref VAT);
                    //Sum_lbl.Text = CalcSum().ToString();
                    Sum_lbl.Text = sum.ToString();
                    VatLbl.Text = VAT.ToString();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }



        private void button5_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(InputGoogsGridView.CurrentRow.Cells["ID"].Value);
            Input_doc_good i = new Input_doc_good(3,id); /*cmd=2 edit*/
            i.Id = Convert.ToInt32(InputGoogsGridView.CurrentRow.Cells["GOODSID"].Value);
            
            i.Name = InputGoogsGridView.CurrentRow.Cells["FName"].Value.ToString();
            i.Count = Convert.ToInt32(InputGoogsGridView.CurrentRow.Cells["Count"].Value);
            i.Price = Convert.ToDouble(InputGoogsGridView.CurrentRow.Cells["Price"].Value);

            //int Id = Convert.ToInt32(InputGoogsGridView.CurrentRow.Cells["ID"].Value);
            int Goods_ID = Convert.ToInt32(InputGoogsGridView.CurrentRow.Cells["GoodsID"].Value);
            int Count = Convert.ToInt32(InputGoogsGridView.CurrentRow.Cells["Count"].Value);
            double Price = Convert.ToDouble(InputGoogsGridView.CurrentRow.Cells["Price"].Value);
            i.ShowDialog();

            if (i.Id != Goods_ID || i.Count != Count || i.Price != Price)
            {
                if (i.ok == true)
                {
                    try
                    {
                        string sqlExpression = "UPDATE dbo.Input_Goods set goodsid=@goodsid, price=@price,count=@count where ID = @ID";

                        /*SqlConnection add_conn;
                        add_conn = new SqlConnection(connectionString);
                        add_conn.Open();*/

                        SqlCommand command = new SqlCommand(sqlExpression, conn);
                        command.Connection = conn;

                        command.Transaction = t;
                        // создаем параметр для ID
                        SqlParameter id_doc_idParam = new SqlParameter("@ID", id);
                        // добавляем параметр к команде
                        command.Parameters.Add(id_doc_idParam);
                        // создаем параметр для возраста
                        SqlParameter Goods_ID_Param = new SqlParameter("@goodsid", i.Id);
                        // добавляем параметр к команде
                        command.Parameters.Add(Goods_ID_Param);
                        // создаем параметр для клиента
                        SqlParameter priceParam = new SqlParameter("@price", i.Price);
                        // добавляем параметр к команде
                        command.Parameters.Add(priceParam);
                        // создаем параметр для клиента
                        SqlParameter countParam = new SqlParameter("@count", i.Count);
                        // добавляем параметр к команде
                        command.Parameters.Add(countParam);
                        command.ExecuteNonQuery();
                        int ind = InputGoogsGridView.CurrentRow.Index;    //выделенная строка
                        GridR();
                        InputGoogsGridView.CurrentCell = InputGoogsGridView.Rows[ind].Cells["Price"]; //возврат на выделенную строку
                        //Sum_lbl.Text = CalcSum().ToString();
                        double sum = -1, VAT = -1;
                        CalcSum(ref sum, ref VAT);
                        Sum_lbl.Text = sum.ToString();
                        VatLbl.Text = VAT.ToString();

                        /*обновление  шапки документа*/
                         string sqlExpression2 = "UPDATE dbo.Input_Doc set SUM=@sum, VAT=@VAT where ID = @ID";

                         SqlCommand command2 = new SqlCommand(sqlExpression2, conn);
                        command2.Connection =conn;
                        command2.Transaction = t;

                        // создаем параметр для ID dbo.Input_Doc
                        int id2 = id;
                        SqlParameter id_doc_idParam2 = new SqlParameter("@ID", id2);
                        // добавляем параметр к команде
                        command2.Parameters.Add(id_doc_idParam2);
                        // создаем параметр для суммы
                        SqlParameter doc_sumParam = new SqlParameter("@SUM", sum);
                        // добавляем параметр к команде
                        command2.Parameters.Add(doc_sumParam);
                        // создаем параметр для НДС
                        SqlParameter doc_VatParam = new SqlParameter("@VAT", VAT);
                        // добавляем параметр к команде
                        command2.Parameters.Add(doc_VatParam);
                        command2.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }



        private void Input_doc_ed2_Load(object sender, EventArgs e)
        {
            if (cmd == 0)
                BilNumTB.Text = Convert.ToString(num + 1);
            if (cmd == 1)
            {
                BilNumTB.Text = Convert.ToString(num);
                DateTP.Value = Date;
                ClientLab.Text = Client_Name;

                GridR();
                //Sum_lbl.Text = CalcSum().ToString();
                double sum = -1, VAT = -1;
                CalcSum(ref sum, ref VAT);
                Sum_lbl.Text = sum.ToString();
                VatLbl.Text = VAT.ToString();

            }
            good_panel.Visible = true;
            //Set_ColumnHeader();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int Id = Convert.ToInt32(InputGoogsGridView.CurrentRow.Cells["ID"].Value);
            int Goods_Id = Convert.ToInt32(InputGoogsGridView.CurrentRow.Cells["GOODSID"].Value);
            
            try
            {
                string sqlExpression = "DELETE from dbo.Input_Goods where ID = @ID";
                SqlCommand command = new SqlCommand(sqlExpression, conn);
                command.Transaction = t;
                // создаем параметр для имени
                SqlParameter id_doc_idParam = new SqlParameter("@ID", Id);
                // добавляем параметр к команде
                command.Parameters.Add(id_doc_idParam);
                command.ExecuteNonQuery();
                sqlExpression = "EXEC RECALC_STOCK @ID";
                command = new SqlCommand(sqlExpression, conn);
                command.Transaction = t;
                // создаем параметр для имени
                id_doc_idParam = new SqlParameter("@ID", Goods_Id);
                // добавляем параметр к команде
                command.Parameters.Add(id_doc_idParam);
                command.ExecuteNonQuery();
                
                int ind = InputGoogsGridView.CurrentRow.Index;    //выделенная строка
                GridR();
                if (InputGoogsGridView.Rows.Count>0) InputGoogsGridView.CurrentCell = InputGoogsGridView.Rows[ind-1].Cells["Price"]; //возврат на предыдущую строку
                double sum = -1, VAT = -1;
                CalcSum(ref sum, ref VAT);
                Sum_lbl.Text = sum.ToString();
                VatLbl.Text = VAT.ToString();
                Recalc_Doc_Stocks(Goods_Id);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void PrnBtn_Click(object sender, EventArgs e)
        {
            //Set_ColumnHeader();
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            int w = InputGoogsGridView.Size.Width;
            int h = InputGoogsGridView.Size.Height;
            Bitmap bmp = new Bitmap(w, h);
            InputGoogsGridView.DrawToBitmap(bmp, InputGoogsGridView.Bounds);

            // Create pen.
            Pen blackPen = new Pen(Color.Black, 3);


            string sqlExpression = "SELECT IG.*,IG.price * IG.count as SUM,G.FNAME FROM dbo.Input_Goods IG,Goods G WHERE IG.Goodsid=G.ID and IG.INPUT_DOC_ID=@INPUT_DOC_ID";

            string fname = "";
            double price = 0;
            int count = 0;
            double sum = 0;
            double sum_itog = 0;
            //num = Convert.ToInt32(BilNumTB.Text);
            //Client_Name=
            SqlCommand command = new SqlCommand(sqlExpression, conn);
            command.Transaction = t;
            SqlParameter Param1 = new SqlParameter("@input_doc_id", Input_Doc_ID);
            command.Parameters.Add(Param1);



            int s = 300;
            // Create location and size of rectangle.
            int x = 30;
            int y = 30;
            int width = 300;
            int height = 50;

            using (SqlDataReader reader = command.ExecuteReader())
            {
                int top = 50;
                /*заголовок*/
                        e.Graphics.DrawString("Накладная № " + num.ToString() + " от " + Date.ToShortDateString(), new Font("Arial", 18, FontStyle.Bold), Brushes.Black, 220, top); top = top + 50;
                e.Graphics.DrawString("Продавец: " + Client_Name, new Font("Arial", 18, FontStyle.Bold), Brushes.Black, 65, top);
                /*шапка таблицы*/
                e.Graphics.DrawString("Наименование", new Font("Arial", 12, FontStyle.Bold | FontStyle.Italic), Brushes.Black, 65, s - 22);
                e.Graphics.DrawRectangle(blackPen, 65, s - 22, 400, 20);

                e.Graphics.DrawString("Цена", new Font("Arial", 12, FontStyle.Bold | FontStyle.Italic), Brushes.Black, 465, s - 22);
                e.Graphics.DrawRectangle(blackPen, 465, s - 22, 100, 20);

                e.Graphics.DrawString("Кол-во", new Font("Arial", 12, FontStyle.Bold | FontStyle.Italic), Brushes.Black, 565, s - 22);
                e.Graphics.DrawRectangle(blackPen, 565, s - 22, 100, 20);

                e.Graphics.DrawString("Сумма", new Font("Arial", 12, FontStyle.Bold | FontStyle.Italic), Brushes.Black, 665, s - 22);
                e.Graphics.DrawRectangle(blackPen, 665, s - 22, 100, 20);
                /*табличная часть*/
                while (reader.Read())
                {
                    fname = reader.GetString(6);//"FNAME"
                    price = Convert.ToDouble(reader.GetDecimal(3));//"price"
                    count = Convert.ToInt32(reader.GetInt32(4));//"count"
                    sum = Convert.ToDouble(reader.GetDecimal(5));//"sum"
                    e.Graphics.DrawString(fname, new Font("Arial", 12), Brushes.Black, 65, s);
                    e.Graphics.DrawRectangle(blackPen, 65, s - 1, 400, 20);

                    e.Graphics.DrawString(price.ToString(), new Font("Arial", 12), Brushes.Black, 465, s);
                    e.Graphics.DrawRectangle(blackPen, 465, s - 1, 100, 20);

                    e.Graphics.DrawString(count.ToString(), new Font("Arial", 12), Brushes.Black, 565, s);
                    e.Graphics.DrawRectangle(blackPen, 565, s - 1, 100, 20);

                    e.Graphics.DrawString(sum.ToString(), new Font("Arial", 12), Brushes.Black, 665, s);
                    e.Graphics.DrawRectangle(blackPen, 665, s - 1, 100, 20);

                    s = s + 20;
                    sum_itog = sum_itog + sum;
                }
                /*итог*/
                e.Graphics.DrawString("Итого: " + sum_itog.ToString()
                + " р.", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, 640, s + 10);
            }
        }

        private void Input_doc_ed2_FormClosed(object sender, FormClosedEventArgs e)
        {
            /*try
            {
                t.Rollback();
            }
            catch (Exception ex2)
            {
                MessageBox.Show("Error rollback: " + ex2.Message);
            }*/
            //button2_Click(null, null);
        }

        private void InputGoogsGridView_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            Set_ColumnHeader();
        }

        private void Recalc_Doc_Stocks(int Goods_Id = -1)
        {
            string sqlExpression = "EXEC [dbo].[RECALC_STOCK] @GOODSID";
            SqlCommand command = new SqlCommand();
            SqlParameter Goods_ID_Param = new SqlParameter("@goodsid", 1);
            command.Connection = conn;
            command.CommandText = sqlExpression;
            command.Transaction = t;
            if (Goods_Id > -1)
            {
               // int ID = Convert.ToInt32(InputGoogsGridView.Rows[j].Cells["Goods_id"].Value);
                Goods_ID_Param = new SqlParameter("@goodsid", Goods_Id);

                try
                {
                    // создаем параметр для имени
                    // добавляем параметр к команде
                    command.Parameters.Clear();
                    command.Parameters.Add(Goods_ID_Param);
                    int number = command.ExecuteNonQuery();
                    MessageBox.Show(number.ToString() + " rows affected by insert");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            } else

                for (int j = 0; j < InputGoogsGridView.Rows.Count; j++)
                {
                    int ID = Convert.ToInt32(InputGoogsGridView.Rows[j].Cells["Goodsid"].Value);
                    Goods_ID_Param = new SqlParameter("@goodsid", ID);

                    try
                    {
                        // создаем параметр для имени
                        command.Parameters.Clear();
                        command.Parameters.Add(Goods_ID_Param);
                        int number = command.ExecuteNonQuery();
                        MessageBox.Show(number.ToString() + " rows affected by insert");
                                            GridR();
                                            double sum = -1, VAT = -1;
                                            CalcSum(ref sum, ref VAT);
                                            //Sum_lbl.Text = CalcSum().ToString();
                                            Sum_lbl.Text = sum.ToString();
                                            VatLbl.Text = VAT.ToString();
                                            //DataGridViewCell d = InputGoogsGridView.Rows[InputGoogsGridView.Rows.Count-1].Cells["Price"];
                                            InputGoogsGridView.CurrentCell = InputGoogsGridView.Rows[InputGoogsGridView.Rows.Count - 1].Cells["Price"];

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
        }

        private void AddGoodBtn_Click(object sender, EventArgs e)
        {
            
            if (Input_Doc_ID == -1) {
                MessageBox.Show("Создайте документ для заполнения табличной части.");
                return;
            }
            Input_doc_good i = new Input_doc_good(0);
            i.ShowDialog();
            if (i.ok == true)
            {
                int Goods_ID = i.Id;
                int Count = i.Count;
                double Price = i.Price;
                int Good_Stock = 0;
                int Good_Count_NEW = Count;
                int Good_Count_Old = 0;

                string sqlExpression = "select * from Goods where ID=@ID";
                SqlCommand command = new SqlCommand(sqlExpression, conn);
                SqlParameter idParam = new SqlParameter("@ID", Goods_ID);
                command.Transaction = t;
                command.Parameters.Add(idParam);
                using (SqlDataReader reader = command.ExecuteReader())
                {

                    while (reader.Read())
                    {
                        Good_Stock = reader.GetInt32(5); //остаток
                    }
                }

                if (Good_Stock - Good_Count_Old + Count < 0)
                {
                    MessageBox.Show("У товара расчитается оcтаток < 0 !");
                    return;
                }

                sqlExpression = "INSERT INTO dbo.Input_Goods(input_doc_id, goodsid,price,count) VALUES(@input_doc_id, @goodsid,@price,@count)";
                    try
                    {
                        SqlCommand command2 = new SqlCommand();
                        command2.Connection = conn;
                        //SqlCommand command = new SqlCommand(sqlExpression, conn);
                        command2.CommandText = sqlExpression;
                        command2.Transaction = t;
                        // создаем параметр для имени
                        SqlParameter input_doc_idParam = new SqlParameter("@input_doc_id", Input_Doc_ID);
                        // добавляем параметр к команде
                        command2.Parameters.Add(input_doc_idParam);
                        // создаем параметр для возраста
                        SqlParameter Goods_ID_Param = new SqlParameter("@goodsid", Goods_ID);
                        // добавляем параметр к команде
                        command2.Parameters.Add(Goods_ID_Param);
                        // создаем параметр для клиента
                        SqlParameter priceParam = new SqlParameter("@price", Price);
                        // добавляем параметр к команде
                        command2.Parameters.Add(priceParam);
                        // создаем параметр для клиента
                        SqlParameter countParam = new SqlParameter("@count", Count);
                        // добавляем параметр к команде
                        command2.Parameters.Add(countParam);
                        int number = command2.ExecuteNonQuery();
                        MessageBox.Show(number.ToString() + " rows affected by insert");
                        GridR();
                        double sum = -1, VAT = -1;
                        CalcSum(ref sum, ref VAT);
                        //Sum_lbl.Text = CalcSum().ToString();
                        Sum_lbl.Text = sum.ToString();
                        VatLbl.Text = VAT.ToString();
                        //DataGridViewCell d = InputGoogsGridView.Rows[InputGoogsGridView.Rows.Count-1].Cells["Price"];
                        InputGoogsGridView.CurrentCell = InputGoogsGridView.Rows[InputGoogsGridView.Rows.Count - 1].Cells["Price"];

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            int Goods_ID = 1;
            int Good_Stock = 0;

            string sqlExpression = "select * from Goods where ID=@ID";
            SqlCommand command = new SqlCommand(sqlExpression, conn);
            SqlParameter idParam = new SqlParameter("@ID", Goods_ID);
            command.Transaction = t;
            command.Parameters.Add(idParam);
            using (SqlDataReader reader = command.ExecuteReader())
            {

                while (reader.Read())
                {
                    Good_Stock = reader.GetInt32(5); //остаток
                }
            }

        }
    }


}
