﻿
namespace WinFormsApp1
{
    partial class GroupE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.GrpNameTB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TNameLbl = new System.Windows.Forms.Label();
            this.ParentLbl = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.OKbtn = new System.Windows.Forms.Button();
            this.ChlBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // GrpNameTB
            // 
            this.GrpNameTB.Location = new System.Drawing.Point(114, 79);
            this.GrpNameTB.Name = "GrpNameTB";
            this.GrpNameTB.Size = new System.Drawing.Size(357, 22);
            this.GrpNameTB.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Название";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Таблица";
            // 
            // TNameLbl
            // 
            this.TNameLbl.AutoSize = true;
            this.TNameLbl.Location = new System.Drawing.Point(111, 8);
            this.TNameLbl.Name = "TNameLbl";
            this.TNameLbl.Size = new System.Drawing.Size(20, 17);
            this.TNameLbl.TabIndex = 3;
            this.TNameLbl.Text = "...";
            // 
            // ParentLbl
            // 
            this.ParentLbl.AutoSize = true;
            this.ParentLbl.Location = new System.Drawing.Point(113, 41);
            this.ParentLbl.Name = "ParentLbl";
            this.ParentLbl.Size = new System.Drawing.Size(0, 17);
            this.ParentLbl.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(71, 17);
            this.label4.TabIndex = 4;
            this.label4.Text = "Родитель";
            // 
            // OKbtn
            // 
            this.OKbtn.Location = new System.Drawing.Point(314, 126);
            this.OKbtn.Name = "OKbtn";
            this.OKbtn.Size = new System.Drawing.Size(75, 23);
            this.OKbtn.TabIndex = 6;
            this.OKbtn.Text = "OK";
            this.OKbtn.UseVisualStyleBackColor = true;
            this.OKbtn.Click += new System.EventHandler(this.OKbtn_Click);
            // 
            // ChlBtn
            // 
            this.ChlBtn.Location = new System.Drawing.Point(395, 126);
            this.ChlBtn.Name = "ChlBtn";
            this.ChlBtn.Size = new System.Drawing.Size(75, 23);
            this.ChlBtn.TabIndex = 7;
            this.ChlBtn.Text = "Отмена";
            this.ChlBtn.UseVisualStyleBackColor = true;
            // 
            // GroupE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(510, 165);
            this.Controls.Add(this.ChlBtn);
            this.Controls.Add(this.OKbtn);
            this.Controls.Add(this.ParentLbl);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TNameLbl);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.GrpNameTB);
            this.Name = "GroupE";
            this.Text = "GroupE";
            this.Load += new System.EventHandler(this.GroupE_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox GrpNameTB;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label TNameLbl;
        private System.Windows.Forms.Label ParentLbl;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button OKbtn;
        private System.Windows.Forms.Button ChlBtn;
    }
}