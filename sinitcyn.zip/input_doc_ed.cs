﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class input_doc_ed : Form
    {
        private SqlConnection conn = null;
        private SqlDataAdapter sqlDataAdapter = null;
        private SqlCommandBuilder sqlCommandBuilder = null;
        string connectionString = main.connectionString;
        private DataSet dataSet;
        private SqlTransaction t ;

        private int num=-1;
        private DateTime Date;
        private string Client_Name = "";
        private int Input_Doc_ID = -1;
        private int ClientsID = -1;
        private int Cmd = 0;


        public input_doc_ed(int cmd,int id=-1)
        {
            conn = new SqlConnection(connectionString);
            conn.Open();
            t = conn.BeginTransaction();
            //SqlTransaction transaction = conn.BeginTransaction();
            //conn.BeginTransaction();
            //if (Connection.State == ConnectionState.Open) Connection.Open();
            sqlDataAdapter = new SqlDataAdapter();
            Cmd = cmd;
            Input_Doc_ID = id;
            
            switch (cmd)
            {
                case 0: /*new*/

                    break;
                case 1: /*edit*/
                    //if (Connection.State == ConnectionState.Closed) Connection.Open();
                    string sqlExpression = "select ID.*, C.FName from dbo.Input_Doc ID, dbo.Clients C where ID.ID = @ID and ID.client_id = C.ID";
                    //string sqlExpression = "select ID.*,C.Fname from dbo.Input_Doc ID ID and Clients C where ID.ID=@ID and ID.clients_id=C.ID";
                    using (conn)
                    {
                        //sqlConnection.Open();
                        //SqlTransaction transaction = sqlConnection.BeginTransaction();

                        SqlCommand command = new SqlCommand(sqlExpression, conn);
                        command.Transaction = t;
                        // создаем параметр для имени
                        SqlParameter idParam = new SqlParameter("@ID", id);
                        // добавляем параметр к команде
                        command.Parameters.Add(idParam);
                        //command.ExecuteNonQuery();

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            // Класс SqlDataReader читает ряды и базы данных  
                            // по одному, по мере того, как их запрашиваем   
                            while (reader.Read())
                            {
                                num = reader.GetInt32(1); //"Bill_num"
                                Client_Name = reader.GetString(6); //"FName"
                                ClientsID = reader.GetInt32(5); //"Client_ID"
                                Date = reader.GetDateTime(4);//"Data"
                            }
                        }

                    }

                    break;
                default:
                    break;
            }

            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //transaction.Rollback();
            this.Close();
            this.Dispose();
        }

        private DataSet CreateDataSet(string newSql = "")
        {
            //string connectionString = @"Data source=VVS-PC;  Initial Catalog=InternetShopDB2; Integrated Security=SSPI";
           // if (Connection.State == ConnectionState.Closed) Connection.Open();
            using (conn)
            {
                // sqlConnection.Close();

                //sqlConnection.Open();
                //MessageBox.Show("Успешное подключение !");
                if (conn.State == ConnectionState.Closed) conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT *,price*count as SUM FROM dbo.Input_Goods WHERE Input_Doc_ID=@Input_Doc_ID " + newSql, conn))
                using (/*SqlDataAdapter adapter = new SqlDataAdapter()*/sqlDataAdapter)
                {
                    //cmd.Transaction = transaction;
                    cmd.Parameters.Add(new SqlParameter("@Input_Doc_ID", Input_Doc_ID));

                    // Объекты‐адаптеры умеют взаимодействовать  
                    // с конкретными серверами баз данных  
                    sqlDataAdapter.TableMappings.Add("Table", "dbo.Input_Goods");
                    sqlDataAdapter.SelectCommand = cmd;
                    DataSet dataSet = new DataSet("dbo.Input_Goods");
                    // Поместить все строки в набор данных  
                    sqlDataAdapter.Fill(dataSet);
                    //adapter.Update(dataSet);
                    return dataSet;
                }

            }
        }

      
        private void button1_Click(object sender, EventArgs e)
        {
            if (conn.State == ConnectionState.Closed) conn.Open();
            //int client_id = -1;
            //if (conn.State == ConnectionState.Closed) conn.Open();
            //return;
            if (this.conn.State == ConnectionState.Closed) this.conn.Open();

            Clients c = new Clients(1);
            c.ShowDialog();
            if (c.client_id > -1)
            {
                ClientsID = c.client_id;
                ClientLab.Text = c.client_name;
            }
            return;
        }

        private void Ins_Btn_Click(object sender, EventArgs e)
        {
            if (this.conn.State == ConnectionState.Closed) this.conn.Open();
            //string connectionString = @"Data source=VVS-PC;  Initial Catalog=InternetShopDB2; Integrated Security=SSPI";

            //INSERT INTO dbo.Input_Doc(Bill_Num, Data) VALUES(@Bill_Num, @Data); select ID from dbo.Input_Doc where [Data] = @Data and Bill_Num = @Bill_Num; ", conn))

            //добавление новой записи
            int num = Convert.ToInt32(BilNumTB.Text);
            DateTime date = DateTP.Value;
            string sqlExpression = "INSERT INTO dbo.Input_Doc(Bill_Num, Data,Client_id) VALUES(@Bill_Num, @Data,@Client_id);SET @id=SCOPE_IDENTITY()";
            using (conn)
            {
                SqlCommand command = new SqlCommand(sqlExpression, conn);
                // создаем параметр для имени
                command.Transaction = t;
                SqlParameter numParam = new SqlParameter("@Bill_Num", num);
                // добавляем параметр к команде
                command.Parameters.Add(numParam);
                // создаем параметр для возраста
                SqlParameter dateParam = new SqlParameter("@Data", date);
                // добавляем параметр к команде
                command.Parameters.Add(dateParam);
                // создаем параметр для клиента
                SqlParameter clientParam = new SqlParameter("@Client_id", ClientsID);
                // добавляем параметр к команде
                command.Parameters.Add(clientParam);
                // параметр для id
                SqlParameter idParam = new SqlParameter
                {
                    ParameterName = "@id",
                    SqlDbType = SqlDbType.Int,
                    Direction = ParameterDirection.Output // параметр выходной
                };
                command.Parameters.Add(idParam);
                command.ExecuteNonQuery();
                MessageBox.Show(idParam.Value.ToString());
                Input_Doc_ID = Convert.ToInt32(idParam.Value);
                //AddDocBtn.Visible = false;
                panel1.Visible = true;
                if (this.conn.State == ConnectionState.Closed) this.conn.Open();
                //GridR(conn);
            }
        }

        private void InputGoogsGridView_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            double price;
            int count;

            try
            {
                price = Convert.ToDouble(InputGoogsGridView.CurrentRow.Cells["Price"].Value.ToString());
            }
            catch
            {
                price = 0;
            };

            try
            {
                count = Convert.ToInt32(InputGoogsGridView.CurrentRow.Cells["Count"].Value.ToString());
            }
            catch
            {
                count = 0;
            };

        }

        private void Add_Btn_Click(object sender, EventArgs e) 
        {
            if (conn.State == ConnectionState.Closed) conn.Open();
            /*Input_doc_good i = new Input_doc_good(0);
            i.ShowDialog();
            int Goods_ID = i.Good_Id;
            int count = i.Good_Count;
            //if (conn.State == ConnectionState.Closed) conn.Open();
            if (i.ok == true) {
                double Price = i.Good_Price;
                string sqlExpression = "INSERT INTO dbo.Input_Goods(input_doc_id, goods_id,price,count) VALUES(@input_doc_id, @goods_id,@price,@count)";
                //if (Connection.State == ConnectionState.Closed) Connection.Open();
                using (conn)
                {
                    SqlCommand command = new SqlCommand(sqlExpression, conn);
                    command.Transaction = t;
            

                    // создаем параметр для имени
                    SqlParameter input_doc_idParam = new SqlParameter("@input_doc_id", Input_Doc_ID);
                    // добавляем параметр к команде
                    command.Parameters.Add(input_doc_idParam);
                    // создаем параметр для возраста
                    SqlParameter Goods_ID_Param = new SqlParameter("@goods_id", Goods_ID);
                    // добавляем параметр к команде
                    command.Parameters.Add(Goods_ID_Param);
                    // создаем параметр для клиента
                    SqlParameter priceParam = new SqlParameter("@price", Price);
                    // добавляем параметр к команде
                    command.Parameters.Add(priceParam);
                    // создаем параметр для клиента
                    SqlParameter countParam = new SqlParameter("@count", count);
                    // добавляем параметр к команде
                    command.Parameters.Add(countParam);
                    command.ExecuteNonQuery();
                    GridR(conn);
                }
            }*/

            //SqlCommand command = conn.CreateCommand();
            //command.Transaction = t;

            Input_doc_good i = new Input_doc_good(0);
            i.ShowDialog();
            int Goods_ID = i.Id;
            int count = i.Count;
            if (i.ok == true)
            {
                double Price = i.Price;
                string sqlExpression = "INSERT INTO dbo.Input_Goods(input_doc_id, goods_id,price,count) VALUES(@input_doc_id, @goods_id,@price,@count)";

                try
                {
                    using (conn)
                    {
                        //connection.Open();
                        SqlCommand command = new SqlCommand(sqlExpression, conn);
                        command.Transaction = t;

                        // создаем параметр для имени
                        SqlParameter input_doc_idParam = new SqlParameter("@input_doc_id", Input_Doc_ID);
                        // добавляем параметр к команде
                        command.Parameters.Add(input_doc_idParam);
                        // создаем параметр для возраста
                        SqlParameter Goods_ID_Param = new SqlParameter("@goods_id", Goods_ID);
                        // добавляем параметр к команде
                        command.Parameters.Add(Goods_ID_Param);
                        // создаем параметр для клиента
                        SqlParameter priceParam = new SqlParameter("@price", Price);
                        // добавляем параметр к команде
                        command.Parameters.Add(priceParam);
                        // создаем параметр для клиента
                        SqlParameter countParam = new SqlParameter("@count", count);
                        // добавляем параметр к команде
                        command.Parameters.Add(countParam);

                        int number = command.ExecuteNonQuery();
                        MessageBox.Show(number.ToString() + " rows affected by insert");
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            sqlDataAdapter = new SqlDataAdapter(GetSql(), conn);
            sqlDataAdapter.SelectCommand.Transaction = t;
            DataSet ds = new DataSet();
            sqlDataAdapter.Fill(ds/*, "dbo.Input_Goods"*/);
            InputGoogsGridView.DataSource = ds.Tables[0];
            InputGoogsGridView.Columns["Id"].ReadOnly = true;
            return;
            /*string sqlExpression ="INSERT INTO Input_Goods (input_doc_id, goods_id,price,count) VALUES(@input_doc_id, @goods_id,@price,@count)";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sqlExpression, connection);
                // создаем параметр 1
                SqlParameter Param1 = new SqlParameter("@input_doc_id", Input_Doc_ID);
                // добавляем параметр к команде
                command.Parameters.Add(Param1);
                // создаем параметр 2
                SqlParameter Param2 = new SqlParameter("@goods_id", Goods_ID);
                // добавляем параметр к команде
                command.Parameters.Add(Param2);
                // создаем параметр 3
                SqlParameter Param3 = new SqlParameter("@price", Price);
                // добавляем параметр к команде
                command.Parameters.Add(Param3);
                // создаем параметр 4
                SqlParameter Param4 = new SqlParameter("@count", count);
                // добавляем параметр к команде
                command.Parameters.Add(Param4);
                int number = command.ExecuteNonQuery();
                MessageBox.Show("Добавлено "+number.ToString()+ " строк");

                /*sqlDataAdapter = new SqlDataAdapter(GetSql(), connection);
                dataSet = new DataSet();
                sqlDataAdapter.Fill(dataSet, "dbo.Input_Goods");
                InputGoogsGridView.DataSource = dataSet.Tables[0];
                InputGoogsGridView.Columns["Id"].ReadOnly = true;
              }*/
      
        }

        private string GetSql()
        {
            return "SELECT IG.*,IG.price * IG.count as SUM,G.FNAME FROM dbo.Input_Goods IG,Goods G WHERE IG.Goods_id=G.ID and IG.Input_Doc_ID =" + Input_Doc_ID;
        }

        
        private void GridR(SqlConnection connection)
        {
            /*string w = "";
            InputGoogsGridView.DataSource = null;
            dataSet = CreateDataSet(" " + w); //установка фильтра
            InputGoogsGridView.DataSource = dataSet.Tables["dbo.Input_Goods"];*/
            //  GoodsDataGridView.CurrentCell= GoodsDataGridView.Rows[GoodsDataGridView.RowCount-1].Cells[0];
            if (connection.State == ConnectionState.Closed) connection.Open();
            sqlDataAdapter = new SqlDataAdapter(GetSql(), connection);
            sqlDataAdapter.SelectCommand.Transaction = t;
            DataSet ds = new DataSet();
            sqlDataAdapter.Fill(ds/*, "dbo.Input_Goods"*/);
            InputGoogsGridView.DataSource = ds.Tables[0];
            InputGoogsGridView.Columns["Id"].ReadOnly = true;
        }

        private double CalcSum(double VAT=-1)
        {
            string sqlExpression = "SELECT sum(IG.price * IG.count) as SUM FROM dbo.Input_Goods IG where Input_Doc_ID=@Input_Doc_ID";
            double sum = 0;

           // if (Connection.State == ConnectionState.Closed) Connection.Open();
            SqlCommand command = new SqlCommand(sqlExpression, conn);
            command.Transaction = t;
            // создаем параметр 1
            SqlParameter Param1 = new SqlParameter("@input_doc_id", Input_Doc_ID);
                //command.ExecuteNonQuery();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    // Класс SqlDataReader читает ряды и базы данных  
                    // по одному, по мере того, как их запрашиваем   
                    while (reader.Read())
                    {
                        sum = reader.GetInt32(0);//"sum"
                }
                }
                return sum;
        }

        private void Edit_Btn_Click(object sender, EventArgs e) 
        {
            // if (Connection.State == ConnectionState.Closed) Connection.Open();
            if (this.conn.State == ConnectionState.Closed) this.conn.Open();

            Input_doc_good i = new Input_doc_good(2); /*cmd=2 edit-bay*/
            i.Id = Convert.ToInt32(InputGoogsGridView.CurrentRow.Cells["Goods_ID"].Value);
            i.Name = InputGoogsGridView.CurrentRow.Cells["FName"].Value.ToString();
            //int Goods_ID = i.Good_id;
            i.Count = Convert.ToInt32(InputGoogsGridView.CurrentRow.Cells["Count"].Value);
            //i.Good_price= Convert.ToInt32(InputGoogsGridView.CurrentRow.Cells["Price"].Value.ToString());
            i.Price = Convert.ToDouble(InputGoogsGridView.CurrentRow.Cells["Price"].Value);
            
            int Id = Convert.ToInt32(InputGoogsGridView.CurrentRow.Cells["ID"].Value);
            int Goods_ID = Convert.ToInt32(InputGoogsGridView.CurrentRow.Cells["Goods_ID"].Value);
            int Count = Convert.ToInt32(InputGoogsGridView.CurrentRow.Cells["Count"].Value);
            double Price = Convert.ToDouble(InputGoogsGridView.CurrentRow.Cells["Price"].Value);
            i.ShowDialog();

            if (i.Id != Goods_ID||i.Count!=Count||i.Price!=Price)
            {
               // if (Connection.State == ConnectionState.Closed) Connection.Open();
                if (i.ok == true)
                {
                    string sqlExpression = "UPDATE dbo.Input_Goods set input_doc_id=@input_doc_id, goods_id=@goods_id, price=@price,count=@count where ID = @ID";
                    using (conn)
                    {
                        //                sqlConnection.Open();
                        //SqlTransaction transaction = sqlConnection.BeginTransaction();

                        SqlCommand command = new SqlCommand(sqlExpression, conn);
                        command.Transaction = t;
                        // создаем параметр для имени
                        SqlParameter id_doc_idParam = new SqlParameter("@ID", Id);
                        // добавляем параметр к команде
                        command.Parameters.Add(id_doc_idParam);
                        // создаем параметр для имени
                        SqlParameter input_doc_idParam = new SqlParameter("@input_doc_id", Input_Doc_ID);
                        // добавляем параметр к команде
                        command.Parameters.Add(input_doc_idParam);
                        // создаем параметр для возраста
                        SqlParameter Goods_ID_Param = new SqlParameter("@goods_id", i.Id);
                        // добавляем параметр к команде
                        command.Parameters.Add(Goods_ID_Param);
                        // создаем параметр для клиента
                        SqlParameter priceParam = new SqlParameter("@price", i.Price);
                        // добавляем параметр к команде
                        command.Parameters.Add(priceParam);
                        // создаем параметр для клиента
                        SqlParameter countParam = new SqlParameter("@count", i.Count);
                        // добавляем параметр к команде
                        command.Parameters.Add(countParam);

                        /*   // параметр для id
                           SqlParameter idParam = new SqlParameter
                          {
                              ParameterName = "@id",
                              SqlDbType = SqlDbType.Int,
                              Direction = ParameterDirection.Output // параметр выходной
                          };*/
                        //command.Parameters.Add(idParam);
                        //sqlConnection.Open();
                        command.ExecuteNonQuery();
                        /*MessageBox.Show(idParam.Value.ToString());
                        Input_Doc_ID = Convert.ToInt32(idParam.Value);
                        AddDocBtn.Visible = false;
                        panel1.Visible = true;*/
                        GridR(conn);
                    }
                }
            }

        }

        private void Sav_Btn_Click(object sender, EventArgs e)
        {
            try
            {
                
               t.Commit();
            }
            catch (Exception ex2)
            {
                MessageBox.Show("Error commit: "+ex2.Message);
            }
            this.Close();
            this.Dispose();
        }

        private void input_doc_ed_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                t.Rollback();
            }
            catch (Exception ex2)
            {
                MessageBox.Show("Error rollback: " + ex2.Message);
            }
        }

        private void input_doc_ed_Load(object sender, EventArgs e)
        {
            //if (Connection.State == ConnectionState.Closed) Connection.Open();
            if (Cmd == 1)
            {
                AddDocBtn.Visible = false;
                panel1.Visible = true;
                BilNumTB.Text = Convert.ToString(num);
                DateTP.Value = Date;
                ClientLab.Text = Client_Name;
                //Connection = new SqlConnection(connectionString);
                GridR(conn);
            }
            //GridR(sqlConnection);
        }

        private void Del_Btn_Click(object sender, EventArgs e)
        {
            //if (conn.State == ConnectionState.Closed) conn.Open();
        }
    }
}
