﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Town_Edit : Form
    {
        private SqlConnection sqlConnection = null;
        private SqlDataAdapter SqlDataAdapter = null;
        private SqlCommandBuilder SqlCommandBuilder = null;
        //операция
        private int op;
        private int id = -1;
        private string TName = "";
        

        
        public Town_Edit(int op_cmd, int IdVal=0, string NameVal = "")
        {
            op = op_cmd;
            TName = NameVal;
            id = IdVal;
            InitializeComponent();
        }

        private void AddBtn_Click(object sender, EventArgs e)
        {
            string connectionString = main.connectionString;
            switch (op) //операция
            {
                case 1: //добавление новой записи
                    string commandText = "INSERT INTO dbo.Towns (Name) VALUES (@Name);";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand command = new SqlCommand(commandText, connection);
                        command.Parameters.Add("@NAME", SqlDbType.VarChar);
                        command.Parameters["@NAME"].Value = NameTBox.Text;

                        

                        try
                        {
                            connection.Open();
                            Int32 rowsAffected = command.ExecuteNonQuery();
                            MessageBox.Show(rowsAffected.ToString() + " rows affected by insert");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }


                    break;
                case 2: //редактирование

                    commandText = "UPDATE dbo.Towns set Name=@Name" +
                                 " WHERE ID=@ID";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand command = new SqlCommand(commandText, connection);
                        command.Parameters.Add("@NAME", SqlDbType.VarChar);
                        command.Parameters["@NAME"].Value = NameTBox.Text;


                        command.Parameters.Add("@ID", SqlDbType.Int);
                        command.Parameters["@ID"].Value = id;

                        try
                        {
                            connection.Open();
                            Int32 rowsAffected = command.ExecuteNonQuery();
                            MessageBox.Show(rowsAffected.ToString() + " rows affected by update");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }

                    break;
                case 3: //удаление

                    using (SqlConnection conn = new
                           SqlConnection(connectionString))
                    {

                        conn.Open();
                        using (SqlCommand cmd = new SqlCommand("DELETE FROM dbo.Towns" +
                            " WHERE ID=@ID", conn))
                        using (SqlDataAdapter adapter = new SqlDataAdapter())
                        {
                            try
                            {
                                cmd.Parameters.Add(new SqlParameter("@ID", id));
                                // Здесь используется метод ExecuteNonQuery(), потому  
                                // что мы не выдаем запрос на чтение строк во время  
                                // вставки 
                                int rowsAffected = cmd.ExecuteNonQuery();
                                MessageBox.Show(rowsAffected.ToString() + " rows affected to delete");
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message);
                            }
                        }

                    }
                    break;

                default:
                    break;
            }

            this.Close();
            this.Dispose();
        }

        private void Town_Edit_Load(object sender, EventArgs e)
        {
            NameTBox.Text = TName;
        }
    }
    
}
