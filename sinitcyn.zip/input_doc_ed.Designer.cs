﻿
namespace WinFormsApp1
{
    partial class input_doc_ed
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.BilNumTB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.DateTP = new System.Windows.Forms.DateTimePicker();
            this.AddDocBtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.ClientLab = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button3 = new System.Windows.Forms.Button();
            this.Del_Btn = new System.Windows.Forms.Button();
            this.Edit_Btn = new System.Windows.Forms.Button();
            this.Add_Btn = new System.Windows.Forms.Button();
            this.InputGoogsGridView = new System.Windows.Forms.DataGridView();
            this.Save_Btn = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.InputGoogsGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "N";
            // 
            // BilNumTB
            // 
            this.BilNumTB.Location = new System.Drawing.Point(78, 26);
            this.BilNumTB.Name = "BilNumTB";
            this.BilNumTB.Size = new System.Drawing.Size(125, 27);
            this.BilNumTB.TabIndex = 1;
            this.BilNumTB.Text = ".";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(236, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 20);
            this.label2.TabIndex = 2;
            this.label2.Text = "Date";
            // 
            // DateTP
            // 
            this.DateTP.Location = new System.Drawing.Point(298, 28);
            this.DateTP.Name = "DateTP";
            this.DateTP.Size = new System.Drawing.Size(250, 27);
            this.DateTP.TabIndex = 3;
            // 
            // AddDocBtn
            // 
            this.AddDocBtn.Location = new System.Drawing.Point(630, 25);
            this.AddDocBtn.Name = "AddDocBtn";
            this.AddDocBtn.Size = new System.Drawing.Size(94, 29);
            this.AddDocBtn.TabIndex = 4;
            this.AddDocBtn.Text = "button1";
            this.AddDocBtn.UseVisualStyleBackColor = true;
            this.AddDocBtn.Click += new System.EventHandler(this.Ins_Btn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Client";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(78, 76);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(29, 29);
            this.button1.TabIndex = 6;
            this.button1.Text = "...";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ClientLab
            // 
            this.ClientLab.AutoSize = true;
            this.ClientLab.Location = new System.Drawing.Point(125, 85);
            this.ClientLab.Name = "ClientLab";
            this.ClientLab.Size = new System.Drawing.Size(18, 20);
            this.ClientLab.TabIndex = 7;
            this.ClientLab.Text = "...";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.Del_Btn);
            this.panel1.Controls.Add(this.Edit_Btn);
            this.panel1.Controls.Add(this.Add_Btn);
            this.panel1.Controls.Add(this.InputGoogsGridView);
            this.panel1.Location = new System.Drawing.Point(22, 146);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(766, 301);
            this.panel1.TabIndex = 8;
            this.panel1.Visible = false;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(652, 258);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(94, 29);
            this.button3.TabIndex = 4;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // Del_Btn
            // 
            this.Del_Btn.Location = new System.Drawing.Point(216, 258);
            this.Del_Btn.Name = "Del_Btn";
            this.Del_Btn.Size = new System.Drawing.Size(94, 29);
            this.Del_Btn.TabIndex = 3;
            this.Del_Btn.Text = "Delete";
            this.Del_Btn.UseVisualStyleBackColor = true;
            this.Del_Btn.Click += new System.EventHandler(this.Del_Btn_Click);
            // 
            // Edit_Btn
            // 
            this.Edit_Btn.Location = new System.Drawing.Point(115, 259);
            this.Edit_Btn.Name = "Edit_Btn";
            this.Edit_Btn.Size = new System.Drawing.Size(94, 29);
            this.Edit_Btn.TabIndex = 2;
            this.Edit_Btn.Text = "Edit";
            this.Edit_Btn.UseVisualStyleBackColor = true;
            this.Edit_Btn.Click += new System.EventHandler(this.Edit_Btn_Click);
            // 
            // Add_Btn
            // 
            this.Add_Btn.Location = new System.Drawing.Point(15, 259);
            this.Add_Btn.Name = "Add_Btn";
            this.Add_Btn.Size = new System.Drawing.Size(94, 29);
            this.Add_Btn.TabIndex = 1;
            this.Add_Btn.Text = "Add";
            this.Add_Btn.UseVisualStyleBackColor = true;
            this.Add_Btn.Click += new System.EventHandler(this.Add_Btn_Click);
            // 
            // InputGoogsGridView
            // 
            this.InputGoogsGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.InputGoogsGridView.Location = new System.Drawing.Point(15, 15);
            this.InputGoogsGridView.Name = "InputGoogsGridView";
            this.InputGoogsGridView.RowHeadersWidth = 51;
            this.InputGoogsGridView.RowTemplate.Height = 29;
            this.InputGoogsGridView.Size = new System.Drawing.Size(732, 224);
            this.InputGoogsGridView.TabIndex = 0;
            this.InputGoogsGridView.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.InputGoogsGridView_CellEndEdit);
            // 
            // Save_Btn
            // 
            this.Save_Btn.Location = new System.Drawing.Point(594, 518);
            this.Save_Btn.Name = "Save_Btn";
            this.Save_Btn.Size = new System.Drawing.Size(94, 29);
            this.Save_Btn.TabIndex = 9;
            this.Save_Btn.Text = "Save";
            this.Save_Btn.UseVisualStyleBackColor = true;
            this.Save_Btn.Click += new System.EventHandler(this.Sav_Btn_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(694, 518);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(94, 29);
            this.button2.TabIndex = 10;
            this.button2.Text = "Chancel";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // input_doc_ed
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 565);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Save_Btn);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.ClientLab);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.AddDocBtn);
            this.Controls.Add(this.DateTP);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BilNumTB);
            this.Controls.Add(this.label1);
            this.Name = "input_doc_ed";
            this.Text = "input_doc_ed";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.input_doc_ed_FormClosing);
            this.Load += new System.EventHandler(this.input_doc_ed_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.InputGoogsGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox BilNumTB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker DateTP;
        private System.Windows.Forms.Button AddDocBtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label ClientLab;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Del_Btn;
        private System.Windows.Forms.Button Add_Btn;
        private System.Windows.Forms.DataGridView InputGoogsGridView;
        private System.Windows.Forms.Button Save_Btn;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button Edit_Btn;
        private System.Windows.Forms.Button button3;
    }
}