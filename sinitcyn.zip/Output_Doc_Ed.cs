﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Output_Doc_Ed : Form
    {
        string connectionString = main.connectionString;

        private SqlConnection conn;
        private SqlDataAdapter sqlDataAdapter;
        private SqlCommandBuilder sqlCommandBuilder;

        private DataSet dataSet;
        private SqlTransaction t; 
        private int ClientsID = -1;
        private int Output_Doc_ID = -1;
        private int num = -1;
        private DateTime Date;
        private string Client_Name = "";
        private string R_Name = "";
        private string R_Address = "";
        private string R_Phone = "";
        private int cmd = 0;
        private double sum;
        public bool Commit = false;

        public Output_Doc_Ed(int cmd, int doc_id = -1)
        {
            conn = new SqlConnection(connectionString);
            conn.Open();
            t = conn.BeginTransaction();

            sqlDataAdapter = new SqlDataAdapter();
            Output_Doc_ID = doc_id;
            this.cmd = cmd;
            string sqlExpression="";
            sqlExpression = "select * from Requisites";
            SqlCommand command = new SqlCommand(sqlExpression, conn);
            command.Transaction = t;
            using (SqlDataReader reader = command.ExecuteReader())
            {
                while (reader.Read())
                {
                    R_Name = reader.GetString(1); //Название организации
                    R_Address = reader.GetString(2); //Адрес организации
                    R_Phone = reader.GetString(3); //Телефон организации

                }
            }

            switch (cmd)
            {
                case 0: //new
                    sqlExpression = "select COALESCE(max(OD.Bill_Num), 0) from dbo.Output_Doc OD";
                    command = new SqlCommand(sqlExpression, conn);
                    command.Transaction = t;
                    
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            num = reader.GetInt32(0)+1; //Bill_num следующий номер
                        }
                    }
                    break;
                case 1: //edit
                    sqlExpression = "select OD.*, C.FName from dbo.Output_Doc OD, dbo.Clients C where OD.ID = @ID and OD.client_id = C.ID";
                    SqlCommand command1 = new SqlCommand(sqlExpression, conn);
                    command1.Transaction = t;
                    // создаем параметр для имени
                    SqlParameter idParam = new SqlParameter("@ID", Output_Doc_ID);
                    // добавляем параметр к команде
                    command1.Parameters.Add(idParam);

                    using (SqlDataReader reader = command1.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            num = reader.GetInt32(1); //"Bill_num"
                            Client_Name = reader.GetString(6);//"FName"
                            ClientsID = reader.GetInt32(5); //"Client_ID"
                            Date = reader.GetDateTime(4);//"Data"
                        }
                    }
                    break;
            }
            InitializeComponent();
            //Set_ColumnHeader(); //изменить заголовки столбцов
        }

        private string GetSql()
        {
            //return "SELECT OG.*,OG.price * OG.count as SUM,G.FNAME FROM dbo.Output_Goods OG,Goods G WHERE OG.Goods_id=G.ID and OG.Output_Doc_ID =" + Output_Doc_ID;
            /*  return "SELECT OG.*,OG.price * OG.count as SUM,G.FNAME,cast(OG.PRICE/(100+G.VAT)*G.VAT*OG.count as numeric(10,2)) as S_VAT, cast((OG.PRICE - (OG.PRICE / (100 + G.VAT) * G.VAT)) as numeric(10, 2)) as PRICE_WV FROM dbo.Output_Goods OG, Goods G WHERE OG.Goods_id = G.ID and OG.Output_Doc_ID=" + Output_Doc_ID;*/
            return "SELECT OG.*,OG.price * OG.count as SUM,G.FNAME,G.VAT,cast((OG.Price * OG.Count) / (100 + G.VAT) *G.VAT as numeric(10, 2)) as S_VAT FROM dbo.Output_Goods OG, Goods G WHERE OG.Goods_id = G.ID and OG.Output_Doc_ID =" + Output_Doc_ID;
        }

        private void UpdateSum(int id, int num, DateTime date, int ClientsID, double sum, double VAT)
        {
            string sqlExpression = "UPDATE dbo.Output_Doc set Bill_Num=@Bill_Num, Data=@Data,Client_id=@Client_id,sum=@sum,VAT=@VAT where ID=@ID";
            try
            {
                SqlCommand commandadd = new SqlCommand(sqlExpression, conn);
                commandadd.Transaction = t;
                SqlParameter idParam = new SqlParameter("@ID", id);
                // добавляем параметр к команде
                commandadd.Parameters.Add(idParam);
                SqlParameter numParam = new SqlParameter("@Bill_Num", num);
                // добавляем параметр к команде
                commandadd.Parameters.Add(numParam);
                // создаем параметр для возраста
                SqlParameter dateParam = new SqlParameter("@Data", date);
                // добавляем параметр к команде
                commandadd.Parameters.Add(dateParam);
                // создаем параметр для клиента
                SqlParameter clientParam = new SqlParameter("@Client_id", ClientsID);
                // добавляем параметр к команде
                commandadd.Parameters.Add(clientParam);

                CalcSum(ref sum, ref VAT);

                // создаем параметр для суммы
                SqlParameter sumParam = new SqlParameter("@SUM", sum);
                // добавляем параметр к команде
                commandadd.Parameters.Add(sumParam);
                // создаем параметр для НДС
                SqlParameter VatParam = new SqlParameter("@VAT", VAT);
                // добавляем параметр к команде
                commandadd.Parameters.Add(VatParam);
                int rowsAffected = commandadd.ExecuteNonQuery();
                MessageBox.Show(rowsAffected.ToString() + " rows affected by update id=" + id.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GridR()
        {
            sqlDataAdapter = new SqlDataAdapter(GetSql(), conn);
            sqlDataAdapter.SelectCommand.Transaction = t;
            /*DataSet ds = new DataSet();
            sqlDataAdapter.Fill(ds);*/
            //добавление моего нового
            dataSet = new DataSet();
            sqlDataAdapter.Fill(dataSet); 
            OutputGoogsGridView.DataSource = dataSet.Tables[0];
            OutputGoogsGridView.Columns["Id"].ReadOnly = true;
        }

        private void Set_ColumnHeader()
        {
            /*скрытие*/
            OutputGoogsGridView.Columns["ID"].Visible = false;
            OutputGoogsGridView.Columns["Output_Doc_ID"].Visible = false;
            OutputGoogsGridView.Columns["Goods_ID"].Visible = false;
            /*переименовывание*/
            OutputGoogsGridView.Columns["FNAME"].DisplayIndex = 0;
            OutputGoogsGridView.Columns["FNAME"].HeaderText = "Название";
            OutputGoogsGridView.Columns["Count"].DisplayIndex = 1;
            OutputGoogsGridView.Columns["Count"].HeaderText = "Количество";
            OutputGoogsGridView.Columns["Price"].DisplayIndex = 2;
            OutputGoogsGridView.Columns["Price"].HeaderText = "Цена";
            OutputGoogsGridView.Columns["Price"].CellTemplate.Style.Format = "N2";
            OutputGoogsGridView.Columns["SUM"].DisplayIndex = 3;
            OutputGoogsGridView.Columns["SUM"].HeaderText = "Сумма";
            OutputGoogsGridView.Columns["SUM"].CellTemplate.Style.Format = "N2";
            OutputGoogsGridView.Columns["VAT"].DisplayIndex = 4;
            OutputGoogsGridView.Columns["VAT"].HeaderText = "НДС%";
            OutputGoogsGridView.Columns["S_VAT"].DisplayIndex = 5;
            OutputGoogsGridView.Columns["S_VAT"].HeaderText = "В т.ч. НДС";
            OutputGoogsGridView.Columns["S_VAT"].CellTemplate.Style.Format = "N2";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Clients c = new Clients(1);
            c.ShowDialog();
            if (c.client_id > -1)
            {
                ClientsID = c.client_id;
                ClientLab.Text = c.client_name;
                Client_Name= c.client_name;

            }
            return;
        }

        

        /*new doc*/
        private void NewDocBtn_Click(object sender, EventArgs e)
        {
            if (cmd == 0)
            {
                if (ClientsID == -1) return;
                string sqlExpression = "INSERT INTO dbo.Output_Doc(Bill_Num, Data,Client_id) VALUES(@Bill_Num, @Data,@Client_id);SET @id=SCOPE_IDENTITY()";
                try
                {
                    int num = Convert.ToInt32(BilNumTB.Text);
                    DateTime date = DateTP.Value;
                    Date = DateTP.Value;

                    SqlCommand commandadd = new SqlCommand(sqlExpression, conn);
                    commandadd.Transaction = t;
                    SqlParameter numParam = new SqlParameter("@Bill_Num", num);
                    // добавляем параметр к команде
                    commandadd.Parameters.Add(numParam);
                    // создаем параметр для возраста
                    SqlParameter dateParam = new SqlParameter("@Data", date);
                    // добавляем параметр к команде
                    commandadd.Parameters.Add(dateParam);
                    // создаем параметр для клиента
                    SqlParameter clientParam = new SqlParameter("@Client_id", ClientsID);
                    // добавляем параметр к команде
                    commandadd.Parameters.Add(clientParam);
                    // параметр для id
                    SqlParameter idParam = new SqlParameter
                    {
                        ParameterName = "@id",
                        SqlDbType = SqlDbType.Int,
                        Direction = ParameterDirection.Output // параметр выходной
                    };
                    commandadd.Parameters.Add(idParam);

                    int rowsAffected = commandadd.ExecuteNonQuery();
                    Output_Doc_ID = Convert.ToInt32(idParam.Value);
                    MessageBox.Show(rowsAffected.ToString() + " rows affected by insert id=" + idParam.Value.ToString());
                    GridR();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            if (cmd==1)
            {
                string sqlExpression = "UPDATE dbo.Output_Doc set Bill_Num=@Bill_Num, Data=@Data,Client_id=@Client_id where ID=@ID;";
                try
                {
                    int num = Convert.ToInt32(BilNumTB.Text);
                    DateTime date = DateTP.Value;

                    SqlCommand commandadd = new SqlCommand(sqlExpression, conn);
                    commandadd.Transaction = t;
                    SqlParameter numParam = new SqlParameter("@Bill_Num", num);
                    // добавляем параметр к команде
                    commandadd.Parameters.Add(numParam);
                    // создаем параметр для возраста
                    SqlParameter dateParam = new SqlParameter("@Data", date);
                    // добавляем параметр к команде
                    commandadd.Parameters.Add(dateParam);
                    // создаем параметр для клиента
                    SqlParameter clientParam = new SqlParameter("@Client_id", ClientsID);
                    // добавляем параметр к команде
                    commandadd.Parameters.Add(clientParam);
                    // параметр для id
                    SqlParameter idParam = new SqlParameter("@id", Output_Doc_ID);
                    // добавляем параметр к команде
                    commandadd.Parameters.Add(idParam);

                    int rowsAffected = commandadd.ExecuteNonQuery();
                    MessageBox.Show(rowsAffected.ToString() + " rows affected");
                    GridR();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private double CalcSum(ref double sum, ref double VAT) //сумма накладной
        {
            string sqlExpression = "SELECT sum(OG.price * OG.count) as SUM, sum(OG.PRICE/(100+G.VAT)*G.VAT*OG.count) as S_VAT  FROM dbo.Output_Goods OG,Goods G WHERE OG.Goods_id = G.ID and OG.Output_Doc_ID = @Output_Doc_ID";
            //double sum = 0;
            SqlCommand command = new SqlCommand(sqlExpression, conn);
            command.Transaction = t;
            SqlParameter Param1 = new SqlParameter("@output_doc_id", Output_Doc_ID);
            command.Parameters.Add(Param1);

            using (SqlDataReader reader = command.ExecuteReader())
            {

                /*if (!reader.IsDBNull(0))
                {
                    sum = Convert.ToDouble(reader.GetDecimal(0)); //"sum"
                }
                else
                {
                    sum = 0;
                }*/

                /*while (reader.Read())
                {
                    sum = Convert.ToDouble(reader.GetDecimal(0));//"sum"
                }*/
                while (reader.Read())
                {
                    if (!reader.IsDBNull(0))
                    {
                        sum = Convert.ToDouble(reader.GetDecimal(0)); //"sum"
                        VAT = Math.Round(Convert.ToDouble(reader.GetDecimal(1)),2); //"VAT"
                    }
                    else
                    {
                        sum = 0;
                        VAT = 0; 
                    }
                    
                }
            }
            return sum;
        }

        private void new_good_btn_Click(object sender, EventArgs e)
        {
            if (Output_Doc_ID == -1)
            {
                MessageBox.Show("Создайте документ для заполнения табличной части.");
                return;
            }
            Input_doc_good i = new Input_doc_good(0);
            i.ShowDialog();
            if (i.ok == true)
            {
                int Goods_ID = i.Id;
                int Count = i.Count;
                double Price = i.Price;
                int Good_Stock = 0;
                int Good_Count_NEW = Count;
                int Good_Count_Old = 0;
                

                string sqlExpression = "select * from Goods where ID=@ID";
                SqlCommand command = new SqlCommand(sqlExpression, conn);
                SqlParameter idParam = new SqlParameter("@ID", Goods_ID);
                command.Transaction = t;
                command.Parameters.Add(idParam);
                using (SqlDataReader reader = command.ExecuteReader())
                {

                    while (reader.Read())
                    {
                        Good_Stock = reader.GetInt32(5); //остаток
                    }
                }

                if (Good_Stock + Good_Count_Old - Count < 0)
                {
                    MessageBox.Show("У товара расчитается оcтаток < 0 !");
                    return;
                }

                sqlExpression = "INSERT INTO dbo.Output_Goods(output_doc_id, goods_id,price,count) VALUES(@output_doc_id, @goods_id,@price,@count)";
                try
                {
                    SqlCommand command2 = new SqlCommand();
                    command2.Connection = conn;
                    //SqlCommand command = new SqlCommand(sqlExpression, conn);
                    command2.CommandText = sqlExpression;
                    command2.Transaction = t;
                    // создаем параметр для имени
                    SqlParameter input_doc_idParam = new SqlParameter("@output_doc_id", Output_Doc_ID);
                    // добавляем параметр к команде
                    command2.Parameters.Add(input_doc_idParam);
                    // создаем параметр для возраста
                    SqlParameter Goods_ID_Param = new SqlParameter("@goods_id", Goods_ID);
                    // добавляем параметр к команде
                    command2.Parameters.Add(Goods_ID_Param);
                    // создаем параметр для клиента
                    SqlParameter priceParam = new SqlParameter("@price", Price);
                    // добавляем параметр к команде
                    command2.Parameters.Add(priceParam);
                    // создаем параметр для клиента
                    SqlParameter countParam = new SqlParameter("@count", Count);
                    // добавляем параметр к команде
                    command2.Parameters.Add(countParam);
                    int number = command2.ExecuteNonQuery();
                    MessageBox.Show(number.ToString() + " rows affected by insert");
                    GridR();
                    double sum = -1, VAT = -1;
                    CalcSum(ref sum, ref VAT);
                    //Sum_lbl.Text = CalcSum().ToString();
                    Sum_lbl.Text = sum.ToString();
                    VatLbl.Text = VAT.ToString();
                    //DataGridViewCell d = InputGoogsGridView.Rows[InputGoogsGridView.Rows.Count-1].Cells["Price"];
                    OutputGoogsGridView.CurrentCell = OutputGoogsGridView.Rows[OutputGoogsGridView.Rows.Count - 1].Cells["Price"];

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }

        private void ed_good_btn_Click(object sender, EventArgs e) //редактирование записи табличной части
        {
            OutputGoogsGridView.Focus();
            //int Id = Convert.ToInt32(OutputGoogsGridView.CurrentRow.Cells["ID"].Value);
            int Id=Convert.ToInt32(dataSet.Tables[0].Rows[OutputGoogsGridView.CurrentRow.Index]["ID"].ToString());
            //int Goods_ID = Convert.ToInt32(OutputGoogsGridView.CurrentRow.Cells["Goods_ID"].Value);
            int Goods_ID = Convert.ToInt32(dataSet.Tables[0].Rows[OutputGoogsGridView.CurrentRow.Index]["Goods_ID"].ToString());
            //int Count = Convert.ToInt32(OutputGoogsGridView.CurrentRow.Cells["Count"].Value);
            int Count = Convert.ToInt32(dataSet.Tables[0].Rows[OutputGoogsGridView.CurrentRow.Index]["Count"].ToString());
            //double Price = Convert.ToDouble(OutputGoogsGridView.CurrentRow.Cells["Price"].Value);
            double Price = Convert.ToDouble(dataSet.Tables[0].Rows[OutputGoogsGridView.CurrentRow.Index]["Price"].ToString());

            //int id = Id;
            Input_doc_good i = new Input_doc_good(4, Goods_ID/*id*/); /*cmd=2 edit*/
            i.Id = Convert.ToInt32(OutputGoogsGridView.CurrentRow.Cells["GOODS_ID"].Value);

            i.Name = OutputGoogsGridView.CurrentRow.Cells["FName"].Value.ToString();
            i.Count = Convert.ToInt32(OutputGoogsGridView.CurrentRow.Cells["Count"].Value);
            i.Price = Convert.ToDouble(OutputGoogsGridView.CurrentRow.Cells["Price"].Value);
            //i.Id = Convert.ToInt32(OutputGoogsGridView.CurrentRow.Cells["ID"].Value);
            /*i.Id = Id;
            //i.Good_Id = Convert.ToInt32(OutputGoogsGridView.CurrentRow.Cells["Goods_ID"].Value);
            i.Good_Id = Goods_ID;
            //i.Good_Name = OutputGoogsGridView.CurrentRow.Cells["FName"].Value.ToString();
            i.Good_Name = dataSet.Tables[0].Rows[OutputGoogsGridView.CurrentRow.Index]["FNAME"].ToString();
            //i.Good_Count = Convert.ToInt32(OutputGoogsGridView.CurrentRow.Cells["Count"].Value);
            i.Good_Count = Count;
            //i.Good_Price = Convert.ToDouble(OutputGoogsGridView.CurrentRow.Cells["Price"].Value);
            i.Good_Price = Price;*/


            i.ShowDialog();

            if (i.Id != Goods_ID || i.Count != Count || i.Price != Price) //если изменилась
            {
                if (i.ok == true)
                {
                    try
                    {
                        string sqlExpression = "UPDATE dbo.Output_Goods set goods_id=@goods_id, price=@price,count=@count where ID = @ID";
                        SqlCommand command = new SqlCommand(sqlExpression, conn);
                        command.Transaction = t;
                        // создаем параметр для имени
                        SqlParameter id_doc_idParam = new SqlParameter("@ID", Id);
                        // добавляем параметр к команде
                        command.Parameters.Add(id_doc_idParam);
                        // создаем параметр для возраста
                        SqlParameter Goods_ID_Param = new SqlParameter("@goods_id", i.Id);
                        // добавляем параметр к команде
                        command.Parameters.Add(Goods_ID_Param);
                        // создаем параметр для клиента
                        SqlParameter priceParam = new SqlParameter("@price", i.Price);
                        // добавляем параметр к команде
                        command.Parameters.Add(priceParam);
                        // создаем параметр для клиента
                        SqlParameter countParam = new SqlParameter("@count", i.Count);
                        // добавляем параметр к команде
                        command.Parameters.Add(countParam);
                        command.ExecuteNonQuery();
                        GridR();
                        //Sum_lbl.Text = CalcSum().ToString();
                        double sum = -1, VAT = -1;
                        CalcSum(ref sum, ref VAT);
                        Sum_lbl.Text = sum.ToString();
                        VatLbl.Text = VAT.ToString();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
            }
        }

        private void del_good_btn_Click(object sender, EventArgs e)
        {
            //int Id = Convert.ToInt32(OutputGoogsGridView.CurrentRow.Cells["ID"].Value);
            int Id = Convert.ToInt32(dataSet.Tables[0].Rows[OutputGoogsGridView.CurrentRow.Index]["ID"].ToString());
            int Goods_Id = Convert.ToInt32(dataSet.Tables[0].Rows[OutputGoogsGridView.CurrentRow.Index]["GOODS_ID"].ToString());


            try
            {
                string sqlExpression = "DELETE from dbo.Output_Goods where ID = @ID";
                SqlCommand command = new SqlCommand(sqlExpression, conn);
                command.Transaction = t;
                // создаем параметр для имени
                SqlParameter id_doc_idParam = new SqlParameter("@ID", Id);
                // добавляем параметр к команде
                command.Parameters.Add(id_doc_idParam);
                command.ExecuteNonQuery();
                GridR();
                Recalc_Doc_Stocks(Goods_Id);
                double sum = -1, VAT = -1;
                CalcSum(ref sum, ref VAT);
                Sum_lbl.Text = sum.ToString();
                VatLbl.Text = VAT.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void RecalcSaldo()
        {
           /* string sqlExpression = "update GOODS set Balance=((select COALESCE(sum(count),0) from Input_Goods IG where IG.Goods_ID=GOODS.ID)-(select COALESCE(sum(count),0) from Output_Goods OG where OG.Goods_ID=GOODS.ID))";

            try
            {
                SqlCommand command = new SqlCommand(sqlExpression, conn);
                command.Transaction = t;
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }*/
        }

        private void UpdateSum(int id, int num, DateTime date, int ClientsID/*, double sum, double VAT*/)
        {
            string sqlExpression = "UPDATE dbo.Output_Doc set Bill_Num=@Bill_Num, Data=@Data,Client_id=@Client_id,sum=@sum,VAT=@VAT where ID=@ID";
            double sum = 0;
            double VAT = 0;
            try
            {
                SqlCommand commandadd = new SqlCommand(sqlExpression, conn);
                commandadd.Transaction = t;
                SqlParameter idParam = new SqlParameter("@ID", id);
                // добавляем параметр к команде
                commandadd.Parameters.Add(idParam);
                SqlParameter numParam = new SqlParameter("@Bill_Num", num);
                // добавляем параметр к команде
                commandadd.Parameters.Add(numParam);
                // создаем параметр для возраста
                SqlParameter dateParam = new SqlParameter("@Data", date);
                // добавляем параметр к команде
                commandadd.Parameters.Add(dateParam);
                // создаем параметр для клиента
                SqlParameter clientParam = new SqlParameter("@Client_id", ClientsID);
                // добавляем параметр к команде
                commandadd.Parameters.Add(clientParam);
                CalcSum(ref sum, ref VAT);
                // создаем параметр для суммы
                SqlParameter sumParam = new SqlParameter("@SUM", sum);
                // добавляем параметр к команде
                commandadd.Parameters.Add(sumParam);
                // создаем параметр для НДС
                SqlParameter VatParam = new SqlParameter("@VAT", VAT);
                // добавляем параметр к команде
                commandadd.Parameters.Add(VatParam);
                int rowsAffected = commandadd.ExecuteNonQuery();
                MessageBox.Show(rowsAffected.ToString() + " rows affected by update id=" + id.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Recalc_Doc_Stocks(int Goods_Id = -1)
        {
            string sqlExpression = "EXEC [dbo].[RECALC_STOCK] @GOODS_ID";
            SqlCommand command = new SqlCommand();
            SqlParameter Goods_ID_Param = new SqlParameter("@goods_id", 1);
            command.Connection = conn;
            command.CommandText = sqlExpression;
            command.Transaction = t;
            if (Goods_Id > -1)
            {
                // int ID = Convert.ToInt32(InputGoogsGridView.Rows[j].Cells["Goods_id"].Value);
                Goods_ID_Param = new SqlParameter("@goods_id", Goods_Id);

                try
                {
                    // создаем параметр для имени
                    // добавляем параметр к команде
                    command.Parameters.Clear();
                    command.Parameters.Add(Goods_ID_Param);
                    int number = command.ExecuteNonQuery();
                    MessageBox.Show(number.ToString() + " rows affected by insert");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else

                for (int j = 0; j < OutputGoogsGridView.Rows.Count; j++)
                {
                    int ID = Convert.ToInt32(OutputGoogsGridView.Rows[j].Cells["Goods_id"].Value);
                    Goods_ID_Param = new SqlParameter("@goods_id", ID);

                    try
                    {
                        // создаем параметр для имени
                        command.Parameters.Clear();
                        command.Parameters.Add(Goods_ID_Param);
                        int number = command.ExecuteNonQuery();
                        MessageBox.Show(number.ToString() + " rows affected by insert");
                        /*                    GridR();
                                            double sum = -1, VAT = -1;
                                            CalcSum(ref sum, ref VAT);
                                            //Sum_lbl.Text = CalcSum().ToString();
                                            Sum_lbl.Text = sum.ToString();
                                            VatLbl.Text = VAT.ToString();
                                            //DataGridViewCell d = InputGoogsGridView.Rows[InputGoogsGridView.Rows.Count-1].Cells["Price"];
                                            InputGoogsGridView.CurrentCell = InputGoogsGridView.Rows[InputGoogsGridView.Rows.Count - 1].Cells["Price"];*/

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                }
        }

        private void button1_Click(object sender, EventArgs e)
        {   /*try
            {   if (cmd==1) NewDocBtn_Click(null, null);
                t.Commit();
            }
            catch (Exception ex2)
            {
                MessageBox.Show("Error commit: " + ex2.Message);
            }
            this.Close();
            this.Dispose();*/
            num = Convert.ToInt32(BilNumTB.Text);
            Date = DateTP.Value;
            ///RecalcSaldo();
            double sum = -1, VAT = -1;
            CalcSum(ref sum, ref VAT);
            Recalc_Doc_Stocks();
            UpdateSum(Output_Doc_ID, num, Date, ClientsID/*, sum, VAT*/);
            ///RecalcSaldo();
            try
            {
                t.Commit();
                Commit = true;
            }
            catch (Exception ex2)
            {
                MessageBox.Show("Error commit: " + ex2.Message);
                Commit = false;
            }
            this.Close();
            this.Dispose();
        }

        private void Output_Doc_Ed_Load(object sender, EventArgs e)
        {
            if (cmd == 0)
                BilNumTB.Text = Convert.ToString(num);
            if (cmd == 1)
            {
                BilNumTB.Text = Convert.ToString(num);
                DateTP.Value = Date;
                ClientLab.Text = Client_Name;
                GridR();
                //sum = CalcSum();
                //Sum_lbl.Text = Convert.ToString(sum);
                double sum = -1, VAT = -1;
                CalcSum(ref sum, ref VAT);
                Sum_lbl.Text = sum.ToString();
                VatLbl.Text = VAT.ToString();
            }
            if (cmd == 2)
            {
                BilNumTB.Text = Convert.ToString(num);
            }
            if (cmd == 3)
            {
                BilNumTB.Text = Convert.ToString(num);
                DateTP.Value = Date;
                ClientLab.Text = Client_Name;
                GridR();
                //sum = CalcSum();
                //Sum_lbl.Text = Convert.ToString(sum);
                double sum = -1, VAT = -1;
                CalcSum(ref sum, ref VAT);
                Sum_lbl.Text = sum.ToString();
                VatLbl.Text = VAT.ToString();
            }
            //Set_ColumnHeader();
        }

        private void chancel_btn_Click(object sender, EventArgs e) //кнопка отмены
        {
            try
            {
                t.Rollback();
            }
            catch (Exception ex2)
            {
                MessageBox.Show("Error rollback: " + ex2.Message);
            }
            Commit = false;

            this.Close();
            this.Dispose();
        }

        private void Prn_btn_Click(object sender, EventArgs e) //предварительный просмотр печати
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e) //формирование печатного листа
        {
                   
            int w = OutputGoogsGridView.Size.Width;
            int h= OutputGoogsGridView.Size.Height;
            Bitmap bmp = new Bitmap(w, h);
            OutputGoogsGridView.DrawToBitmap(bmp, OutputGoogsGridView.Bounds);

            // Create pen.
            Pen blackPen = new Pen(Color.Black, 3);

                       
            string sqlExpression = "SELECT OG.*,OG.price * OG.count as SUM,G.FNAME FROM dbo.Output_Goods OG,Goods G WHERE OG.Goods_id=G.ID AND OG.OUTPUT_DOC_ID=@output_doc_id" ;


            string fname = "";
            double price = 0;
            int count = 0;
            double sum = 0;
            double sum_itog = 0;

            SqlCommand command = new SqlCommand(sqlExpression, conn);
            command.Transaction = t;
            SqlParameter Param1 = new SqlParameter("@output_doc_id", Output_Doc_ID);
            command.Parameters.Add(Param1);

            int s = 300;
            // Create location and size of rectangle.
            int x = 30;
            int y = 30;
            int width = 300;
            int height = 50;

            using (SqlDataReader reader = command.ExecuteReader())
            {
                int top = 50;
                /*заголовок*/
                e.Graphics.DrawRectangle(blackPen, 15, 45, width+500, 1);
                e.Graphics.DrawString(R_Address.ToString() + " т. " + R_Phone.ToString(), new Font("Arial", 18, FontStyle.Bold), Brushes.Black, 220, top); 
                top = top + 50;
                e.Graphics.DrawString(R_Name, new Font("Arial", 18, FontStyle.Bold), Brushes.Black, 65, top);
                top = top + 100;
                e.Graphics.DrawString("Накладная № "+num.ToString()+ " от "+Date.ToShortDateString(), new Font("Arial", 18, FontStyle.Bold), Brushes.Black, 220, top); top = top + 50;
                
                e.Graphics.DrawString("Покупатель: " + Client_Name, new Font("Arial", 18, FontStyle.Bold), Brushes.Black, 65, top);
                /*шапка таблицы*/
                e.Graphics.DrawString("Наименование", new Font("Arial", 12,FontStyle.Bold | FontStyle.Italic), Brushes.Black, 65, s-22);
                e.Graphics.DrawRectangle(blackPen, 65, s-22, 400, 20);
                
                e.Graphics.DrawString("Цена", new Font("Arial", 12, FontStyle.Bold | FontStyle.Italic), Brushes.Black, 465, s-22);
                e.Graphics.DrawRectangle(blackPen, 465, s - 22, 100, 20);
                
                e.Graphics.DrawString("Кол-во", new Font("Arial", 12, FontStyle.Bold | FontStyle.Italic), Brushes.Black, 565, s-22);
                e.Graphics.DrawRectangle(blackPen, 565, s - 22, 100, 20);
                
                e.Graphics.DrawString("Сумма", new Font("Arial", 12, FontStyle.Bold | FontStyle.Italic), Brushes.Black, 665, s-22);
                e.Graphics.DrawRectangle(blackPen, 665, s - 22, 100, 20);
                /*табличная часть*/
                while (reader.Read())
                {
                    fname = reader.GetString(6);//"FNAME"
                    price = Convert.ToDouble(reader.GetDecimal(3));//"price"
                    count = Convert.ToInt32(reader.GetInt32(4));//"count"
                    sum = Convert.ToDouble(reader.GetDecimal(5));//"sum"
                    e.Graphics.DrawString(fname, new Font("Arial", 12), Brushes.Black, 65, s);
                    e.Graphics.DrawRectangle(blackPen, 65, s-1, 400, 20);
                    
                    e.Graphics.DrawString(price.ToString(), new Font("Arial", 12), Brushes.Black, 465, s);
                    e.Graphics.DrawRectangle(blackPen, 465, s - 1, 100, 20);

                    e.Graphics.DrawString(count.ToString(), new Font("Arial", 12), Brushes.Black, 565, s);
                    e.Graphics.DrawRectangle(blackPen, 565, s - 1, 100, 20);

                    e.Graphics.DrawString(sum.ToString(), new Font("Arial", 12), Brushes.Black, 665, s);
                    e.Graphics.DrawRectangle(blackPen, 665, s - 1, 100, 20);

                    s = s + 20;
                    sum_itog = sum_itog + sum;
                }
                /*итог*/
                e.Graphics.DrawString("Итого: " + sum_itog.ToString()
                + " р.", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, 640, s + 10);
            /*}
                //итог
                e.Graphics.DrawString("Итого: "+ sum.ToString() + " р.", new Font("Arial", 12, FontStyle.Bold), Brushes.Black, 640, s+10);*/
            }
        }

        private void OutputGoogsGridView_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            Set_ColumnHeader(); //изменить заголовки столбцов после загрузки данных           
        }
    }
}
