﻿using System;
using System.Windows.Forms.DataVisualization.Charting;

using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class diag_form : Form
    {
        private SqlConnection conn = null;
        private SqlDataAdapter sqlDataAdapter = null;
        private SqlCommandBuilder sqlCommandBuilder = null;
        string connectionString = main.connectionString;

        public diag_form()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e) //построить
        {
            conn = new SqlConnection(connectionString);
            conn.Open();
            string sqlExpression = "select *  from Goods";

            using (conn)
            {
                SqlCommand cmd = new SqlCommand(sqlExpression, conn);
                
                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    adapter.SelectCommand = cmd;
                    DataSet ds = new DataSet();
                    adapter.Fill(ds);
                }

                SqlDataReader reader = cmd.ExecuteReader();

                int x = 1;
                int y;
                
                Series S = new Series();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        y = reader.GetInt32(5);
                        chart1.Series[0].Points.AddXY(x, y);
                        chart1.Series[0].Points[((int)x - 1)].LegendText = reader.GetString(1) + "=" + y.ToString();
                        chart1.Series[0].Points[((int)x - 1)].Label=  y.ToString();
                        chart1.Series[0].Points[((int)x - 1)].AxisLabel = reader.GetString(1);
                        x = x + 1;
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e) //предварительный просмотр печати
        {
            PrintPreviewDialog ppd = new PrintPreviewDialog();
            chart1.Series[0].ChartType = SeriesChartType.Column;
            

            ppd.Document = this.chart1.Printing.PrintDocument;
            ppd.ShowDialog();
        }

        
    }
}
