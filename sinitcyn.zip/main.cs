﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TSN_CSh_lab6;

namespace WinFormsApp1
{
    public partial class main : Form
    {
        public static string connectionString = @"Server=.\SQLEXPRESS;Database=InternetShopDB32;TrustServerCertificate=True;Trusted_Connection=True;";
        public const string FILE_NAME = "My_Set.ini"; // Имя файла настроек

        public main()
        {
            IniFile MyIni = new IniFile(FILE_NAME);
            connectionString = MyIni.ReadKey("connectionString", "Base");
            InitializeComponent();
        }

        private void InDocMenuItem_Click(object sender, EventArgs e)
        {
            Input_Doc InForm = new Input_Doc(0);
            // Set the Parent Form of the Child window.
            InForm.MdiParent = this;
            InForm.Show();
        }

        private void OutDocMenuItem_Click(object sender, EventArgs e)
        {
            Output_Doc OutForm = new Output_Doc(0);
            // Set the Parent Form of the Child window.
            OutForm.MdiParent = this;
            OutForm.Show();
        }

        private void GoodsMenuItem_Click(object sender, EventArgs e)
        {
            Goods GoodsForm = new Goods(0);
            // Set the Parent Form of the Child window.
            GoodsForm.MdiParent = this;
            GoodsForm.Show();
        }

        private void ClientsMenuItem_Click(object sender, EventArgs e)
        {
            Clients ClientsForm = new Clients(0);
            // Set the Parent Form of the Child window.
            ClientsForm.MdiParent = this;
            ClientsForm.Show();
        }

        private void CountRepMenuItem_Click(object sender, EventArgs e)
        {
            diag_form diagForm = new diag_form();
            // Set the Parent Form of the Child window.
            diagForm.MdiParent = this;
            diagForm.Show();
        }

       
        private void GoodMoveOneMenuItem_Click(object sender, EventArgs e)
        {
            GoodClientsForm Good_ClientsForm = new GoodClientsForm();
            // Set the Parent Form of the Child window.
            Good_ClientsForm.MdiParent = this;
            Good_ClientsForm.Show();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            string connectionString = main.connectionString;
            SqlConnection conn;
            SqlTransaction t;
            conn = new SqlConnection(connectionString);
            conn.Open();

            t = conn.BeginTransaction();

            int Input_Doc_Id = 19;
                      
            Input_doc_good i = new Input_doc_good(0);
            i.ShowDialog();

            int Goods_ID = i.Id;
            int count = i.Count;
            double Price = i.Price;
            if (i.ok == true)
            {
                //MessageBox.Show(Input_Doc_Id.ToString() + " "+ i.Good_Price.ToString()+" "+ i.Good_Id.ToString()+" "+ i.Good_Count.ToString());
                if (i.ok == true)
                {
                    string sqlExpression = "INSERT INTO dbo.Input_Goods(input_doc_id, goods_id,price,count) VALUES(@input_doc_id, @goods_id,@price,@count)";
                    try
                    {
                        SqlCommand command = new SqlCommand(sqlExpression, conn);
                        command.Transaction = t;
                        // создаем параметр для имени
                        SqlParameter input_doc_idParam = new SqlParameter("@input_doc_id", Input_Doc_Id);
                        // добавляем параметр к команде
                        command.Parameters.Add(input_doc_idParam);
                        // создаем параметр для возраста
                        SqlParameter Goods_ID_Param = new SqlParameter("@goods_id", Goods_ID);
                        // добавляем параметр к команде
                        command.Parameters.Add(Goods_ID_Param);
                        // создаем параметр для клиента
                        SqlParameter priceParam = new SqlParameter("@price", Price);
                        // добавляем параметр к команде
                        command.Parameters.Add(priceParam);
                        // создаем параметр для клиента
                        SqlParameter countParam = new SqlParameter("@count", count);
                        // добавляем параметр к команде
                        command.Parameters.Add(countParam);
                        int number = command.ExecuteNonQuery();
                        MessageBox.Show(number.ToString() + " rows affected by insert");
                        
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                }
            }
        }

        private void GoodsMoveMenuItem_Click(object sender, EventArgs e)
        {
            Goods_Move_Form GoodsMoveForm = new Goods_Move_Form();
            // Set the Parent Form of the Child window.
            GoodsMoveForm.MdiParent = this;
            GoodsMoveForm.Show();
        }

        private void iniToolStripMenuItem_Click(object sender, EventArgs e)
        {

            IniFile MyIni = new IniFile(FILE_NAME);
            //MyIni.WriteKey("connectionString", connectionString, "Base");
            connectionString=MyIni.ReadKey("connectionString", "Base");
            MessageBox.Show(connectionString);
            
            

        }

        private void NumPhrase(int v1, bool v2)
        {
            throw new NotImplementedException();
        }

        private void ReqsitesMenuItem_Click(object sender, EventArgs e)
        {
            Requisites RForm = new Requisites(0);
            RForm.MdiParent = this;
            RForm.Show();
        }

        private void TownsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Towns TownsForm = new Towns(0);
            // Set the Parent Form of the Child window.
            TownsForm.MdiParent = this;
            TownsForm.Show();
        }

        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            Input_doc_good i = new Input_doc_good(4, 1/*id*/);
            i.ShowDialog();
        }
    }
}
