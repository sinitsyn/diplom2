﻿
namespace WinFormsApp1
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Main_menuStrip = new System.Windows.Forms.MenuStrip();
            this.DocMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.InDocMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.OutDocMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DicMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GoodsMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ClientsMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ReqsitesMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TownsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ReportsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.CountRepMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GoodsMoveMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.GoodMoveOneMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.iniToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.Main_menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // Main_menuStrip
            // 
            this.Main_menuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.Main_menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.DocMenuItem,
            this.DicMenuItem,
            this.ReportsMenu});
            this.Main_menuStrip.Location = new System.Drawing.Point(0, 0);
            this.Main_menuStrip.Name = "Main_menuStrip";
            this.Main_menuStrip.Size = new System.Drawing.Size(852, 28);
            this.Main_menuStrip.TabIndex = 0;
            this.Main_menuStrip.Text = "main_menuStrip";
            // 
            // DocMenuItem
            // 
            this.DocMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.InDocMenuItem,
            this.OutDocMenuItem,
            this.toolStripMenuItem3});
            this.DocMenuItem.Name = "DocMenuItem";
            this.DocMenuItem.Size = new System.Drawing.Size(101, 24);
            this.DocMenuItem.Text = "Документы";
            // 
            // InDocMenuItem
            // 
            this.InDocMenuItem.Name = "InDocMenuItem";
            this.InDocMenuItem.Size = new System.Drawing.Size(224, 26);
            this.InDocMenuItem.Text = "Приходные";
            this.InDocMenuItem.Click += new System.EventHandler(this.InDocMenuItem_Click);
            // 
            // OutDocMenuItem
            // 
            this.OutDocMenuItem.Name = "OutDocMenuItem";
            this.OutDocMenuItem.Size = new System.Drawing.Size(224, 26);
            this.OutDocMenuItem.Text = "Отпускные";
            this.OutDocMenuItem.Click += new System.EventHandler(this.OutDocMenuItem_Click);
            // 
            // DicMenuItem
            // 
            this.DicMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.GoodsMenuItem,
            this.ClientsMenuItem,
            this.ReqsitesMenuItem,
            this.TownsToolStripMenuItem});
            this.DicMenuItem.Name = "DicMenuItem";
            this.DicMenuItem.Size = new System.Drawing.Size(117, 24);
            this.DicMenuItem.Text = "Справочники";
            // 
            // GoodsMenuItem
            // 
            this.GoodsMenuItem.Name = "GoodsMenuItem";
            this.GoodsMenuItem.Size = new System.Drawing.Size(224, 26);
            this.GoodsMenuItem.Text = "Товары";
            this.GoodsMenuItem.Click += new System.EventHandler(this.GoodsMenuItem_Click);
            // 
            // ClientsMenuItem
            // 
            this.ClientsMenuItem.Name = "ClientsMenuItem";
            this.ClientsMenuItem.Size = new System.Drawing.Size(224, 26);
            this.ClientsMenuItem.Text = "Клиенты";
            this.ClientsMenuItem.Click += new System.EventHandler(this.ClientsMenuItem_Click);
            // 
            // ReqsitesMenuItem
            // 
            this.ReqsitesMenuItem.Name = "ReqsitesMenuItem";
            this.ReqsitesMenuItem.Size = new System.Drawing.Size(224, 26);
            this.ReqsitesMenuItem.Text = "Реквизиты";
            this.ReqsitesMenuItem.Click += new System.EventHandler(this.ReqsitesMenuItem_Click);
            // 
            // TownsToolStripMenuItem
            // 
            this.TownsToolStripMenuItem.Name = "TownsToolStripMenuItem";
            this.TownsToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.TownsToolStripMenuItem.Text = "Города";
            this.TownsToolStripMenuItem.Click += new System.EventHandler(this.TownsToolStripMenuItem_Click);
            // 
            // ReportsMenu
            // 
            this.ReportsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CountRepMenuItem,
            this.GoodsMoveMenuItem,
            this.GoodMoveOneMenuItem,
            this.toolStripMenuItem2,
            this.iniToolStripMenuItem});
            this.ReportsMenu.Name = "ReportsMenu";
            this.ReportsMenu.Size = new System.Drawing.Size(73, 24);
            this.ReportsMenu.Text = "Отчёты";
            // 
            // CountRepMenuItem
            // 
            this.CountRepMenuItem.Name = "CountRepMenuItem";
            this.CountRepMenuItem.Size = new System.Drawing.Size(295, 26);
            this.CountRepMenuItem.Text = "Остатки";
            this.CountRepMenuItem.Click += new System.EventHandler(this.CountRepMenuItem_Click);
            // 
            // GoodsMoveMenuItem
            // 
            this.GoodsMoveMenuItem.Name = "GoodsMoveMenuItem";
            this.GoodsMoveMenuItem.Size = new System.Drawing.Size(295, 26);
            this.GoodsMoveMenuItem.Text = "Движение товара (общее)";
            this.GoodsMoveMenuItem.Click += new System.EventHandler(this.GoodsMoveMenuItem_Click);
            // 
            // GoodMoveOneMenuItem
            // 
            this.GoodMoveOneMenuItem.Name = "GoodMoveOneMenuItem";
            this.GoodMoveOneMenuItem.Size = new System.Drawing.Size(295, 26);
            this.GoodMoveOneMenuItem.Text = "Покупки товара по клиентам";
            this.GoodMoveOneMenuItem.Click += new System.EventHandler(this.GoodMoveOneMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(295, 26);
            this.toolStripMenuItem2.Text = "1";
            this.toolStripMenuItem2.Visible = false;
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // iniToolStripMenuItem
            // 
            this.iniToolStripMenuItem.Name = "iniToolStripMenuItem";
            this.iniToolStripMenuItem.Size = new System.Drawing.Size(295, 26);
            this.iniToolStripMenuItem.Text = "ini";
            this.iniToolStripMenuItem.Visible = false;
            this.iniToolStripMenuItem.Click += new System.EventHandler(this.iniToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(224, 26);
            this.toolStripMenuItem3.Text = "111";
            this.toolStripMenuItem3.Click += new System.EventHandler(this.toolStripMenuItem3_Click);
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(852, 512);
            this.Controls.Add(this.Main_menuStrip);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.Main_menuStrip;
            this.Name = "main";
            this.Text = "Финансовый учёт работы Интернет магазина";
            this.Main_menuStrip.ResumeLayout(false);
            this.Main_menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip Main_menuStrip;
        private System.Windows.Forms.ToolStripMenuItem DocMenuItem;
        private System.Windows.Forms.ToolStripMenuItem InDocMenuItem;
        private System.Windows.Forms.ToolStripMenuItem OutDocMenuItem;
        private System.Windows.Forms.ToolStripMenuItem DicMenuItem;
        private System.Windows.Forms.ToolStripMenuItem GoodsMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ClientsMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ReportsMenu;
        private System.Windows.Forms.ToolStripMenuItem CountRepMenuItem;
        private System.Windows.Forms.ToolStripMenuItem GoodsMoveMenuItem;
        private System.Windows.Forms.ToolStripMenuItem GoodMoveOneMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem iniToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ReqsitesMenuItem;
        private System.Windows.Forms.ToolStripMenuItem TownsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
    }
}