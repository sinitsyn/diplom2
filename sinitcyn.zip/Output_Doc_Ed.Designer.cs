﻿
namespace WinFormsApp1
{
    partial class Output_Doc_Ed
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Output_Doc_Ed));
            this.ClientLab = new System.Windows.Forms.Label();
            this.Client_btn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.chancel_btn = new System.Windows.Forms.Button();
            this.OK_btn = new System.Windows.Forms.Button();
            this.NewDocBtn = new System.Windows.Forms.Button();
            this.DateTP = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.BilNumTB = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.VatLbl = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Sum_lbl = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.del_good_btn = new System.Windows.Forms.Button();
            this.ed_good_btn = new System.Windows.Forms.Button();
            this.new_good_btn = new System.Windows.Forms.Button();
            this.OutputGoogsGridView = new System.Windows.Forms.DataGridView();
            this.Prn_btn = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OutputGoogsGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // ClientLab
            // 
            this.ClientLab.AutoSize = true;
            this.ClientLab.Location = new System.Drawing.Point(167, 79);
            this.ClientLab.Name = "ClientLab";
            this.ClientLab.Size = new System.Drawing.Size(20, 17);
            this.ClientLab.TabIndex = 30;
            this.ClientLab.Text = "...";
            // 
            // Client_btn
            // 
            this.Client_btn.Location = new System.Drawing.Point(127, 73);
            this.Client_btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Client_btn.Name = "Client_btn";
            this.Client_btn.Size = new System.Drawing.Size(34, 24);
            this.Client_btn.TabIndex = 29;
            this.Client_btn.Text = "...";
            this.Client_btn.UseVisualStyleBackColor = true;
            this.Client_btn.Click += new System.EventHandler(this.button3_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(71, 76);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 17);
            this.label3.TabIndex = 28;
            this.label3.Text = "Клиент";
            // 
            // chancel_btn
            // 
            this.chancel_btn.Location = new System.Drawing.Point(851, 480);
            this.chancel_btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chancel_btn.Name = "chancel_btn";
            this.chancel_btn.Size = new System.Drawing.Size(94, 24);
            this.chancel_btn.TabIndex = 27;
            this.chancel_btn.Text = "Отмена";
            this.chancel_btn.UseVisualStyleBackColor = true;
            this.chancel_btn.Click += new System.EventHandler(this.chancel_btn_Click);
            // 
            // OK_btn
            // 
            this.OK_btn.Location = new System.Drawing.Point(751, 480);
            this.OK_btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.OK_btn.Name = "OK_btn";
            this.OK_btn.Size = new System.Drawing.Size(94, 24);
            this.OK_btn.TabIndex = 26;
            this.OK_btn.Text = "ok";
            this.OK_btn.UseVisualStyleBackColor = true;
            this.OK_btn.Click += new System.EventHandler(this.button1_Click);
            // 
            // NewDocBtn
            // 
            this.NewDocBtn.Location = new System.Drawing.Point(786, 30);
            this.NewDocBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.NewDocBtn.Name = "NewDocBtn";
            this.NewDocBtn.Size = new System.Drawing.Size(159, 24);
            this.NewDocBtn.TabIndex = 25;
            this.NewDocBtn.Text = "Новый/изменить";
            this.NewDocBtn.UseVisualStyleBackColor = true;
            this.NewDocBtn.Click += new System.EventHandler(this.NewDocBtn_Click);
            // 
            // DateTP
            // 
            this.DateTP.Location = new System.Drawing.Point(347, 26);
            this.DateTP.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.DateTP.Name = "DateTP";
            this.DateTP.Size = new System.Drawing.Size(250, 22);
            this.DateTP.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(285, 30);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 17);
            this.label2.TabIndex = 23;
            this.label2.Text = "Дата";
            // 
            // BilNumTB
            // 
            this.BilNumTB.Location = new System.Drawing.Point(127, 25);
            this.BilNumTB.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.BilNumTB.Name = "BilNumTB";
            this.BilNumTB.Size = new System.Drawing.Size(125, 22);
            this.BilNumTB.TabIndex = 22;
            this.BilNumTB.Text = ".";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(71, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 17);
            this.label1.TabIndex = 21;
            this.label1.Text = "No";
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.VatLbl);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.Sum_lbl);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.del_good_btn);
            this.panel1.Controls.Add(this.ed_good_btn);
            this.panel1.Controls.Add(this.new_good_btn);
            this.panel1.Controls.Add(this.OutputGoogsGridView);
            this.panel1.Location = new System.Drawing.Point(71, 125);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(874, 332);
            this.panel1.TabIndex = 38;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 271);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 17);
            this.label5.TabIndex = 47;
            this.label5.Text = "Товары";
            // 
            // VatLbl
            // 
            this.VatLbl.AutoSize = true;
            this.VatLbl.Location = new System.Drawing.Point(760, 306);
            this.VatLbl.Name = "VatLbl";
            this.VatLbl.Size = new System.Drawing.Size(16, 17);
            this.VatLbl.TabIndex = 46;
            this.VatLbl.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(677, 307);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 17);
            this.label6.TabIndex = 45;
            this.label6.Text = "в т.ч. НДС:";
            // 
            // Sum_lbl
            // 
            this.Sum_lbl.AutoSize = true;
            this.Sum_lbl.Location = new System.Drawing.Point(760, 271);
            this.Sum_lbl.Name = "Sum_lbl";
            this.Sum_lbl.Size = new System.Drawing.Size(16, 17);
            this.Sum_lbl.TabIndex = 43;
            this.Sum_lbl.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(677, 271);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 17);
            this.label4.TabIndex = 42;
            this.label4.Text = "Итого:";
            // 
            // del_good_btn
            // 
            this.del_good_btn.Location = new System.Drawing.Point(210, 299);
            this.del_good_btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.del_good_btn.Name = "del_good_btn";
            this.del_good_btn.Size = new System.Drawing.Size(94, 24);
            this.del_good_btn.TabIndex = 41;
            this.del_good_btn.Text = "Удалить";
            this.del_good_btn.UseVisualStyleBackColor = true;
            this.del_good_btn.Click += new System.EventHandler(this.del_good_btn_Click);
            // 
            // ed_good_btn
            // 
            this.ed_good_btn.Location = new System.Drawing.Point(109, 300);
            this.ed_good_btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ed_good_btn.Name = "ed_good_btn";
            this.ed_good_btn.Size = new System.Drawing.Size(94, 24);
            this.ed_good_btn.TabIndex = 40;
            this.ed_good_btn.Text = "Изменить";
            this.ed_good_btn.UseVisualStyleBackColor = true;
            this.ed_good_btn.Click += new System.EventHandler(this.ed_good_btn_Click);
            // 
            // new_good_btn
            // 
            this.new_good_btn.Location = new System.Drawing.Point(10, 299);
            this.new_good_btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.new_good_btn.Name = "new_good_btn";
            this.new_good_btn.Size = new System.Drawing.Size(94, 24);
            this.new_good_btn.TabIndex = 39;
            this.new_good_btn.Text = "Добавить";
            this.new_good_btn.UseVisualStyleBackColor = true;
            this.new_good_btn.Click += new System.EventHandler(this.new_good_btn_Click);
            // 
            // OutputGoogsGridView
            // 
            this.OutputGoogsGridView.AllowUserToAddRows = false;
            this.OutputGoogsGridView.AllowUserToDeleteRows = false;
            this.OutputGoogsGridView.AllowUserToOrderColumns = true;
            this.OutputGoogsGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.OutputGoogsGridView.Dock = System.Windows.Forms.DockStyle.Top;
            this.OutputGoogsGridView.Location = new System.Drawing.Point(0, 0);
            this.OutputGoogsGridView.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.OutputGoogsGridView.MultiSelect = false;
            this.OutputGoogsGridView.Name = "OutputGoogsGridView";
            this.OutputGoogsGridView.ReadOnly = true;
            this.OutputGoogsGridView.RowHeadersWidth = 51;
            this.OutputGoogsGridView.RowTemplate.Height = 29;
            this.OutputGoogsGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.OutputGoogsGridView.Size = new System.Drawing.Size(874, 260);
            this.OutputGoogsGridView.TabIndex = 38;
            this.OutputGoogsGridView.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.OutputGoogsGridView_DataBindingComplete);
            // 
            // Prn_btn
            // 
            this.Prn_btn.Location = new System.Drawing.Point(71, 480);
            this.Prn_btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Prn_btn.Name = "Prn_btn";
            this.Prn_btn.Size = new System.Drawing.Size(94, 24);
            this.Prn_btn.TabIndex = 44;
            this.Prn_btn.Text = "Печать";
            this.Prn_btn.UseVisualStyleBackColor = true;
            this.Prn_btn.Click += new System.EventHandler(this.Prn_btn_Click);
            // 
            // Output_Doc_Ed
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1015, 514);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.ClientLab);
            this.Controls.Add(this.Prn_btn);
            this.Controls.Add(this.Client_btn);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.chancel_btn);
            this.Controls.Add(this.OK_btn);
            this.Controls.Add(this.NewDocBtn);
            this.Controls.Add(this.DateTP);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BilNumTB);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Output_Doc_Ed";
            this.Text = "Отпускной документ";
            this.Load += new System.EventHandler(this.Output_Doc_Ed_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OutputGoogsGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label ClientLab;
        private System.Windows.Forms.Button Client_btn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button chancel_btn;
        private System.Windows.Forms.Button OK_btn;
        private System.Windows.Forms.Button NewDocBtn;
        private System.Windows.Forms.DateTimePicker DateTP;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox BilNumTB;
        private System.Windows.Forms.Label label1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button Prn_btn;
        private System.Windows.Forms.Label Sum_lbl;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button del_good_btn;
        private System.Windows.Forms.Button ed_good_btn;
        private System.Windows.Forms.Button new_good_btn;
        private System.Windows.Forms.DataGridView OutputGoogsGridView;
        private System.Windows.Forms.Label VatLbl;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
    }
}