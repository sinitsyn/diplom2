﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Requisites : Form
    {
        private int op;
        private SqlConnection sqlConnection = null;
        private SqlDataAdapter SqlDataAdapter = null;
        private SqlCommandBuilder SqlCommandBuilder = null;

        string filter;
        Boolean f_active = false;
        public int Requisites_id = -1;
        DataSet dataSet;

        public Requisites(int cmd)
        {
            op = cmd;
            InitializeComponent();
            dataSet = CreateDataSet();
            RequisitesGridView.DataSource = dataSet.Tables["dbo.Requisites"];
            Set_ColumnHeader();
            //InitializeComponent();
        }

        private DataSet CreateDataSet(string newSql = "")
        {
            string connectionString = main.connectionString;
            using (SqlConnection conn = new
                   SqlConnection(connectionString))
            {
                conn.Close();

                conn.Open();
                //MessageBox.Show("Успешное подключение !");
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM dbo.Requisites " +
                                                        newSql, conn))
                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    // Объекты‐адаптеры умеют взаимодействовать  
                    // с конкретными серверами баз данных  
                    adapter.TableMappings.Add("Table", "dbo.Requisites");
                    adapter.SelectCommand = cmd;
                    DataSet dataSet = new DataSet("dbo.Requisites");
                    // Поместить все строки в набор данных  
                    adapter.Fill(dataSet);
                    return dataSet;
                }

            }
        }

        private void Set_ColumnHeader()
        {
            //обзываем
            RequisitesGridView.Columns["Name"].DisplayIndex = 0;
            RequisitesGridView.Columns["Name"].HeaderText = "Название";
            RequisitesGridView.Columns["Address"].DisplayIndex = 1;
            RequisitesGridView.Columns["Address"].HeaderText = "Адрес";
            //ClientsGridView.Columns["Person"].DisplayIndex = 2;
            //ClientsGridView.Columns["Person"].HeaderText = "Ч/Л";
            //if (ClientsGridView.Columns["Person"].Visible == true) ClientsGridView.Columns["Person"].Visible = false;
            RequisitesGridView.Columns["Phone"].DisplayIndex = 3;
            RequisitesGridView.Columns["Phone"].HeaderText = "Телефон";
            //ClientsGridView.Columns["TOWN_NAME"].DisplayIndex = 4;
            //ClientsGridView.Columns["TOWN_NAME"].HeaderText = "Город";


            //ClientsGridView.Columns["ID"].DisplayIndex = ClientsGridView.Columns.Count - 1;
            //ClientsGridView.Columns["ID"].Visible = false;
            if (RequisitesGridView.Columns["ID"].Visible == true) RequisitesGridView.Columns["ID"].Visible = false;
            //if (ClientsGridView.Columns["TOWNS_ID"].Visible == true) ClientsGridView.Columns["TOWNS_ID"].Visible = false;
            //ClientsGridView.Columns["City"].DisplayIndex = ClientsGridView.Columns.Count - 1;
            //if (ClientsGridView.Columns["City"].Visible == true) ClientsGridView.Columns["City"].Visible = false;*/
        }

        private void GridR()
        {
            ///  int row = ClientsGridView.CurrentRow.Index;
            string w = "";
            RequisitesGridView.DataSource = null;
            /*if (fname != null && fname != "") w = w + " AND FNAME='" + fname + "' ";
            if (price1 > 0) w = w + " AND Price>" + price1;
            if (price2 > 0) w = w + " AND Price<" + price2;
            if (priceOut1 > 0) w = w + " AND PriceOut>" + PriceOut1Val.ToString();
            if (priceOut2 > 0) w = w + " AND PriceOut<" + PriceOut2Val.ToString();
            if (vat! > 0) w = w + " AND VAT=" + VATVal.ToString();


            // dataSet = CreateDataSet("WHERE FNAME='"+FNameVal+"'"); //установка фильтра*/
            dataSet = CreateDataSet(" " + w); //установка фильтра
            RequisitesGridView.DataSource = dataSet.Tables["dbo.Requisites"];
            //  GoodsDataGridView.CurrentCell= GoodsDataGridView.Rows[GoodsDataGridView.RowCount-1].Cells[0];
            /*if (op == 0)
                ClientsGridView.CurrentCell = ClientsGridView.Rows[ClientsGridView.RowCount-1].Cells[0]; //добавление
            if (op==1)
                ClientsGridView.CurrentCell = ClientsGridView.Rows[row].Cells[0];
            if (op == 2)
                ClientsGridView.CurrentCell = ClientsGridView.Rows[row -1].Cells[0];*/
            //Set_ColumnHeader();
        }

        private void NewBtn_Click(object sender, EventArgs e)
        {
            int row = RequisitesGridView.RowCount;
            RequisitesEditForm re = new RequisitesEditForm(1);

            re.ShowDialog();
            GridR();
            Set_ColumnHeader();
        }

        private void EdBtn_Click(object sender, EventArgs e)
        {
            RequisitesGridView.Focus();
            int row = RequisitesGridView.CurrentRow.Index;
            
            int ID = Convert.ToInt32(dataSet.Tables[0].Rows[row]["ID"].ToString());
            
            string FNameVal = Convert.ToString(dataSet.Tables[0].Rows[row]["Name"].ToString());
            string AddressVal = dataSet.Tables[0].Rows[RequisitesGridView.CurrentRow.Index]["Address"].ToString();
            string PhoneVal = dataSet.Tables[0].Rows[RequisitesGridView.CurrentRow.Index]["Phone"].ToString();

            RequisitesEditForm ce = new RequisitesEditForm(2, ID, FNameVal, AddressVal, PhoneVal);
            ce.ShowDialog();
            GridR();
            Set_ColumnHeader();
            RequisitesGridView.CurrentCell = RequisitesGridView.Rows[row].Cells[2];
        }

        private void DelBtn_Click(object sender, EventArgs e)
        {
            int row = RequisitesGridView.CurrentRow.Index;
            //int ID = Convert.ToInt32( ClientsGridView.CurrentRow.Cells["ID"].Value.ToString());
            int ID = Convert.ToInt32(dataSet.Tables[0].Rows[row]["ID"].ToString());
            string connectionString = main.connectionString;
            using (SqlConnection conn = new
                   SqlConnection(connectionString))
            {
                conn.Close();

                conn.Open();
                //MessageBox.Show("Успешное подключение !");
                using (SqlCommand cmd = new SqlCommand("DELETE FROM dbo.Requisites where ID=@ID", conn))
                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {

                    cmd.Parameters.Add(new SqlParameter("@ID", ID));
                    // Здесь используется метод ExecuteNonQuery(), потому  
                    // что мы не выдаем запрос на чтение строк во время  
                    // вставки 
                    int rowsAffected = cmd.ExecuteNonQuery();
                    MessageBox.Show(rowsAffected.ToString() + " rows affected by delete");
                }


            }
            //   goods_editF ge = new goods_editF(3, ID);
            //   ge.ShowDialog();
            GridR();
            Set_ColumnHeader();
            RequisitesGridView.CurrentCell = RequisitesGridView.Rows[row - 1].Cells[2];
        }
    }
}
