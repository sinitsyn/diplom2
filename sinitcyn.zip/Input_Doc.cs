﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Input_Doc : Form
    {
        string connectionString = main.connectionString;
        private int op;
        private SqlConnection sqlConnection = null;
        private SqlDataAdapter SqlDataAdapter = null;
        private SqlCommandBuilder SqlCommandBuilder = null;
        private SqlTransaction t;

        string filter;
        DataSet dataSet;


        public Input_Doc(int op_cmd) //при создании формы
        {
            op = op_cmd;
            InitializeComponent();
            dataSet = CreateDataSet();
            IDocGridView.DataSource = dataSet.Tables["dbo.Input_Doc"];
            Set_ColumnHeader();
            //IDocGridView.Columns["Sum"].CellTemplate.Style.Format = "N2";
            //IDocGridView.Columns["VAT"].CellTemplate.Style.Format = "N2";
        }

        private void Set_ColumnHeader(int cmd=0) //изменить заголовки столбцов
        {
            //обзываем
            if (cmd == 1)
            {
                if (IDocGridView.Columns["ID"].Visible == true) IDocGridView.Columns["ID"].Visible = false;
                if (IDocGridView.Columns["CLIENT_ID"].Visible == true) IDocGridView.Columns["CLIENT_ID"].Visible = false;
                if (IDocGridView.Columns["C_ID"].Visible == true) IDocGridView.Columns["C_ID"].Visible = false;

                IDocGridView.Columns["Bill_Num"].DisplayIndex = 0;
                IDocGridView.Columns["Bill_Num"].HeaderText = "Номер";
                //IDocGridView.Columns["Bill_Num"].DefaultCellStyle.Format ="d";
                IDocGridView.Columns["Data"].DisplayIndex = 1;
                IDocGridView.Columns["Data"].HeaderText = "Дата";
                //IDocGridView.Columns["Data"].DefaultCellStyle.Format = "d";

                IDocGridView.Columns["FNAME"].DisplayIndex = 2;
                IDocGridView.Columns["FNAME"].HeaderText = "Клиент";
                IDocGridView.Columns["Sum"].DisplayIndex = 3;
                IDocGridView.Columns["Sum"].HeaderText = "Сумма";
                IDocGridView.Columns["Sum"].CellTemplate.Style.Format = "N2";
                IDocGridView.Columns["VAT"].DisplayIndex = 4;
                IDocGridView.Columns["VAT"].HeaderText = "В.т.ч. НДС";
                IDocGridView.Columns["VAT"].CellTemplate.Style.Format = "N2";
            }
        }

        private DataSet CreateDataSet(string newSql = "")
        {
            string connectionString = main.connectionString;
            using (SqlConnection conn = new
                   SqlConnection(connectionString))
            {
                conn.Close();

                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT I_D.*,C.FName,C.ID as C_ID FROM dbo.Input_Doc I_D,CLIENTS C WHERE I_D.Client_ID=C.ID " + newSql, conn))
                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    // Объекты‐адаптеры умеют взаимодействовать  
                    // с конкретными серверами баз данных  
                    adapter.TableMappings.Add("Table", "dbo.Input_Doc");
                    //adapter.TableMappings.Add("Table", "dbo.Clients");
                    adapter.SelectCommand = cmd;
                    DataSet dataSet = new DataSet("dbo.Input_Doc");
                    //DataSet dataSet = new DataSet("dbo.Clients");
                    // Поместить все строки в набор данных  
                    adapter.Fill(dataSet);
                    return dataSet;
                }

            }
        }

        private DataSet CreateDataSetG(int InputDocId)
        {
            string connectionString = main.connectionString;
            using (SqlConnection conn = new
                   SqlConnection(connectionString))
            {
                conn.Close();

                conn.Open();

                SqlCommand cmd = new SqlCommand("SELECT * FROM dbo.Input_Goods");
                cmd.Connection = conn;
                
                cmd.ExecuteNonQuery();

                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    // Объекты‐адаптеры умеют взаимодействовать  
                    // с конкретными серверами баз данных  
                    adapter.TableMappings.Add("Table", "dbo.Input_Goods");
                    //adapter.TableMappings.Add("Table", "dbo.Clients");
                    adapter.SelectCommand = cmd;
                    DataSet dataSet = new DataSet("dbo.Input_Goods");
                    //DataSet dataSet = new DataSet("dbo.Clients");
                    // Поместить все строки в набор данных  
                    adapter.Fill(dataSet);
                    return dataSet;
                }

            }
        }

        private void GridR(int cmd) //обновление
        {
            string w = "";
            int r = 0;
            /*if (dataSet.Tables[0].Rows.Count > 0)
                r = IDocGridView.CurrentCell.RowIndex;*/
            dataSet = null;
            //IDocGridView.DataSource = null;
            dataSet = CreateDataSet(" " + w); //переоткрытие
            IDocGridView.DataSource = dataSet.Tables["dbo.Input_Doc"];
            switch (cmd)
            {
                case 1:
                    if (IDocGridView.RowCount > 0) IDocGridView.CurrentCell = IDocGridView.Rows[IDocGridView.RowCount - 1].Cells[1]; //добавление
                    break;
                case 2:
                    if (IDocGridView.RowCount > 0)
                        IDocGridView.CurrentCell = IDocGridView.Rows[r].Cells[1];//редактирование
                    break;
                case 3:
                    if (r > 0) IDocGridView.CurrentCell = IDocGridView.Rows[r - 1].Cells[1];//удаление
                    break;
                default:
                    break;
            }
            Set_ColumnHeader();
            //IDocGridView.Columns["Sum"].CellTemplate.Style.Format = "N2";
        }

        private void NewBtn_Click(object sender, EventArgs e)
        {
            //IDocGridView.Focus();
            //int row = IDocGridView.RowCount;
            Input_doc_ed2 I_D_E = new Input_doc_ed2(0);
            I_D_E.ShowDialog();
            GridR(1);
            //RecalcSaldo();
            //переоткрытие
            //dataSet = CreateDataSet("");
            //IDocGridView.DataSource = dataSet.Tables["dbo.Input_Doc"];

            //Set_ColumnHeader();

            /* if (I_D_E.Commit==true)*/
            //IDocGridView.CurrentCell = IDocGridView.Rows[IDocGridView.RowCount-1].Cells[1]; //последняя строка
        }

        private void EditBtn_Click(object sender, EventArgs e)
        {
            //IDocGridView.Focus();
            //int id= Convert.ToInt32(IDocGridView.CurrentRow.Cells["ID"].Value.ToString());
            //int ind = IDocGridView.CurrentRow.Index;
            int ind = 0; //выделенная строка
            if (dataSet.Tables[0].Rows != null)
                if (dataSet.Tables[0].Rows.Count > 0)
                    ind = IDocGridView.CurrentCell.RowIndex;
                else return;
            int id = Convert.ToInt32(dataSet.Tables[0].Rows[IDocGridView.CurrentRow.Index]["id"].ToString());
            Input_doc_ed2 I_D_E = new Input_doc_ed2(1, id); //окно редактирования
            I_D_E.ShowDialog();
            //  GridR(2);
            //Set_ColumnHeader();
            //RecalcSaldo(); //перерасчёт остатков
            // dataSet = CreateDataSet("");//переокрытие dataset
            //IDocGridView.DataSource = dataSet.Tables["dbo.Input_Doc"];
            GridR(2);

            //Set_ColumnHeader(); //русфикация заголовков

            IDocGridView.CurrentCell = IDocGridView.Rows[ind].Cells[1]; //возврат на выделенную строку

        }

        private void DelBtn_Click(object sender, EventArgs e)
        {
            string sqlExpression;
            try
            {
                int Doc_Id = Convert.ToInt32(dataSet.Tables[0].Rows[IDocGridView.CurrentRow.Index]["ID"].ToString());
                string connectionString = main.connectionString;
                string sql = "SELECT * FROM dbo.Input_Goods where Input_Doc_Id="+ Doc_Id.ToString();
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    // Создаем объект DataAdapter
                    SqlDataAdapter adapter = new SqlDataAdapter(sql, connection);
                    // Создаем объект Dataset
                    DataSet ds = new DataSet();
                    // Заполняем Dataset
                    adapter.Fill(ds);
                    // Отображаем данные
                    //IDocGridView.DataSource = ds.Tables[0];

                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        string row_id = ds.Tables[0].Rows[i]["ID"].ToString();
                        string goods_id = ds.Tables[0].Rows[i]["GOODS_ID"].ToString();
                        //MessageBox.Show(d[0].ToString());
                        SqlCommand cmd1 = new SqlCommand("DELETE FROM INPUT_GOODS WHERE ID=" + row_id);
                        cmd1.Transaction = t;
                        cmd1.Connection = connection;
                        int rowsAffected = cmd1.ExecuteNonQuery();
                        MessageBox.Show(rowsAffected.ToString() + " rows affected by delete");
                        sqlExpression = "EXEC RECALC_STOCK " + goods_id.ToString();
                        SqlCommand command = new SqlCommand(sqlExpression, connection);
                        command.Transaction = t;
                        rowsAffected = command.ExecuteNonQuery();
                        MessageBox.Show(rowsAffected.ToString() + " rows affected by delete");
                    }

                    sqlExpression = "DELETE FROM dbo.Input_DOC where ID = @ID";
                    SqlCommand command2 = new SqlCommand(sqlExpression, connection);
                    command2.Transaction = t; //команда в транзакцию
                                             // создаем параметр для id документа
                    SqlParameter id_doc_idParam = new SqlParameter("@ID", Doc_Id);
                    // добавляем параметр к команде
                    command2.Parameters.Add(id_doc_idParam);
                    command2.ExecuteNonQuery();


                }

                GridR(2);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
            /*   //IDocGridView.Focus();
               int ind = 0; //выделенная строка
               if (dataSet.Tables[0].Rows.Count > 0)
                   ind = IDocGridView.CurrentCell.RowIndex;
               int Id = Convert.ToInt32(dataSet.Tables[0].Rows[IDocGridView.CurrentRow.Index]["ID"].ToString());
               string connectionString = main.connectionString;
               try
               {
                   using (SqlConnection conn = new
                      SqlConnection(main.connectionString))
                   {
                       conn.Open();
                       t = conn.BeginTransaction(); //начало транзакции
                       string sqlExpression = "DELETE FROM dbo.Input_GOODS where INPUT_DOC_ID = @ID";
                       SqlCommand command = new SqlCommand(sqlExpression, conn);
                       command.Transaction = t; //команда в транзакцию
                       // создаем параметр для id документа
                       SqlParameter id_doc_idParam = new SqlParameter("@ID", Id);
                       // добавляем параметр к команде
                       command.Parameters.Add(id_doc_idParam);
                       command.ExecuteNonQuery();
                       sqlExpression = "DELETE FROM dbo.Input_Doc where ID = @ID";
                       SqlCommand command2 = new SqlCommand(sqlExpression, conn);
                       command2.Transaction = t;
                       // создаем параметр для имени
                       SqlParameter idParam = new SqlParameter("@ID", Id);
                       // добавляем параметр к команде
                       command2.Parameters.Add(idParam);
                       command2.ExecuteNonQuery();
                       t.Commit(); //подтверждение транзакции
                       dataSet = CreateDataSet("");//переокрытие dataset
                       RecalcSaldo(); //перерасчёт остатков
                       IDocGridView.DataSource = dataSet.Tables["dbo.Input_Doc"];
                       Set_ColumnHeader(1); //русфикация заголовков
                       if (ind > 0) IDocGridView.CurrentCell = IDocGridView.Rows[ind - 1].Cells[1]; //возврат на предыдущую строку
                   }
               }
               catch (Exception ex)
               {
                   MessageBox.Show(ex.Message);
               }*/

        }



        void RecalcGoods_Del_Doc()
        {
            dataSet = CreateDataSet();
            for (int i = 0; i < dataSet.Tables[0].Rows.Count; i++)
            {

            }
        }

        private void PrintBtn_Click(object sender, EventArgs e)
        {
            //IDocGridView.
        }

        private void RecalcSaldo() //перерасчёт остатков по всем накладным
                                   //можно сделать только для товаров в одной накладной
        {
            string sqlExpression = "update GOODS set Balance=((select COALESCE(sum(count),0) from Input_Goods IG where IG.Goods_ID=GOODS.ID)-(select COALESCE(sum(count),0) from Output_Goods OG where OG.Goods_ID=GOODS.ID))";
            string connectionString = main.connectionString;
            SqlConnection conn = new SqlConnection(main.connectionString);
            conn.Open();

            try
            {
                SqlCommand command = new SqlCommand(sqlExpression, conn);
                command.Transaction = t;
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }





        private void IDocGridView_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e) //после загрузки данных в грид
        {
            Set_ColumnHeader(1);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sqlExpression;
            try
            {
                int Doc_Id = Convert.ToInt32(dataSet.Tables[0].Rows[IDocGridView.CurrentRow.Index]["ID"].ToString());
                string connectionString = main.connectionString;
                string sql = "SELECT * FROM dbo.Input_Goods ";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    // Создаем объект DataAdapter
                    SqlDataAdapter adapter = new SqlDataAdapter(sql, connection);
                    // Создаем объект Dataset
                    DataSet ds = new DataSet();
                    // Заполняем Dataset
                    adapter.Fill(ds);
                    // Отображаем данные
                    IDocGridView.DataSource = ds.Tables[0];

                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        string row_id = ds.Tables[0].Rows[i]["ID"].ToString();
                        string goods_id= ds.Tables[0].Rows[i]["GOODS_ID"].ToString();
                        //MessageBox.Show(d[0].ToString());
                        SqlCommand cmd1 = new SqlCommand("DELETE FROM INPUT_GOODS WHERE ID=" + row_id);
                        cmd1.Transaction = t;
                        cmd1.Connection = connection;
                        int rowsAffected = cmd1.ExecuteNonQuery();
                        MessageBox.Show(rowsAffected.ToString() + " rows affected by delete");
                        sqlExpression = "EXEC RECALC_STOCK " + goods_id.ToString();
                        SqlCommand command = new SqlCommand(sqlExpression, connection);
                        command.Transaction = t;
                        rowsAffected = command.ExecuteNonQuery();
                        MessageBox.Show(rowsAffected.ToString() + " rows affected by delete");
                    }
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


    /*// SqlDataAdapter adapter = new SqlDataAdapter(queryString, conn);

    DataSet customers = new DataSet();
    //adapter.Fill(customers, "Input_Goods");

    using (SqlDataAdapter adapter = new SqlDataAdapter())
    {
        string queryString = "SELECT IG.* FROM dbo.Input_Goods IG WHERE IG.Input_Doc_ID=" + Doc_Id.ToString();
        // Объекты‐адаптеры умеют взаимодействовать  
        // с конкретными серверами баз данных  
        adapter.TableMappings.Add("Table", "dbo.Clients");
        adapter.SelectCommand = queryString;
        DataSet dataSet = new DataSet("dbo.Clients");
        // Поместить все строки в набор данных  
        adapter.Fill(dataSet);
        return dataSet;
    }
    while (reader.Read())
    {
        foreach (DataRow pRow in customers.Tables["Input_Goods"].Rows)
        {


        }
        Console.WriteLine(String.Format("{0}, {1}",
            reader[0], reader[1]));
    }



}


}
catch (Exception ex)
{
MessageBox.Show(ex.Message);
}








/*int ind = 0; //выделенная строка
if (dataSet.Tables[0].Rows.Count > 0)
ind = IDocGridView.CurrentCell.RowIndex;
int Id = Convert.ToInt32(dataSet.Tables[0].Rows[IDocGridView.CurrentRow.Index]["ID"].ToString());


int Doc_Id = Convert.ToInt32(dataSet.Tables[0].Rows[IDocGridView.CurrentRow.Index]["ID"].ToString());
int r = IDocGridView.CurrentRow.Index;
string connectionString = main.connectionString;
SqlConnection conn = new SqlConnection(main.connectionString);
//t = conn.BeginTransaction(); //начало транзакции

conn.Open();
string s = "SELECT IG.* FROM dbo.Input_Goods IG WHERE IG.Input_Doc_ID=" + Doc_Id.ToString();

SqlDataAdapter adapter = new SqlDataAdapter(s, conn);
DataSet customers = new DataSet();
adapter.Fill(customers);
string sqlExpression = "";
SqlCommand command = new SqlCommand(sqlExpression, conn);

foreach (DataTable dt in customers.Tables)
{
foreach (DataRow d in dt.Rows)
{
    int row_id;

    row_id = Convert.ToInt32(d[0].ToString());
    //MessageBox.Show(d[0].ToString());
    SqlCommand cmd1 = new SqlCommand("DELETE FROM INPUT_GOODS WHERE ID=" + row_id.ToString());
    cmd1.Transaction = t;
    cmd1.Connection = conn;
    int rowsAffected = cmd1.ExecuteNonQuery();
    MessageBox.Show(rowsAffected.ToString() + " rows affected by delete");
    sqlExpression = "EXEC RECALC_STOCK "+ row_id.ToString();
    command = new SqlCommand(sqlExpression, conn);
    command.Transaction = t;
    rowsAffected = command.ExecuteNonQuery();
    MessageBox.Show(rowsAffected.ToString() + " rows affected by delete");
}
}

//t.Commit(); //подтверждение транзакции
}
catch (Exception ex)
{
MessageBox.Show(ex.Message);
}




//SqlParameter idParam1 = new SqlParameter("@ID", Doc_Id);
// добавляем параметр к команде


//adapter.Fill(customers, "Input_Goods");

//cmd.Transaction = t;
/*    cmd.Connection = conn;
SqlParameter idParam = new SqlParameter("@Input_Doc_ID", Doc_Id);
// добавляем параметр к команде
cmd.Parameters.Add(idParam);
//t = conn.BeginTransaction(); //начало транзакции
SqlCommand cmd1 = new SqlCommand("DELETE FROM INPUT_GOODS WHERE ID=@ID");
cmd1.Connection = conn;
//cmd1.Transaction = t;


int r1;
SqlDataReader reader = cmd.ExecuteReader();



if (reader.HasRows)
{
while (reader.Read())
{
r1 = reader.GetInt32(0);
// создаем параметр для имени

//MessageBox.Show(r1.ToString());
//t.Commit(); //подтверждение транзакции
SqlParameter idParam1 = new SqlParameter("@ID", r1);
// добавляем параметр к команде
cmd1.Parameters.Clear();
cmd1.Parameters.Add(idParam1);
cmd1.ExecuteReader();
}
}
}

}*/
}
    }
}
