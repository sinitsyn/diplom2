﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WinFormsApp1
{
    public partial class test : Form
    {
        string connectionString = main.connectionString;
        private SqlConnection conn;
        private SqlTransaction t;

        private SqlDataAdapter sqlDataAdapter;

        public test()
        {
            conn = new SqlConnection(connectionString);
            conn.Open();
            t = conn.BeginTransaction();
            InitializeComponent();
        }

        private void GridR()
        {
            sqlDataAdapter = new SqlDataAdapter("select * from input_goods", conn);
            sqlDataAdapter.SelectCommand.Transaction = t;
            DataSet ds = new DataSet();
            sqlDataAdapter.Fill(ds/*, "dbo.Input_Goods"*/);
            InputGoogsGridView.DataSource = ds.Tables[0];
            InputGoogsGridView.Columns["Id"].ReadOnly = true;
        }

        private double CalcSum()
        {
            string sqlExpression = "SELECT sum(IG.price * IG.count) as SUM FROM dbo.Input_Goods IG where IG.Input_Doc_ID=1";
            double sum = 0;
            SqlCommand command = new SqlCommand(sqlExpression, conn);
            command.Transaction = t;
            /*SqlParameter Param1 = new SqlParameter("@input_doc_id", textBox1.Text);
            // добавляем параметр к команде
            command.Parameters.Add(Param1);*/
            //command.ExecuteNonQuery();

            using (SqlDataReader reader = command.ExecuteReader())
            {
                // Класс SqlDataReader читает ряды и базы данных  
                // по одному, по мере того, как их запрашиваем   
                while (reader.Read())
                {
                    sum = Convert.ToDouble(reader.GetDecimal(0));//"sum"
                }
            }
            return sum;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sqlExpression = "INSERT INTO dbo.Input_Goods(input_doc_id, goods_id,price,count) VALUES(@input_doc_id, @goods_id,@price,@count)";
                    SqlCommand command = new SqlCommand(sqlExpression, conn);
                    command.Transaction = t;
                    // создаем параметр для имени
                    SqlParameter input_doc_idParam = new SqlParameter("@input_doc_id", 1);
                    // добавляем параметр к команде
                    command.Parameters.Add(input_doc_idParam);
                    // создаем параметр для возраста
                    SqlParameter Goods_ID_Param = new SqlParameter("@goods_id", 1);
                    // добавляем параметр к команде
                    command.Parameters.Add(Goods_ID_Param);
                    // создаем параметр для клиента
                    SqlParameter priceParam = new SqlParameter("@price", 1);
                    // добавляем параметр к команде
                    command.Parameters.Add(priceParam);
                    // создаем параметр для клиента
                    SqlParameter countParam = new SqlParameter("@count", 2);
                    // добавляем параметр к команде
                    command.Parameters.Add(countParam);

                    int number = command.ExecuteNonQuery();
                    MessageBox.Show(number.ToString() + " rows affected by insert");
                    GridR();
                    label1.Text = CalcSum().ToString();
        }

        private void test_Load(object sender, EventArgs e)
        {
            GridR();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double price=Convert.ToDouble(InputGoogsGridView.CurrentRow.Cells["price"].Value);
            
            string sqlExpression = "UPDATE dbo.Input_Goods set price=price-1 where ID=@ID";
            SqlCommand command = new SqlCommand(sqlExpression, conn);
            command.Transaction = t;
            // создаем параметр для имени
            SqlParameter input_doc_idParam = new SqlParameter("@id", Convert.ToInt32(InputGoogsGridView.CurrentRow.Cells["ID"].Value));
            // добавляем параметр к команде
            command.Parameters.Add(input_doc_idParam);
            int number = command.ExecuteNonQuery();
            MessageBox.Show(number.ToString() + " rows affected by update");
            GridR();
        }
    }
}
