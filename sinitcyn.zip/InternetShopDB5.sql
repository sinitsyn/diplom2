USE master
GO

DROP DATABASE [InternetShopDB34];

CREATE DATABASE [InternetShopDB34]
COLLATE Cyrillic_General_CI_AS
GO


USE InternetShopDB34
GO

IF EXISTS (
   SELECT name
   FROM sys.tables
   WHERE name = N'Clients'
)
drop Table Clients

CREATE Table Clients
(ID int not NULL IDENTITY,
FName nvarchar(20),
[Address] nvarchar(50),
Phone nvarchar(30),
TownsID INT
)
GO

ALTER Table Clients
ADD
Primary key (ID)
GO

IF EXISTS (
   SELECT name
   FROM sys.tables
   WHERE name = N'Goods'
)
drop Table Goods

CREATE Table Goods
(ID int not NULL IDENTITY,
FName nvarchar(50),
Price money DEFAULT 0 not NULL,
Price_Out money DEFAULT 0 not NULL,
VAT int DEFAULT 0 not NULL,
Balance int DEFAULT 0 not NULL,
Groups_ID int
)
GO

ALTER Table Goods
ADD
Primary key (ID)
GO

IF EXISTS (
   SELECT name
   FROM sys.tables
   WHERE name = N'Groups'
)
drop Table Groups

CREATE Table Groups
(ID int not NULL IDENTITY,
P_G_ID int,
Tables_ID int,
Name nvarchar(50)
)
GO

ALTER Table Groups
ADD
Primary key (ID)
GO

IF EXISTS (
   SELECT name
   FROM sys.tables
   WHERE name = N'Stoks'
)
drop Table Stoks

CREATE Table Stoks
(ID int not NULL IDENTITY,
Name nvarchar(50)
)
GO

ALTER Table Stoks
ADD
Primary key (ID)
GO

IF EXISTS (
   SELECT name
   FROM sys.tables
   WHERE name = N'Towns'
)
drop Table Towns

CREATE Table Towns
(ID int not NULL IDENTITY,
Name nvarchar(50)
)
GO

ALTER Table Towns
ADD
Primary key (ID)
GO
/*---*/
IF EXISTS (
   SELECT name
   FROM sys.tables
   WHERE name = N'requisites'
)
drop Table Requisites

CREATE Table Requisites
(ID int not NULL IDENTITY,
Name nvarchar(50),
Address nvarchar(100),
Phone nvarchar(50)
)
GO

ALTER Table Requisites
ADD
Primary key (ID)
GO

IF EXISTS (
   SELECT name
   FROM sys.tables
   WHERE name = N'Tables'
)
drop Table Tables

CREATE Table Tables
(ID int not NULL IDENTITY,
Name nvarchar(50)
)
GO

ALTER Table Tables
ADD
Primary key (ID)
GO
Insert into Tables (Name) VALUES ('Clients');
Insert into Tables (Name) VALUES ('Goods');
Insert into Tables (Name) VALUES ('Groups');
Insert into Tables (Name) VALUES ('Stoks');
Insert into Tables (Name) VALUES ('Towns');
Insert into Tables (Name) VALUES ('Requisites');
Insert into Tables (Name) VALUES ('Tables');
Insert into Tables (Name) VALUES ('Input_Doc');
Insert into Tables (Name) VALUES ('Input_Goods');
Insert into Tables (Name) VALUES ('Output_Doc');
Insert into Tables (Name) VALUES ('Output_Goods');
Insert into Tables (Name) VALUES ('Passwords');
GO


CREATE Table Input_Doc
(ID int not NULL IDENTITY,
Bill_Num int,
CLIENT_ID int,
[Sum] money,
VAT money,
[Data] date,
)
GO

ALTER Table Input_Doc
ADD
Primary key (ID)
GO

CREATE Table Input_Goods
(ID int not NULL IDENTITY,
Input_Doc_ID int,
GoodsID int,
Price money,
[Count] int,
FOREIGN KEY (Input_Doc_ID) REFERENCES Input_Doc (ID) ON DELETE CASCADE
)
GO

ALTER Table Input_Goods
ADD
Primary key (ID)
GO

CREATE Table Output_Doc
(ID int not NULL IDENTITY,
Bill_Num int,
[Sum] money,
VAT money,
Data date NULL,
Client_ID int NULL
)
GO

ALTER Table Output_Doc
ADD
Primary key (ID)
GO

CREATE Table Output_Goods
(ID int not NULL IDENTITY,
Output_Doc_ID int,
Goods_ID int,
Price money,
[Count] int,
FOREIGN KEY (Output_Doc_ID) REFERENCES Output_Doc (ID) ON DELETE CASCADE
)
GO

ALTER Table Output_Goods
ADD
Primary key (ID)
GO

CREATE Table Passwords
(ID int not NULL IDENTITY,
[User] varchar(150),
Pass varchar(150)
)
GO

ALTER Table Passwords
ADD
Primary key (ID)
GO

--������ ��� ������� � ���� ������
SELECT * FROM sys.objects WHERE type in (N'U')
GO
SELECT * FROM Tables
GO

CREATE TRIGGER [dbo].[Input_Goods_INSERT_UPDATE]
ON [dbo].[Input_Goods]
AFTER INSERT, UPDATE
AS

	DECLARE @GOODS_ID INT;
	DECLARE @Input_DOC_ID INT;
	SELECT @Input_DOC_ID=Input_Doc_ID, @GOODS_ID=GOODSID FROM inserted;
	
	DECLARE @SUM MONEY;
	SELECT @SUM=COALESCE(SUM(PRICE*COUNT),0) from Input_GOODS where Input_Doc_ID=@Input_DOC_ID

	UPDATE Input_Doc
	SET SUM = @SUM
	WHERE Id = @Input_DOC_ID
	
	DECLARE @INPUT_CNT  INT;
	DECLARE @OUTPUT_CNT INT

	select @INPUT_CNT=sum(COUNT) from Input_Goods where GoodsID=@GOODS_ID;
	select @OUTPUT_CNT=sum(COUNT) from Output_Goods where Goods_ID=@GOODS_ID;

	if @INPUT_CNT is NULL set @INPUT_CNT=0
	if @OUTPUT_CNT is NULL set @OUTPUT_CNT=0

	/*insert into goods (price,price_out,vat) values (@INPUT_CNT,@OUTPUT_CNT,@GOODS_ID)*/

	/*update GOODS set Balance=((select COALESCE(sum(count),0) from Input_Goods IG where IG.Goods_ID=GOODS.ID)-(select COALESCE(sum(count),0) from Output_Goods OG where OG.Goods_ID=GOODS.ID))
	where GOODS.ID=@GOODS_ID*/
	if (@INPUT_CNT-@OUTPUT_CNT<0)  BEGIN
								 ROLLBACK TRAN
								 RAISERROR ('������, ����� ��������� �� ��������, ��� ��� ����� ���� ��������������� ������������� ������� !',16,10)
								END /*else
	UPDATE Goods
	SET Goods.Balance=@INPUT_CNT-@OUTPUT_CNT where Goods.ID=@GOODS_ID;*/

	
GO

CREATE TRIGGER [dbo].[Input_Goods_Delete]
ON [dbo].[Input_Goods]
AFTER DELETE
AS

DECLARE @GOODS_ID INT;
DECLARE @Input_DOC_ID INT;
SELECT @Input_DOC_ID=Input_Doc_ID, @GOODS_ID=GOODSID FROM deleted;

DECLARE @SUM MONEY;
SELECT @SUM=COALESCE(SUM(PRICE*COUNT),0) from Input_GOODS where Input_Doc_ID=@Input_DOC_ID

UPDATE Input_Doc
	SET SUM = @SUM
	WHERE Id = @Input_DOC_ID


DECLARE @INPUT_CNT  INT;
DECLARE @OUTPUT_CNT INT;

select @INPUT_CNT=sum(COUNT) from Input_Goods where GoodsID=@GOODS_ID;
select @OUTPUT_CNT=sum(COUNT) from Output_Goods where Goods_ID=@GOODS_ID;

if @INPUT_CNT is NULL set @INPUT_CNT=0
if @OUTPUT_CNT is NULL set @OUTPUT_CNT=0
if (@INPUT_CNT-@OUTPUT_CNT<0)  BEGIN
								 ROLLBACK TRAN
								 RAISERROR ('������, ����� ��������� �� ��������, ��� ��� ����� ���� ��������������� ������������� ������� !',16,10)
								END /*else
UPDATE Goods
SET Goods.Balance=@INPUT_CNT-@OUTPUT_CNT where Goods.ID=@GOODS_ID;


UPDATE Goods
SET Goods.Balance=@INPUT_CNT-@OUTPUT_CNT where Goods.ID=@GOODS_ID*/

GO


CREATE TRIGGER [dbo].[Output_Goods_INSERT_UPDATE]
ON [dbo].[Output_Goods]
AFTER INSERT, UPDATE
AS

DECLARE @GOODS_ID INT;
DECLARE @OUTPUT_DOC_ID INT;
SELECT @OUTPUT_DOC_ID=Output_Doc_ID, @GOODS_ID=GOODS_ID FROM inserted;

DECLARE @SUM MONEY;
	SELECT @SUM=COALESCE(SUM(PRICE*COUNT),0) from Output_GOODS where Output_Doc_ID=@Output_DOC_ID

	UPDATE OUTPUT_DOC
	SET SUM = @SUM
	WHERE Id = @OUTPUT_DOC_ID

/*UPDATE Output_Doc
SET SUM = (SELECT SUM(PRICE*COUNT) from OUTPUT_GOODS where Output_Doc_ID=@OUTPUT_DOC_ID)
WHERE Id = @OUTPUT_DOC_ID;*/

DECLARE @INPUT_CNT  INT;
DECLARE @OUTPUT_CNT INT;

select @INPUT_CNT=sum(COUNT) from Input_Goods where GoodsID=@GOODS_ID;
select @OUTPUT_CNT=sum(COUNT) from Output_Goods where Goods_ID=@GOODS_ID;

if (@INPUT_CNT is NULL) set @INPUT_CNT = 0;
if (@OUTPUT_CNT is NULL) set @OUTPUT_CNT = 0;
if (@INPUT_CNT-@OUTPUT_CNT<0)  BEGIN
								 ROLLBACK TRAN
								 RAISERROR ('������, ����� ��������� �� ��������, ��� ��� ����� ���� ��������������� ������������� ������� !',16,10)
								END /*else
UPDATE Goods
SET Goods.Balance=@INPUT_CNT-@OUTPUT_CNT where Goods.ID=@GOODS_ID;*/

GO

CREATE TRIGGER [dbo].[Output_Goods_Delete]
ON [dbo].[Output_Goods]
AFTER DELETE
AS

DECLARE @GOODS_ID INT;
DECLARE @OUTPUT_DOC_ID INT;
SELECT @OUTPUT_DOC_ID=Output_Doc_ID, @GOODS_ID=GOODS_ID FROM deleted;

DECLARE @SUM MONEY;
SELECT @SUM=COALESCE(SUM(PRICE*COUNT),0) from Output_GOODS where Output_Doc_ID=@Output_DOC_ID

UPDATE Output_Doc
	SET SUM = @SUM
	WHERE Id = @Output_DOC_ID


DECLARE @INPUT_CNT  INT;
DECLARE @OUTPUT_CNT INT;

select @INPUT_CNT=sum(COUNT) from Input_Goods where GoodsID=@GOODS_ID;
select @OUTPUT_CNT=sum(COUNT) from Output_Goods where Goods_ID=@GOODS_ID;

if (@INPUT_CNT is NULL) set @INPUT_CNT = 0;
if (@OUTPUT_CNT is NULL) set @OUTPUT_CNT = 0;

if (@INPUT_CNT-@OUTPUT_CNT<0)  BEGIN
								 ROLLBACK TRAN
								 RAISERROR ('������, ����� ��������� �� ��������, ��� ��� ����� ���� ��������������� ������������� ������� !',16,10)
								END /*else
UPDATE Goods
SET Goods.Balance=@INPUT_CNT-@OUTPUT_CNT where Goods.ID=@GOODS_ID;*/

GO





CREATE PROCEDURE [dbo].[RECALC_STOCK] @GOODS_ID int
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @INPUT_CNT  INT;
	DECLARE @OUTPUT_CNT INT

	select @INPUT_CNT=sum(COUNT) from Input_Goods where GoodsID=@GOODS_ID;
	select @OUTPUT_CNT=sum(COUNT) from Output_Goods where Goods_ID=@GOODS_ID;

	if @INPUT_CNT is NULL set @INPUT_CNT=0
	if @OUTPUT_CNT is NULL set @OUTPUT_CNT=0
    
	UPDATE Goods
	SET Goods.Balance=@INPUT_CNT-@OUTPUT_CNT where Goods.ID=@GOODS_ID;
END
GO

CREATE PROCEDURE [dbo].[MOVE_GOODS]
AS
BEGIN
    
	
	SET NOCOUNT ON;

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	create table #tmp
	(ID int not NULL,
	FName nvarchar(20),
	Input_count_sum int,
	Output_count_sum int
	)

	DECLARE vendor_cursor CURSOR FOR   
	SELECT ID, FName  
	FROM Goods

	DECLARE @id INT, @fname NVARCHAR(50),  
    @message VARCHAR(80), @product NVARCHAR(50),
	@Input_count_sum int, @Output_count_sum int;  

	OPEN vendor_cursor  
    FETCH NEXT FROM vendor_cursor   
    INTO @id, @fname  

	WHILE @@FETCH_STATUS = 0  
	BEGIN
	select @Input_count_sum=sum(count) from input_goods where GoodsID=@ID
	select @Output_count_sum=sum(count) from Output_Goods where Goods_ID=@ID
	
	if @Input_count_sum is null set @Input_count_sum=0;
	if @Output_count_sum is null set @Output_count_sum=0;

	INSERT INTO #TMP (ID,FNAME,Input_count_sum,Output_count_sum) values (@ID,@FNAME,@Input_count_sum,@Output_count_sum)

	FETCH NEXT FROM vendor_cursor   
    INTO @id, @fname  
	END

	CLOSE vendor_cursor;  
	DEALLOCATE vendor_cursor;  
	
	SELECT * FROM #TMP

END

GO
