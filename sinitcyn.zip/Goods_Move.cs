﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Windows.Forms.DataVisualization.Charting;

namespace WinFormsApp1
{
    public partial class Goods_Move_Form : Form
    {
        private SqlConnection conn = null;
        private SqlDataAdapter SqlDataAdapter = null;
        private SqlCommandBuilder SqlCommandBuilder = null;
        string connectionString = main.connectionString;
        DataSet dataSet;

        public Goods_Move_Form()
        {
            InitializeComponent();
            GraphBox.SelectedIndex = 0;
        }
     
        private DataSet CreateDataSet(string newSql = "")
        {

            using (SqlConnection conn = new
                   SqlConnection(connectionString))
            {
                conn.Close();

                conn.Open();
                //MessageBox.Show("Успешное подключение !");
                using (SqlCommand cmd = new SqlCommand("exec dbo.MOVE_GOODS " + newSql, conn))
                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    // Объекты‐адаптеры умеют взаимодействовать  
                    // с конкретными серверами баз данных  
                   // adapter.TableMappings.Add("Table", "dbo.MOVE_GOODS");
                    adapter.SelectCommand = cmd;
                    //DataSet dataSet = new DataSet("dbo.MOVE_GOODS");
                    // Поместить все строки в набор данных  
                    adapter.Fill(dataSet);
                    return dataSet;
                }

            }
        }

        
        private void BuildBtn_Click(object sender, EventArgs e) //построить
        {
            conn = new SqlConnection(connectionString);
            conn.Open();

            string sqlExpression = "exec dbo.MOVE_GOODS";
            using (conn)
            {
                SqlCommand cmd = new SqlCommand(sqlExpression, conn);

                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    adapter.SelectCommand = cmd;
                    DataSet ds = new DataSet();
                    adapter.Fill(ds);
                    GoodsMoveDataGridView.DataSource = ds.Tables[0];
                }
            }
        }

        private void PrnBtn_Click(object sender, EventArgs e)
        {
            if (GraphBox.SelectedIndex == 0)
             chart1.Titles[0].Text = "График покупок (шт.)";
             else 
             chart1.Titles[0].Text = "График продаж (шт.)";
             chart1.Titles[0].Font = new Font("Arial", 16, FontStyle.Bold);
             chart1.Series[0].ChartType = SeriesChartType.Pie;
            
            conn = new SqlConnection(connectionString);
            conn.Open();

            string sqlExpression = "exec dbo.MOVE_GOODS";
            using (conn)
            {
                SqlCommand cmd = new SqlCommand(sqlExpression, conn);

                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    adapter.SelectCommand = cmd;
                    DataSet ds = new DataSet();
                    adapter.Fill(ds);
                    GoodsMoveDataGridView.DataSource = ds.Tables[0];
                }

                SqlDataReader reader = cmd.ExecuteReader();


                int x = 1;
                int y=0;
                Series S = new Series();
                   chart1.Series[0].IsValueShownAsLabel = true;
                    chart1.Series[0].LegendText = "Колличество";
                chart1.Series[0].Points.Clear();
                chart1.ChartAreas[0].AxisY.IsLabelAutoFit = false;
                chart1.Series["Series1"].LegendText = "111";


                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        if (GraphBox.SelectedIndex == 0)
                            y = reader.GetInt32(2);
                        else
                            y = reader.GetInt32(3);

                        chart1.Series[0].Points.Add(
                        new DataPoint(x++, y)
                        {
                            
                            LegendText=$"{reader.GetString(1)}={y}",
                            AxisLabel = reader.GetString(1)

                        }) ;
                    
                      x++;
                    }
                    
                }
            }

             PrintPreviewDialog ppd = new PrintPreviewDialog();
             ppd.Document = this.chart1.Printing.PrintDocument;
             ppd.ShowDialog();
            }

        private void button1_Click(object sender, EventArgs e)
        {
            conn = new SqlConnection(connectionString);
            conn.Open();

            string sqlExpression = "exec dbo.MOVE_GOODS";
            using (conn)
            {
                SqlCommand cmd = new SqlCommand(sqlExpression, conn);

                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    adapter.SelectCommand = cmd;
                    DataSet ds = new DataSet();
                    adapter.Fill(ds);
                    GoodsMoveDataGridView.DataSource = ds.Tables[0];
                }

                SqlDataReader reader = cmd.ExecuteReader();

                double x = 1;
                int y;
                Series S = new Series();


                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        if (GraphBox.SelectedIndex == 0)
                            y = reader.GetInt32(3);
                        else
                            y = reader.GetInt32(4);
                        chart1.Series[0].Points.AddXY(x, y);

                        chart1.Series[0].Points[((int)x - 1)].LegendText = reader.GetString(1) + "=" + y.ToString();
                        x = x + 1;
                    }
                }

            }
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void Set_ColumnHeader()
        {
            /*переименовывание*/
            /*скрытие*/
            GoodsMoveDataGridView.Focus();
            GoodsMoveDataGridView.Columns["FName"].DisplayIndex = 0;
            GoodsMoveDataGridView.Columns["FName"].HeaderText = "Номер";
            GoodsMoveDataGridView.Columns["Input_count_sum"].DisplayIndex = 1;
            GoodsMoveDataGridView.Columns["Input_count_sum"].HeaderText = "Количество принятых единиц";
            GoodsMoveDataGridView.Columns["Output_count_sum"].DisplayIndex = 2;
            GoodsMoveDataGridView.Columns["Output_count_sum"].HeaderText = "Количество отпущенных единиц";

            GoodsMoveDataGridView.Columns["ID"].Visible = false;
        }

        private void GoodsMoveDataGridView_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            Set_ColumnHeader();
        }
    }
}
