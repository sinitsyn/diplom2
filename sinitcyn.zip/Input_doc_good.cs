﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Input_doc_good : Form
    {
        private SqlConnection sqlConnection = null;
        private SqlDataAdapter SqlDataAdapter = null;
        private SqlCommandBuilder SqlCommandBuilder = null;
        string connectionString = main.connectionString;

        private Button button1;
        private Label label1;

        public int Id = -1;
        public int Count = -1;
        public string Name = "";
        public double Price = 0;
        public double Price_Out = 0;
        public int VAT = 0;
        public int Balance = 0;

        public Boolean ok = false;


        private Label label2;
        private TextBox Price_tB;
        private Label label3;
        private TextBox Count_tB;
        private Button OKbtn;
        private Label GoodLab;
        private Button ChancelBtn;
        private TextBox IDtB;
        private int Cmd = 0;
        

        public Input_doc_good(int cmd, int Good_id = -1)
        {
            InitializeComponent();
            
            sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();
            Cmd = cmd;
            Id = Good_id;
            
            string sqlExpression = "select * from Goods  where ID=@ID";
            if (Cmd == 2 || Cmd == 4)
            {

                SqlCommand command = new SqlCommand(sqlExpression, sqlConnection);

                // создаем параметр для имени
                SqlParameter idParam = new SqlParameter("@ID", Id);
                // добавляем параметр к команде
                command.Parameters.Add(idParam);
                //command.ExecuteNonQuery();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    // Класс SqlDataReader читает ряды и базы данных  
                    // по одному, по мере того, как их запрашиваем   
                    while (reader.Read())
                    {
                        Id = reader.GetInt32(0); //"ID"
                        Name = reader.GetString(1); //"FNAME"
                        decimal s;
                        s = reader.GetDecimal(2);


                        Price = Convert.ToDouble(s);//"Price"
                        //Price_Out = reader.GetFloat(3); ;//"Price_OUt"
                        s = reader.GetDecimal(3);
                        Price_Out = Convert.ToDouble(s);//"Price_OUt"
                        VAT = reader.GetInt32(4);
                        Balance = reader.GetInt32(5);
                    }

                }
            }
        }    

        private void button1_Click(object sender, EventArgs e)
        {
            /*Goods GoodsForm = new Goods(0);
            // Set the Parent Form of the Child window.
            GoodsForm.MdiParent = this;
            GoodsForm.Show();*/

            /*Goods g = new Goods(1);
            g.ShowDialog();
            Good_Id = g.ID;
            Good_Price = g.PriceOut1Val;
            GoodLab.Text = g.FNameVal;*/
            
            /*int Good_Id = -1;
            double Good_Price = -1;
            int Good_Count = -1;
            string Good_Name = "";
            Boolean ok = false;*/

            Goods g = new Goods(1);
             g.ShowDialog();
            Id = g.ID;
            //IDtB.Text = Good_Id.ToString();

            if (Cmd == 0||Cmd== 1) Price = g.Price1Val;
            if (Cmd == 2 || Cmd == 3) Price = g.PriceOut1Val;
            Name = g.FNameVal;

            GoodLab.Text = Name;
            Price_tB.Text = Price.ToString();
        }

        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Price_tB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Count_tB = new System.Windows.Forms.TextBox();
            this.OKbtn = new System.Windows.Forms.Button();
            this.ChancelBtn = new System.Windows.Forms.Button();
            this.GoodLab = new System.Windows.Forms.Label();
            this.IDtB = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(74, 33);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(29, 29);
            this.button1.TabIndex = 3;
            this.button1.Text = "...";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Товар";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Цена";
            // 
            // Price_tB
            // 
            this.Price_tB.Location = new System.Drawing.Point(120, 85);
            this.Price_tB.Name = "Price_tB";
            this.Price_tB.Size = new System.Drawing.Size(176, 22);
            this.Price_tB.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 134);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Количество";
            // 
            // Count_tB
            // 
            this.Count_tB.Location = new System.Drawing.Point(120, 129);
            this.Count_tB.Name = "Count_tB";
            this.Count_tB.Size = new System.Drawing.Size(176, 22);
            this.Count_tB.TabIndex = 7;
            // 
            // OKbtn
            // 
            this.OKbtn.Location = new System.Drawing.Point(390, 183);
            this.OKbtn.Name = "OKbtn";
            this.OKbtn.Size = new System.Drawing.Size(94, 29);
            this.OKbtn.TabIndex = 8;
            this.OKbtn.Text = "OK";
            this.OKbtn.UseVisualStyleBackColor = true;
            this.OKbtn.Click += new System.EventHandler(this.OKbtn_Click);
            // 
            // ChancelBtn
            // 
            this.ChancelBtn.Location = new System.Drawing.Point(490, 183);
            this.ChancelBtn.Name = "ChancelBtn";
            this.ChancelBtn.Size = new System.Drawing.Size(94, 29);
            this.ChancelBtn.TabIndex = 9;
            this.ChancelBtn.Text = "Отмена";
            this.ChancelBtn.UseVisualStyleBackColor = true;
            this.ChancelBtn.Click += new System.EventHandler(this.ChancelBtn_Click);
            // 
            // GoodLab
            // 
            this.GoodLab.AutoSize = true;
            this.GoodLab.Location = new System.Drawing.Point(117, 39);
            this.GoodLab.Name = "GoodLab";
            this.GoodLab.Size = new System.Drawing.Size(20, 17);
            this.GoodLab.TabIndex = 10;
            this.GoodLab.Text = "...";
            // 
            // IDtB
            // 
            this.IDtB.Location = new System.Drawing.Point(390, 58);
            this.IDtB.Name = "IDtB";
            this.IDtB.Size = new System.Drawing.Size(100, 22);
            this.IDtB.TabIndex = 11;
            this.IDtB.Visible = false;
            // 
            // Input_doc_good
            // 
            this.ClientSize = new System.Drawing.Size(602, 230);
            this.Controls.Add(this.IDtB);
            this.Controls.Add(this.GoodLab);
            this.Controls.Add(this.ChancelBtn);
            this.Controls.Add(this.OKbtn);
            this.Controls.Add(this.Count_tB);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Price_tB);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Name = "Input_doc_good";
            this.Text = "Позиция товара";
            this.Load += new System.EventHandler(this.Input_doc_good_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void Input_doc_good_Load(object sender, EventArgs e)
        {
            /*sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();*/
            if (Cmd==3||Cmd==4)
            {
                GoodLab.Text = Name;
                Price_tB.Text = Convert.ToString(Price);
                Count_tB.Text = Convert.ToString(Count);
            }

        }

        private void ChancelBtn_Click(object sender, EventArgs e)
        {
            this.Close();
            this.Dispose();
        }

        private void OKbtn_Click(object sender, EventArgs e)
        {
            int Good_Stock = 0;
            int Good_Count_NEW = Convert.ToInt32(Count_tB.Text);
            Price= Convert.ToDouble(Price_tB.Text);
            Count= Convert.ToInt32(Count_tB.Text);
            Price_Out = Convert.ToDouble(Price_tB.Text);
            string sqlExpression = "select * from Goods where ID=@ID";
            sqlConnection = new SqlConnection(connectionString);
            sqlConnection.Open();
            //sqlConnection = transaction_orig.Connection;
            using (sqlConnection)
            {
                SqlCommand command = new SqlCommand(sqlExpression, sqlConnection);
                SqlParameter idParam = new SqlParameter("@ID", Id);
                //if (transaction_orig != null) command.Transaction = transaction_orig;
                command.Parameters.Add(idParam);
                

                using (SqlDataReader reader = command.ExecuteReader())
                {

                    while (reader.Read())
                    {
                        Good_Stock = reader.GetInt32(5); //остаток
                    }
                }
            }
            ok = true;
            this.Close();
            this.Dispose();
        }
       
    }
}
