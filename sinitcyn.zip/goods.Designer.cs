﻿
namespace WinFormsApp1
{
    partial class Goods
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.New_Btn = new System.Windows.Forms.Button();
            this.Edt_Btn = new System.Windows.Forms.Button();
            this.Del_Btn = new System.Windows.Forms.Button();
            this.Rld_Btn = new System.Windows.Forms.Button();
            this.Flt_Btn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.AllGrpBtn = new System.Windows.Forms.Button();
            this.EdGrpBtn = new System.Windows.Forms.Button();
            this.InsGrpBtn = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.chsBtn = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.splitter2 = new System.Windows.Forms.Splitter();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.GoodsDataGridView = new System.Windows.Forms.DataGridView();
            this.splitter3 = new System.Windows.Forms.Splitter();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GoodsDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // New_Btn
            // 
            this.New_Btn.Location = new System.Drawing.Point(17, 22);
            this.New_Btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.New_Btn.Name = "New_Btn";
            this.New_Btn.Size = new System.Drawing.Size(94, 23);
            this.New_Btn.TabIndex = 1;
            this.New_Btn.Text = "Новый";
            this.New_Btn.UseVisualStyleBackColor = true;
            this.New_Btn.Click += new System.EventHandler(this.button1_Click);
            // 
            // Edt_Btn
            // 
            this.Edt_Btn.Location = new System.Drawing.Point(117, 22);
            this.Edt_Btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Edt_Btn.Name = "Edt_Btn";
            this.Edt_Btn.Size = new System.Drawing.Size(94, 23);
            this.Edt_Btn.TabIndex = 2;
            this.Edt_Btn.Text = "Изменить";
            this.Edt_Btn.UseVisualStyleBackColor = true;
            this.Edt_Btn.Click += new System.EventHandler(this.button2_Click);
            // 
            // Del_Btn
            // 
            this.Del_Btn.Location = new System.Drawing.Point(217, 22);
            this.Del_Btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Del_Btn.Name = "Del_Btn";
            this.Del_Btn.Size = new System.Drawing.Size(94, 23);
            this.Del_Btn.TabIndex = 3;
            this.Del_Btn.Text = "Удалить";
            this.Del_Btn.UseVisualStyleBackColor = true;
            this.Del_Btn.Click += new System.EventHandler(this.button3_Click);
            // 
            // Rld_Btn
            // 
            this.Rld_Btn.Location = new System.Drawing.Point(417, 22);
            this.Rld_Btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Rld_Btn.Name = "Rld_Btn";
            this.Rld_Btn.Size = new System.Drawing.Size(94, 23);
            this.Rld_Btn.TabIndex = 4;
            this.Rld_Btn.Text = "Обновить";
            this.Rld_Btn.UseVisualStyleBackColor = true;
            this.Rld_Btn.Click += new System.EventHandler(this.button4_Click);
            // 
            // Flt_Btn
            // 
            this.Flt_Btn.Location = new System.Drawing.Point(317, 22);
            this.Flt_Btn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Flt_Btn.Name = "Flt_Btn";
            this.Flt_Btn.Size = new System.Drawing.Size(94, 23);
            this.Flt_Btn.TabIndex = 5;
            this.Flt_Btn.Text = "Фильтр";
            this.Flt_Btn.UseVisualStyleBackColor = true;
            this.Flt_Btn.Click += new System.EventHandler(this.button5_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.AllGrpBtn);
            this.panel1.Controls.Add(this.EdGrpBtn);
            this.panel1.Controls.Add(this.InsGrpBtn);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.chsBtn);
            this.panel1.Controls.Add(this.Rld_Btn);
            this.panel1.Controls.Add(this.Flt_Btn);
            this.panel1.Controls.Add(this.New_Btn);
            this.panel1.Controls.Add(this.Edt_Btn);
            this.panel1.Controls.Add(this.Del_Btn);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 305);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1123, 55);
            this.panel1.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(753, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 17);
            this.label1.TabIndex = 12;
            this.label1.Text = "Группы";
            // 
            // AllGrpBtn
            // 
            this.AllGrpBtn.Location = new System.Drawing.Point(936, 22);
            this.AllGrpBtn.Name = "AllGrpBtn";
            this.AllGrpBtn.Size = new System.Drawing.Size(75, 23);
            this.AllGrpBtn.TabIndex = 11;
            this.AllGrpBtn.Text = "Все";
            this.AllGrpBtn.UseVisualStyleBackColor = true;
            this.AllGrpBtn.Click += new System.EventHandler(this.AllGrpBtn_Click);
            // 
            // EdGrpBtn
            // 
            this.EdGrpBtn.Location = new System.Drawing.Point(845, 22);
            this.EdGrpBtn.Name = "EdGrpBtn";
            this.EdGrpBtn.Size = new System.Drawing.Size(92, 23);
            this.EdGrpBtn.TabIndex = 10;
            this.EdGrpBtn.Text = "Изменить";
            this.EdGrpBtn.UseVisualStyleBackColor = true;
            this.EdGrpBtn.Click += new System.EventHandler(this.UpdGrpBtn_Click_1);
            // 
            // InsGrpBtn
            // 
            this.InsGrpBtn.Location = new System.Drawing.Point(753, 22);
            this.InsGrpBtn.Name = "InsGrpBtn";
            this.InsGrpBtn.Size = new System.Drawing.Size(92, 23);
            this.InsGrpBtn.TabIndex = 9;
            this.InsGrpBtn.Text = "Добавить";
            this.InsGrpBtn.UseVisualStyleBackColor = true;
            this.InsGrpBtn.Click += new System.EventHandler(this.InsGrpBtn_Click_1);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(607, 20);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 8;
            this.button2.Text = "инс cmd";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(526, 22);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // chsBtn
            // 
            this.chsBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chsBtn.Location = new System.Drawing.Point(1017, 22);
            this.chsBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chsBtn.Name = "chsBtn";
            this.chsBtn.Size = new System.Drawing.Size(94, 23);
            this.chsBtn.TabIndex = 6;
            this.chsBtn.Text = "Выбрать";
            this.chsBtn.UseVisualStyleBackColor = true;
            this.chsBtn.Click += new System.EventHandler(this.chooseBtn_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.splitter3);
            this.panel2.Controls.Add(this.splitter2);
            this.panel2.Controls.Add(this.treeView1);
            this.panel2.Controls.Add(this.dataGridView1);
            this.panel2.Controls.Add(this.GoodsDataGridView);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1123, 305);
            this.panel2.TabIndex = 7;
            // 
            // splitter2
            // 
            this.splitter2.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitter2.Location = new System.Drawing.Point(753, 199);
            this.splitter2.Name = "splitter2";
            this.splitter2.Size = new System.Drawing.Size(370, 3);
            this.splitter2.TabIndex = 5;
            this.splitter2.TabStop = false;
            // 
            // treeView1
            // 
            this.treeView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView1.Location = new System.Drawing.Point(753, 199);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(370, 106);
            this.treeView1.TabIndex = 3;
            this.treeView1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView1.Location = new System.Drawing.Point(753, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(370, 199);
            this.dataGridView1.TabIndex = 2;
            // 
            // GoodsDataGridView
            // 
            this.GoodsDataGridView.AllowUserToAddRows = false;
            this.GoodsDataGridView.AllowUserToDeleteRows = false;
            this.GoodsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GoodsDataGridView.Dock = System.Windows.Forms.DockStyle.Left;
            this.GoodsDataGridView.Location = new System.Drawing.Point(0, 0);
            this.GoodsDataGridView.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GoodsDataGridView.MultiSelect = false;
            this.GoodsDataGridView.Name = "GoodsDataGridView";
            this.GoodsDataGridView.ReadOnly = true;
            this.GoodsDataGridView.RowHeadersWidth = 51;
            this.GoodsDataGridView.RowTemplate.Height = 29;
            this.GoodsDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.GoodsDataGridView.Size = new System.Drawing.Size(753, 305);
            this.GoodsDataGridView.TabIndex = 1;
            this.GoodsDataGridView.DataBindingComplete += new System.Windows.Forms.DataGridViewBindingCompleteEventHandler(this.GoodsDataGridView_DataBindingComplete);
            this.GoodsDataGridView.Sorted += new System.EventHandler(this.GoodsDataGridView_Sorted);
            // 
            // splitter3
            // 
            this.splitter3.Location = new System.Drawing.Point(753, 202);
            this.splitter3.Name = "splitter3";
            this.splitter3.Size = new System.Drawing.Size(3, 103);
            this.splitter3.TabIndex = 7;
            this.splitter3.TabStop = false;
            // 
            // Goods
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1123, 360);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Goods";
            this.Text = "Товары";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GoodsDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button New_Btn;
        private System.Windows.Forms.Button Edt_Btn;
        private System.Windows.Forms.Button Del_Btn;
        private System.Windows.Forms.Button Rld_Btn;
        private System.Windows.Forms.Button Flt_Btn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button chsBtn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button InsGrpBtn;
        private System.Windows.Forms.Button EdGrpBtn;
        private System.Windows.Forms.Splitter splitter2;
        private System.Windows.Forms.Button AllGrpBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Splitter splitter3;
        private System.Windows.Forms.DataGridView GoodsDataGridView;
    }
}