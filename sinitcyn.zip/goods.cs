﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace WinFormsApp1
{
    public partial class Goods : Form
    {
        private int op;
        private SqlConnection sqlConnection = null;
        private SqlDataAdapter SqlDataAdapter = null;
        private SqlCommandBuilder SqlCommandBuilder = null;
        
        string filter;
        Boolean f_active = false;
        DataSet dataSet ;
        DataSet dataSetG;

        public int ID = -1;
        public string FNameVal="";
        public double Price1Val =-1;
        double Price2Val=-1;
        public double PriceOut1Val =-1;
        double PriceOut2Val=-1;
        public int VATVal = -1;


        public Goods(int op_cmd)
        {
            op = op_cmd;
            InitializeComponent();
            dataSet = CreateDataSet();
            dataSetG = CreateDataSetG();
            GoodsDataGridView.DataSource = dataSet.Tables["dbo.Goods"];
            
            GoodsDataGridView.DataSource = dataSet.Tables[0];
            dataGridView1.DataSource = dataSetG.Tables["dbo.Groups"];
            TreeR(treeView1,dataSetG);
            /*for (int j = 0; j < treeView1.Nodes.Count; j++)
            {
                  MessageBox.Show("In:"+treeView1.Nodes[j].Index.ToString() + " Id:" + treeView1.Nodes[j].Name+" Text:"+ treeView1.Nodes[j].Text+" Tag:"+ treeView1.Nodes[j].Tag);
                //MessageBox.Show(treeView1.Nodes[j].Name);
            }*/
            // Set_ColumnHeader();
        }

        
        private DataSet CreateDataSet(string newSql = "")
        {
            string connectionString = main.connectionString;
            using (SqlConnection conn = new
                   SqlConnection(connectionString))
            {
                //conn.Close();
                conn.Open();
                //MessageBox.Show("Успешное подключение !");
                SqlCommand cmd = new SqlCommand("SELECT G.*,GR.Name as GR_NAME FROM dbo.Goods G " +
                    "LEFT JOIN GROUPS GR ON G.GROUPS_ID = GR.ID "+
                    "WHERE G.ID=G.ID " + newSql, conn);
               /* SqlCommand cmd = new SqlCommand("SELECT G.*,(select GR.Name as GR_NAME FROM GROUPS GR where G.GROUPS_ID = GR.ID) from dbo.Goods G WHERE G.ID = G.ID "+newSql, conn);
                String c = "SELECT G.*,(select GR.Name as GR_NAME FROM GROUPS GR where G.GROUPS_ID = GR.ID) from dbo.Goods G WHERE G.ID = G.ID ";*/
                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    // Объекты‐адаптеры умеют взаимодействовать  
                    // с конкретными серверами баз данных  
                    adapter.TableMappings.Add("Table", "dbo.Goods");
                    adapter.SelectCommand = cmd;
                    DataSet dataSet = new DataSet("dbo.Goods");
                    // Поместить все строки в набор данных  
                    adapter.Fill(dataSet);


                    /*// Создаем объект DataAdapter
                    SqlDataAdapter adapter2 = new SqlDataAdapter(c, conn );
                    // Создаем объект DataSet
                    DataSet ds = new DataSet();
                    // Заполняем Dataset
                    adapter2.Fill(ds);*/

                    return dataSet;
                    //return ds;
                }

            }
        }

        private DataSet CreateDataSetG(string newSql = "")
        {
            string connectionString = main.connectionString;
            using (SqlConnection conn = new
                   SqlConnection(connectionString))
            {
                conn.Close();
                conn.Open();
                //MessageBox.Show("Успешное подключение !");
                SqlCommand cmd = new SqlCommand("SELECT * FROM dbo.Groups WHERE Tables_ID=(Select ID from Tables T where T.Name='Goods') " + newSql, conn);
                
                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    // Объекты‐адаптеры умеют взаимодействовать  
                    // с конкретными серверами баз данных  
                    adapter.TableMappings.Add("Table", "dbo.Groups");
                    adapter.SelectCommand = cmd;
                    DataSet dataSet = new DataSet("dbo.Groups");
                    // Поместить все строки в набор данных  
                    adapter.Fill(dataSet);
                    return dataSet;
                }

            }
        }

        private void Set_ColumnHeader()
        {
            //обзываем
            GoodsDataGridView.Columns["FName"].DisplayIndex = 0;
            GoodsDataGridView.Columns["FName"].HeaderText = "Название";
            GoodsDataGridView.Columns["Price"].DisplayIndex = 1;
            GoodsDataGridView.Columns["Price"].HeaderText = "Цена";
            GoodsDataGridView.Columns["Price"].CellTemplate.Style.Format = "N2";
            GoodsDataGridView.Columns["Price_Out"].DisplayIndex = 2;
            GoodsDataGridView.Columns["Price_Out"].HeaderText = "Цена продажи";
            GoodsDataGridView.Columns["Price_Out"].CellTemplate.Style.Format = "N2";
            GoodsDataGridView.Columns["VAT"].DisplayIndex = 3;
            GoodsDataGridView.Columns["VAT"].HeaderText = "НДС%";
            GoodsDataGridView.Columns["Balance"].DisplayIndex = 4;
            GoodsDataGridView.Columns["Balance"].HeaderText = "Остаток";
            GoodsDataGridView.Columns["GR_NAME"].HeaderText = "Группа";
            if (GoodsDataGridView.Columns["ID"].Visible == true) GoodsDataGridView.Columns["ID"].Visible = false;
            if (GoodsDataGridView.Columns["Groups_ID"].Visible == true) GoodsDataGridView.Columns["Groups_ID"].Visible = false;
        }



        private void button1_Click(object sender, EventArgs e)
        {
            string GRPkey = "-1";
            if (treeView1.SelectedNode != null)
            {
                GRPkey = treeView1.SelectedNode.Name.ToString();
                //key = treeView1.SelectedNode.Tag.ToString();
            }
            int row = GoodsDataGridView.RowCount;
            
            goods_editF ge = new goods_editF(1,-1,"",0,0,0,Convert.ToInt32(GRPkey));
            ge.ShowDialog();
            GridR(1);
            //GoodsDataGridView.CurrentCell = GoodsDataGridView.Rows[row].Cells[0];
            //Set_ColumnHeader();
        }

        private void GridR(int cmd, string fname="", double price1 =0, double price2 =0,int vat=0, double priceOut1 =0, double priceOut2 =0, int Groups_ID=0)
        {
            string w = "";
            //GoodsDataGridView.DataSource = null;
            int r = 0;
                      
            /*if (dataSet.Tables[0].Rows.Count > 0)
                r = GoodsDataGridView.CurrentCell.RowIndex;*/

            if (fname != null && fname != "")
            {
                w = w + " AND FNAME='" + fname + "' ";
                if (price1 > 0) w = w + " AND Price>" + price1;
                if (price2 > 0) w = w + " AND Price<" + price2;
                if (priceOut1 > 0) w = w + " AND PriceOut>" + PriceOut1Val.ToString();
                if (priceOut2 > 0) w = w + " AND PriceOut<" + PriceOut2Val.ToString();
                
            }

            if (Groups_ID > 0) w = w + " and Groups_ID=" + Groups_ID.ToString();

            dataSet = null;
            dataSet = CreateDataSet(" "+ w); //установка фильтра
            GoodsDataGridView.DataSource = dataSet.Tables["dbo.Goods"];
            if (GoodsDataGridView.RowCount>0)
            switch (cmd)
            {
                case 1:
                    GoodsDataGridView.CurrentCell = GoodsDataGridView.Rows[GoodsDataGridView.RowCount - 1].Cells[1]; //добавление
                    break;
                case 2:
                    GoodsDataGridView.CurrentCell = GoodsDataGridView.Rows[r].Cells[1];//редактирование
                    break;
                case 3:
                    GoodsDataGridView.CurrentCell = GoodsDataGridView.Rows[r - 1].Cells[1];//удаление
                    break;
                default:
                    break;
            }
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            int row = GoodsDataGridView.CurrentRow.Index;
            int col= GoodsDataGridView.CurrentCell.ColumnIndex;
            int ID= Convert.ToInt32(dataSet.Tables[0].Rows[GoodsDataGridView.CurrentRow.Index]["ID"].ToString());
            SqlConnection conn = new SqlConnection(main.connectionString);
            conn.Close();
            conn.Open();
            using (SqlCommand cmd = new SqlCommand("EXEC RECALC_STOCK @ID", conn))
            {
                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {

                    cmd.Parameters.Add(new SqlParameter("@ID", ID));
                    // Здесь используется метод ExecuteNonQuery(), потому  
                    // что мы не выдаем запрос на чтение строк во время  
                    // вставки 
                    int rowsAffected = cmd.ExecuteNonQuery();
                    MessageBox.Show(rowsAffected.ToString() + " rows affected");

                }
            }
            dataSet = CreateDataSet();
            GridR(1);
            //GoodsDataGridView.CurrentCell = GoodsDataGridView.Rows[row].Cells[col];
        }

        private void button2_Click(object sender, EventArgs e) //изменить
        {
            GoodsDataGridView.Focus();
            int row = GoodsDataGridView.CurrentRow.Index;
            //int ID = Convert.ToInt32(GoodsDataGridView.CurrentRow.Cells["ID"].Value.ToString());
            int ID = Convert.ToInt32(dataSet.Tables[0].Rows[row]["ID"].ToString());
                //string FNameVal = GoodsDataGridView.CurrentRow.Cells["FName"].Value.ToString();
                string FNameVal = dataSet.Tables[0].Rows[row]["FName"].ToString();
            //double PriceVal = Convert.ToDouble(GoodsDataGridView.CurrentRow.Cells["Price"].Value.ToString());
            double PriceVal = Convert.ToDouble(dataSet.Tables[0].Rows[row]["Price"].ToString());

            //double PriceOutVal = Convert.ToDouble(GoodsDataGridView.CurrentRow.Cells["Price_Out"].Value.ToString());
            double PriceOutVal = Convert.ToDouble(dataSet.Tables[0].Rows[row]["Price_Out"].ToString());
            //int VATVal = Convert.ToInt32(GoodsDataGridView.CurrentRow.Cells["VAT"].Value.ToString());
            int VATVal = Convert.ToInt32(dataSet.Tables[0].Rows[row]["VAT"].ToString());
            
            goods_editF ge = new goods_editF(2, ID,FNameVal,PriceVal,PriceOutVal,VATVal);
            ge.ShowDialog();
            GridR(2);
            //Set_ColumnHeader();
            //GoodsDataGridView.CurrentCell = GoodsDataGridView.Rows[row].Cells[0];
            //GoodsDataGridView.CurrentCell = GoodsDataGridView.Rows[row].Cells[2];
        }

        private void button3_Click(object sender, EventArgs e)
        {
            GoodsDataGridView.Focus();
            int row = GoodsDataGridView.CurrentRow.Index;
            //int ID = Convert.ToInt32(GoodsDataGridView.CurrentRow.Cells["ID"].Value.ToString());
            int ID = Convert.ToInt32(dataSet.Tables[0].Rows[GoodsDataGridView.CurrentRow.Index]["ID"].ToString());
            string connectionString = main.connectionString;
            using (SqlConnection conn = new
                   SqlConnection(connectionString))
            {
                conn.Close();

                conn.Open();
                //MessageBox.Show("Успешное подключение !");

                /*//проверка на использование ID
                string sqlExpression = "select (select count(IG.Count) from Input_Goods IG where IG.Goods_ID=@goods_id) as IG_Count, (select count(OG.Count) from Output_Goods OG where OG.Goods_ID=@goods_id) as OG_Count)";
                try
                {
                    SqlCommand command = new SqlCommand(sqlExpression, conn);
                    SqlParameter Goods_ID_Param = new SqlParameter("@goods_id", ID);
                    // добавляем параметр к команде
                    command.Parameters.Add(Goods_ID_Param);
                    int number = command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }*/


                using (SqlCommand cmd = new SqlCommand("DELETE FROM dbo.Goods where ID=@ID", conn))
                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {

                    cmd.Parameters.Add(new SqlParameter("@ID", ID));
                    // Здесь используется метод ExecuteNonQuery(), потому  
                    // что мы не выдаем запрос на чтение строк во время  
                    // вставки 
                    int rowsAffected = cmd.ExecuteNonQuery();
                    MessageBox.Show(rowsAffected.ToString() + " rows affected by delete");

                }

            }
         //   goods_editF ge = new goods_editF(3, ID);
         //   ge.ShowDialog();
            GridR(3);
            //Set_ColumnHeader();
            if (row>1) GoodsDataGridView.CurrentCell = GoodsDataGridView.Rows[row - 1].Cells[2];
        }

        private void button5_Click(object sender, EventArgs e) //фильтр
        {
            Goods_F gf = new Goods_F();
            /*установка в форме сохранённых значений */
            gf.F_Act=f_active;
            gf.ResFname=FNameVal;
            gf.ResPrice1=Price1Val;
            gf.ResPrice2 = Price2Val;
            gf.ResPriceOut1 = PriceOut1Val;
            gf.ResPriceOut2 = PriceOut2Val;
            gf.ResVAT = VATVal;
            /*показ формы фильтра*/
            gf.ShowDialog();
            /*сохранение  установленых в форме значений*/
            f_active = gf.F_Act; /*значения элементов фильтра*/
            filter = gf.ResText; /*строка фильтра*/
            FNameVal = gf.ResFname;
            Price1Val = Convert.ToDouble(gf.ResPrice1);
            Price2Val = Convert.ToDouble(gf.ResPrice2);
            PriceOut1Val = Convert.ToDouble(gf.ResPriceOut1);
            PriceOut2Val = Convert.ToDouble(gf.ResPriceOut2);
            VATVal = Convert.ToInt16(gf.ResVAT);

            if (gf.Set == true) /*если нажата ок*/
            {
                if (f_active == true) /*если активен*/
                {
                    dataSet = CreateDataSet(" " + filter);
                    GoodsDataGridView.DataSource = dataSet.Tables["dbo.Goods"];
                }
                else /*иначе бе фильтра*/
                { //GridR();
                    dataSet = CreateDataSet("");
                    GoodsDataGridView.DataSource = dataSet.Tables["dbo.Goods"];
                }
            }

                
            //Set_ColumnHeader();
            return; 
        }

        private void chooseBtn_Click(object sender, EventArgs e) //кнопка выбора
        {
            if (op==1)
            {
                /*ID=Convert.ToInt32(GoodsDataGridView.CurrentRow.Cells["ID"].Value.ToString());
                FNameVal = GoodsDataGridView.CurrentRow.Cells["FName"].Value.ToString();
                Price1Val = Convert.ToDouble(GoodsDataGridView.CurrentRow.Cells["Price"].Value.ToString());
                PriceOut1Val = Convert.ToDouble(GoodsDataGridView.CurrentRow.Cells["Price_Out"].Value.ToString());
                VATVal = Convert.ToInt32(GoodsDataGridView.CurrentRow.Cells["VAT"].Value.ToString());
                this.Close();*/
                ID = Convert.ToInt32(dataSet.Tables[0].Rows[GoodsDataGridView.CurrentRow.Index]["ID"].ToString());
                FNameVal = dataSet.Tables[0].Rows[GoodsDataGridView.CurrentRow.Index]["FName"].ToString();
                Price1Val = Convert.ToDouble(dataSet.Tables[0].Rows[GoodsDataGridView.CurrentRow.Index]["Price"].ToString());
                PriceOut1Val = Convert.ToDouble(dataSet.Tables[0].Rows[GoodsDataGridView.CurrentRow.Index]["Price_Out"].ToString());
                VATVal = Convert.ToInt32(dataSet.Tables[0].Rows[GoodsDataGridView.CurrentRow.Index]["VAT"].ToString());
                this.Close();
                this.Dispose();
            }
        }

        private void GoodsDataGridView_Sorted(object sender, EventArgs e)
        {
        }

        private void GoodsDataGridView_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            Set_ColumnHeader();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            /*DataTable table = new DataTable();
            table.Columns.Add("Id", typeof(int));
            dataGridView1.DataSource = table;*/
            for (int i = 0; i < dataSetG.Tables[0].Rows.Count; i++)
            {
                TreeNode node = new TreeNode();
                node.Nodes.Add(dataSetG.Tables[0].Rows[i]["Name"].ToString());
                treeView1.Nodes.Add(node);
            }
            //treeView1.Nodes[0].Nodes[0].Nodes.Add("Grandchild");
            
        }

        /*private void Loadtree()
        {
            
            foreach (DataRow dr in dataSetG.Tables[0].Rows)
            {
                treeView1.Nodes.Clear();
                TreeNode node = new TreeNode();
                node.Text = (string)dr["Name"];
                node.Tag = dr["ID"];
                treeView1.Nodes.Add(node);
                AddNodes(node);
            }

        }

        private void AddNodes(TreeNode node)
        {
            string connectionString = main.connectionString;
            using (SqlConnection conn = new
                   SqlConnection(connectionString))
            {
                conn.Close();
                conn.Open();
                //MessageBox.Show("Успешное подключение !");
                SqlCommand cmd = new SqlCommand("SELECT * FROM dbo.Goods WHERE ID=@ID ", conn);
                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    // Объекты‐адаптеры умеют взаимодействовать  
                    // с конкретными серверами баз данных  
                    adapter.TableMappings.Add("Table", "dbo.Goods");
                    adapter.SelectCommand = cmd;
                    DataSet dataSet = new DataSet("dbo.Goods");
                    // Поместить все строки в набор данных  
                    adapter.Fill(dataSet);


                    //DataTable requirmentTable = adapter.GetData();
                    foreach (DataRow dr in cmd.Select("ID = " + node.Tag.ToString()))
                    {
                        TreeNode node1 = new TreeNode();
                        node1.Text = (string)dr["Name"];
                        node1.Tag = dr["ID"];
                        node.Nodes.Add(node1);
                    }
                }
            }
        }*/

        public void TreeR(TreeView treeView1, DataSet dataset)
        {
            //main.TreeR(treeView1, dataSetG);
            treeView1.Nodes.Clear();
            /*раб
            for (int i = 0; i < dataSetG.Tables[0].Rows.Count; i++)
            {
                TreeNode node = new TreeNode();
                string key = dataSetG.Tables[0].Rows[i]["ID"].ToString();
                string name = dataSetG.Tables[0].Rows[i]["Name"].ToString();
                string p_g_id = dataSetG.Tables[0].Rows[i]["P_G_ID"].ToString();
               
                //node.Nodes.Add(key, name);
                node.Text = name;
                node.Name= name;
                node.Tag = key;
                if (p_g_id != "" && p_g_id != "0")
                {
                    TreeNode[] findResult= treeView1.Nodes.Find(p_g_id, true);
                    //treeView1.Nodes[0]
                    if (findResult.Count() > 0)
                    {
                        findResult.First().Nodes.Add(key,node.Text);
                    }
                } else treeView1.Nodes.Add(key, node.Text);
                
            }
            //TreeNode[] findResult = treeView1.Nodes.IndexOf(node);
            //if (findResult.Length > 0) MessageBox.Show("Нашёл");
            for (int j = 0; j < treeView1.Nodes.Count; j++)
            {
               // MessageBox.Show("In:"+treeView1.Nodes[j].Index.ToString() + " Id:" + treeView1.Nodes[j].Tag+" T:"+ treeView1.Nodes[j].Text);
            }*/
            
            
            for (int i = 0; i < dataSetG.Tables[0].Rows.Count; i++)
            {
                TreeNode node = new TreeNode();
                string key = dataSetG.Tables[0].Rows[i]["ID"].ToString();
                string name = dataSetG.Tables[0].Rows[i]["Name"].ToString();
                //string p_g_id = dataSetG.Tables[0].Rows[i]["P_G_ID"].ToString();
                string p_g_id = dataSetG.Tables[0].Rows[i]["P_G_ID"].ToString();

                //node.Nodes.Add(key, name);
                node.Text = name+" t:"+key;
                node.Name = key;
                node.Tag = p_g_id;
                if (p_g_id != "" && p_g_id != "-1"&& p_g_id != "0")
                {
                    TreeNode[] findResult = treeView1.Nodes.Find(p_g_id, true);
                    //treeView1.Nodes[0]
                    if (findResult.Count() > 0)
                    {
                        findResult.First().Nodes.Add(node);
                        
                    }
                }
                else treeView1.Nodes.Add(node);

            }
            //TreeNode[] findResult = treeView1.Nodes.IndexOf(node);
            //if (findResult.Length > 0) MessageBox.Show("Нашёл");
            for (int j = 0; j < treeView1.Nodes.Count; j++)
            {
                 //MessageBox.Show("In:"+treeView1.Nodes[j].Index.ToString() + " Id:" + treeView1.Nodes[j].Name+" T:"+ treeView1.Nodes[j].Text);
                //MessageBox.Show(treeView1.Nodes[j].Name);

            }
                        
            /*for (int i = 0; i < dataSetG.Tables[0].Rows.Count; i++)
            {
                TreeNode node = new TreeNode();
                string key = dataSetG.Tables[0].Rows[i]["ID"].ToString();
                string name = dataSetG.Tables[0].Rows[i]["Name"].ToString();
                string p_g_id = dataSetG.Tables[0].Rows[i]["P_G_ID"].ToString();

               // node.Nodes.Add(key, name);
                node.Text = name;
                node.Name = name;
                node.Tag = key;
                if (p_g_id != "" && p_g_id != "0")
                {
                    //TreeNode[] findResult = treeView1.Nodes.Find(p_g_id, false);

                    for (int k = 0; k < treeView1.Nodes.Count; k++)
                    { 
                    if ((string)treeView1.Nodes[k].Tag==p_g_id) treeView1.Nodes[k].Nodes.Add(node);
                    }
                }
                else treeView1.Nodes.Add(node);

            }
            //TreeNode[] findResult = treeView1.Nodes.IndexOf(node);
            //if (findResult.Length > 0) MessageBox.Show("Нашёл");
            for (int j = 0; j < treeView1.Nodes.Count; j++)
            {
                //MessageBox.Show("In:"+treeView1.Nodes[j].Index.ToString() + " Id:" + treeView1.Nodes[j].Tag+" T:"+ treeView1.Nodes[j].Text);
                MessageBox.Show(" Id:" + treeView1.Nodes[j].Tag);
            }*/


            /*for (int i = 0; i < dataSetG.Tables[0].Rows.Count; i++)
            {

                TreeNode node = new TreeNode();
                string key = dataSetG.Tables[0].Rows[i]["ID"].ToString();
                string name = dataSetG.Tables[0].Rows[i]["Name"].ToString();
                string p_g_id = dataSetG.Tables[0].Rows[i]["P_G_ID"].ToString();

                //TreeNode node1 = new TreeNode();
                //node1.Nodes.Add("2");
                node.Nodes.Add(key, name);
                node.Text = name;
                node.Name = name;
                node.Tag = key;
                bool found = false;

                if (p_g_id != ""&& p_g_id!="0")
                {
//                        TreeNode[] findResult=null;

                    for (int j = 0; j < treeView1.Nodes[0].Nodes.Count; j++)
                    {
                        if ((string)treeView1.Nodes[j].Tag == Convert.ToString(p_g_id))
                        {
                            treeView1.Nodes[j].Nodes.Add(node);
                            found = true;
                        }

                    }
                } else treeView1.Nodes.Add(node);
                //   node.Nodes.Add(node1);

            }*/


            /*treeView1.Nodes.Clear();
            for (int i = 0; i < dataSetG.Tables[0].Rows.Count; i++)
            {
                string key = dataSetG.Tables[0].Rows[i]["ID"].ToString();
                string name = dataSetG.Tables[0].Rows[i]["Name"].ToString();
                string p_g_id = dataSetG.Tables[0].Rows[i]["P_G_ID"].ToString();
                TreeNode node1 = new TreeNode();
                node1.Nodes.Add(key, name);
                node1.Tag = p_g_id;
                treeView1.Nodes.Add(node1);
            }

            for (int j = 1; j < treeView1.Nodes.Count-1; j++)
            {
                TreeNode node1 = new TreeNode();
                string p_g_id = dataSetG.Tables[0].Rows[j-1]["P_G_ID"].ToString();
                TreeNode[] findResult = treeView1.Nodes.Find(p_g_id, true);
                if (findResult.Count() > 0)
                {
                    //findResult.First().Nodes.Add(key, name);
                    findResult.First().Nodes.Add(node1);
                    //MessageBox.Show(dataSetG.Tables[0].Rows[i]["P_G_ID"].ToString());
                }   else treeView1.Nodes.Add(node1);
                MessageBox.Show(treeView1.Nodes[j].Index.ToString()+" "+ treeView1.Nodes[j].Tag);
            }*/
            /* поиск 
            TreeNode[] findResult = treeView1.Nodes.Find("1", true);
            if (findResult.Count() > 0) MessageBox.Show("!");*/


            /*for (int i = 0; i < dataSetG.Tables[0].Rows.Count; i++)
            {
                TreeNode node = new TreeNode();
                string key = dataSetG.Tables[0].Rows[i]["P_G_ID"].ToString();
                TreeNode[] findResult = treeView1.Nodes.Find(key, true);
                if (findResult.Count() > 0)
                {
                    MessageBox.Show(dataSetG.Tables[0].Rows[i]["P_G_ID"].ToString());
                }
            }*/
            /*TreeNode temp = treeView1.Nodes.Add("1", "TestNode");
            TreeNode[] findResult = treeView1.Nodes.Find("1-", false);
            if (findResult.Count() > 0) MessageBox.Show("!");*/
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            string connectionString = main.connectionString;
                     using (SqlConnection conn = new
                           SqlConnection(connectionString))
                    {

                        conn.Open();
                        using (SqlCommand cmd = new SqlCommand("INSERT INTO dbo.Groups (P_G_ID,Tables_ID,Name) VALUES (null,2,@Name)", conn))
                        using (SqlDataAdapter adapter = new SqlDataAdapter())
                        {
                            cmd.Parameters.Add(new SqlParameter("@Name", "222"));
                            
                            // Здесь используется метод ExecuteNonQuery(), потому  
                            // что мы не выдаем запрос на чтение строк во время  
                            // вставки 
                            int rowsAffected = cmd.ExecuteNonQuery();
                            MessageBox.Show(rowsAffected.ToString() + " rows affected by insert");
                        }

                    }
            }

        private void InsGrpBtn_Click_1(object sender, EventArgs e)
        {
            int Parent = -1;
            if (treeView1.SelectedNode!=null) 
                Parent = treeView1.SelectedNode.Index;//индекс активная ветвь
            string p_g_id = "-1"; //id предка
            //string t = treeView1.Nodes[0].Tag.ToString();
            
            if (treeView1.SelectedNode != null)
            {
                p_g_id = treeView1.SelectedNode.Name.ToString(); //id активной ветви
            }
            

            GroupE ge = new GroupE(1,2, Convert.ToInt32(p_g_id));
            ge.ShowDialog();
            dataGridView1.DataSource = null;
            dataSetG = null;
            dataSetG = CreateDataSetG();
            dataGridView1.DataSource = dataSetG.Tables["dbo.Groups"];
            TreeR(treeView1, dataSetG);
            if (Parent>-1)
              treeView1.Nodes[Parent].Expand(); //раскрытие предка созданной ветви
        }

        private void UpdGrpBtn_Click_1(object sender, EventArgs e)
        {
            
            string key = "";
            string p_g_id = "";
            if (treeView1.SelectedNode != null)
            {
                key = treeView1.SelectedNode.Name.ToString();
                //key = treeView1.SelectedNode.Tag.ToString();
                p_g_id = treeView1.SelectedNode.Tag.ToString();
            }
            else
            {
                MessageBox.Show("Выделите группу.");
                return;
               // exit(0);
            }

            
            int Parent = -1;
            if (treeView1.SelectedNode != null)
                Parent = treeView1.SelectedNode.Index; 
            if (p_g_id == "") p_g_id = "-1";

            GroupE ge = new GroupE(2, 2, Convert.ToInt32(p_g_id), Convert.ToInt32(key));
            
            ge.ShowDialog();
            dataGridView1.DataSource = null;
            dataSetG = null;
            dataSetG = CreateDataSetG();
            dataGridView1.DataSource = dataSetG.Tables["dbo.Groups"];
            TreeR(treeView1, dataSetG);
            //treeView1.Nodes[Parent].Expand();
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            GridR(1, "", 0, 0, 0, 0, 0, Convert.ToInt32(treeView1.SelectedNode.Name.ToString()));
        }

        private void AllGrpBtn_Click(object sender, EventArgs e)
        {
            GridR(1);
            treeView1.SelectedNode = null;

        }
    }
    
}
