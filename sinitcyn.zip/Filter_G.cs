﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Goods_F : Form
    {
        public Boolean F_Act { set; get; } //результат выбранного для возврата
        public string ResText { set; get; } 
        public string ResFname { set; get; }
        public double ResPrice1 { set; get; }
        public double ResPrice2 { set; get; }
        public double ResVAT { set; get; }
        public double ResPriceOut1 { set; get; }
        public double ResPriceOut2 { set; get; }
        public Boolean Set { set; get; }//результат выбранного для возврата

        public Goods_F()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Set = false;
            this.Close();
            this.Dispose();
        }

        private void SetBtn_Click(object sender, EventArgs e)
        {
            string Filter = "";
            
            /*обнуление*/
            ResText = "";
            ResFname = "";
            ResPrice1 = -1;
            ResPrice2 = -1;
            ResVAT = -1;
            ResPriceOut1 = -1;
            ResPriceOut2 = -1;
            

            F_Act = Active_cB.Checked;
            if (FnameTB.Text != "")
            {
                Filter = Filter + " and FNAME=  '" + FnameTB.Text+"'";
                ResFname = FnameTB.Text;
            }
            if (Price1tB.Text != "")
                {
                    Filter = Filter + " and PRICE> " + Price1tB.Text;
                    ResPrice1 = Convert.ToDouble(Price1tB.Text);
                }
            if (Price2tB.Text != "")
                {
                    Filter = Filter + " and PRICE< " + Price2tB.Text;
                    ResPrice2 = Convert.ToDouble(Price2tB.Text);
                }
            if (VAT_tB.Text != "")
                {
                    Filter = Filter + " and VAT= " + VAT_tB.Text;
                    ResVAT = Convert.ToDouble(VAT_tB.Text);
                }
            if (BalanceTB.Text != "")
                {
                    Filter = Filter + " and Balance> " + BalanceTB.Text;
                }
            if (PriceOut1TB.Text != "")
                {
                    Filter = Filter + " and PRICE_OUT> " + PriceOut1TB.Text;
                    ResPriceOut1 = Convert.ToDouble(PriceOut1TB.Text);
                }
            if (PriceOut2TB.Text != "")
                {
                    Filter = Filter + " and PRICE_OUT< " + PriceOut2TB.Text;
                    ResPriceOut2 = Convert.ToDouble(PriceOut2TB.Text);
                }
            Set = true;
            ResText = Filter;
            this.Close();
        }

        private void Goods_F_Load(object sender, EventArgs e)
        {
            FnameTB.Text= ResFname;
            Active_cB.Checked = F_Act;
            if (ResPrice1 != -1) Price1tB.Text = ResPrice1.ToString(); else Price1tB.Text = "";
            if (ResPrice2 != -1) Price2tB.Text = ResPrice2.ToString(); else Price2tB.Text = "";
            if (ResVAT != -1) VAT_tB.Text = ResVAT.ToString(); else VAT_tB.Text = "";
            if (ResPriceOut1 != -1) PriceOut1TB.Text = ResPriceOut1.ToString(); else PriceOut1TB.Text = "";
            if (ResPriceOut2 != -1) PriceOut2TB.Text = ResPriceOut2.ToString(); else PriceOut2TB.Text = "";
            Set = false;
        }
    }
}
