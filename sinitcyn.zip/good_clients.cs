﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Windows.Forms.DataVisualization.Charting;


namespace WinFormsApp1
{
    public partial class GoodClientsForm : Form
    {
        private SqlConnection conn = null;
        private SqlDataAdapter SqlDataAdapter = null;
        private SqlCommandBuilder SqlCommandBuilder = null;
        string connectionString = main.connectionString;
        DataSet dataSet;

        int Good_Id = -1;



        public GoodClientsForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Goods g = new Goods(1);
            g.ShowDialog();
            Good_Id = g.ID;
            GoodLab.Text = g.FNameVal;
        }

        private void ReloadPrn(int GoodsID)
        {
            conn = new SqlConnection(connectionString);
            conn.Open();

            string sqlExpression = "select C.FName, ID.Client_ID,sum(IG.count) as Count ,sum(IG.count * IG.Price) as Sum "+
                "from Input_Goods IG,goods G, Input_Doc ID,Clients C "+
                "where g.id = ig.GoodsID and ID.id = IG.Input_Doc_ID "+
                "and g.id = @goodsid and C.id = ID.Client_ID " +
                "group by ID.Client_ID,C.FName";

            using (conn) 
            {
                SqlCommand cmd = new SqlCommand(sqlExpression, conn);

                // создаем параметр для возраста
                SqlParameter goods_idParam = new SqlParameter("@goodsid", Good_Id);
                // добавляем параметр к команде
                cmd.Parameters.Add(goods_idParam);

                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    adapter.SelectCommand = cmd;
                    DataSet ds = new DataSet();
                    adapter.Fill(ds);
                    GoodsMoveDataGridView.DataSource = ds.Tables[0];
                }

                SqlDataReader reader = cmd.ExecuteReader();
            }
        }

        private void Set_ColumnHeader()
        {
            /*переименовывание*/
            /*отодвигание в конец*/
            GoodsMoveDataGridView.Focus();
            GoodsMoveDataGridView.Columns["FName"].DisplayIndex = 0;
            GoodsMoveDataGridView.Columns["FName"].HeaderText = "Номер";
            GoodsMoveDataGridView.Columns["Count"].DisplayIndex = 1;
            GoodsMoveDataGridView.Columns["Count"].HeaderText = "шт.";
            GoodsMoveDataGridView.Columns["Sum"].DisplayIndex = 2;
            GoodsMoveDataGridView.Columns["Sum"].HeaderText = "Сумма";

            GoodsMoveDataGridView.Columns["Client_ID"].Visible = false;
        }

        private void BuildBtn_Click(object sender, EventArgs e)
        {
            ReloadPrn(Good_Id);
        }

        private void PrnBtn_Click(object sender, EventArgs e)
        {
            Color[] Cl = { Color.Red, Color.Yellow, Color.Green, Color.Aqua, Color.Teal, Color.Blue, Color.Navy, Color.Black, Color.Gray, Color.Silver, Color.White, Color.Fuchsia, Color.Purple, Color.Maroon, Color.Olive, Color.Lime};
            //if (GraphBox.SelectedIndex == 0)
            chart1.Titles[0].Text = "График покупок";
            //else
            //    chart1.Titles[0].Text = "График продаж (шт.)";
            chart1.Titles[0].Font = new Font("Arial", 16, FontStyle.Bold);
            //chart1.Series[0].ChartType = SeriesChartType.Pie;

            conn = new SqlConnection(connectionString);
            conn.Open();

            //ReloadPrn(Good_Id);

            string sqlExpression = "select C.FName, ID.Client_ID,sum(IG.count) as Count ,sum(IG.count * IG.Price) as Sum " +
                "from Input_Goods IG,goods G, Input_Doc ID,Clients C " +
                "where g.id = ig.GoodsID and ID.id = IG.Input_Doc_ID " +
                "and g.id = @goodsid and C.id = ID.Client_ID " +
                "group by ID.Client_ID,C.FName";

            using (conn)
            {
                SqlCommand cmd = new SqlCommand(sqlExpression, conn);
                // создаем параметр для возраста
                SqlParameter goods_idParam = new SqlParameter("@goodsid", Good_Id);
                // добавляем параметр к команде
                cmd.Parameters.Add(goods_idParam);

                SqlDataReader reader = cmd.ExecuteReader();

                int x = 1;
                int y;
                int el;
                
                decimal s;
                int k = reader.FieldCount;
                chart1.Series[0].Points.Clear();

                //  chart1.ChartAreas[0].AxisY.IsLabelAutoFit = false;
                //chart1.Series[0].YValueMembers = "Name";


                if (reader.HasRows)
                {
                    string l="",f;
                    //Legend Legend1 = new Legend();
                    //Legend1.Enabled = false;
                    //chart1.Legends.Add(Legend1);
                    // Assign the legend to Series1.
                    //chart1.Series["Series1"].Legend = "Legend1";
                    
                    //chart1.Series["Series1"].LegendText = "111";

                    //chart1.Series[0].YValueMembers = "Name1";
                    //chart1.Series[0].XValueMember = "Name2";
                    //chart1.Series["Series1"].IsVisibleInLegend = true;

                    while (reader.Read())
                    {
                        y = reader.GetInt32(2);
                        s= reader.GetDecimal(3);
                        /*if (l != "") l = l+"\n";
                        l = l + reader.GetString(0) + ":\t " + y.ToString() + "шт.," + " (" + Math.Round(s, 2).ToString() + " р.)";*/
                        chart1.Series[0].Points.Add(
                            new DataPoint(x++, y)
                            {
                                //LegendText = reader.GetString(0) + "=" + y.ToString(), // лучше $"{reader.GetString(1)}={y}"
                                AxisLabel = reader.GetString(0),
                                Label = y.ToString()+ " шт. (" + Math.Round(s,2).ToString()+" р.)"
                            }
                        ) ;
                        chart1.Series[0].Points[x / 2 - 1].Color = Cl[x / 2 - 1];




                        //chart1.Series["Series1"].LegendText = l;
                        /*                chart1.Series[0].Points.AddXY(x, y);

                                        l = reader.GetString(0) + "=" + y.ToString() + " р.";
                                        f = chart1.Series[0].Points[x - 1].LegendText;
                                        chart1.Series[0].Points[x - 1].LegendText = l;*/

                        //chart1.Series[0].IsVisibleInLegend = true;
                        //chart1.Series[0].IsValueShownAsLabel = true;

                        // chart1.Series[0].Points.DataBindXY((double)x);

                        //chart1.Series[0].Points.AddXY(x, y);
                        //chart1.Series[0].Points[((int)x - 1)].AxisLabel = reader.GetString(0);

                        //S.Points.AddXY(x, y);
                        //chart1.Series.Add(S);
                        //chart1.Series[0].Points[((int)x - 1)].LegendText = reader.GetString(0) + "=" + y.ToString();
                        //chart1.Series[0].Points[((int)x - 1)].AxisLabel = reader.GetString(0);
                        x++;
                    }
                }
            }
            PrintPreviewDialog ppd = new PrintPreviewDialog();
            ppd.Document = this.chart1.Printing.PrintDocument;
            ppd.ShowDialog();
        }

        private void GoodsMoveDataGridView_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            Set_ColumnHeader();
        }
    }
}
