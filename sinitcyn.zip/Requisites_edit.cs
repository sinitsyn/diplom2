﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class RequisitesEditForm : Form
    {
        //операция
        private int op;
        private int id = -1;
        private string RName = "";
        private string Address = "";
        private string Phone = "";
        DataSet dataSet;


        public RequisitesEditForm(int cmd, int IdVal = -1, string FNameVal = "", string AddressVal = "", string PhoneVal = "")
        {

            op = cmd;
            dataSet = CreateDataSet();
            InitializeComponent();
            NameTB.Text = FNameVal;
            AddressTB.Text = AddressVal;
            PhoneTB.Text = PhoneVal;
            if (IdVal > 0) id = IdVal;


            /*string commandText = "select * from dbo.Requisites;";
            id = 1;
            using (SqlConnection conn = new
                   SqlConnection(main.connectionString))
            {
                conn.Close();
                conn.Open();
                //MessageBox.Show("Успешное подключение !");
                //using (SqlConnection connection = new SqlConnection(main.connectionString))
                /*using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    dataSet = CreateDataSet();
                    adapter.Fill(dataSet, "Requisites");
                    if (dataSet.Tables.Count > 0) NameTB.Text = dataSet.
                }*/

                /*SqlCommand command = new SqlCommand(commandText, conn);
                command.Parameters.Add("@NAME", SqlDbType.VarChar);
                command.Parameters["@NAME"].Value = NameTB.Text;
                command.Parameters.Add("@Address", SqlDbType.VarChar);
                command.Parameters["@Address"].Value = AddressTB.Text;
                command.Parameters.Add("@Phone", SqlDbType.VarChar);
                try
                {
                    //connection.Open();
                    // Объекты‐адаптеры умеют взаимодействовать  
                    // с конкретными серверами баз данных  
                    adapter.TableMappings.Add("Table", "dbo.Clients");
                    adapter.SelectCommand = cmd;
                    DataSet dataSet = new DataSet("dbo.Clients");
                    // Поместить все строки в набор данных  
                    adapter.Fill(dataSet);
                    return dataSet; 
                    CreateDataSet()
                    if (command.)
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }*/


        }

        private DataSet CreateDataSet(string newSql = "")
        {
            string connectionString = main.connectionString;
            using (SqlConnection conn = new
                   SqlConnection(connectionString))
            {
                conn.Close();

                conn.Open();
                //MessageBox.Show("Успешное подключение !");
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM dbo.Requisites WHERE ID=ID " + newSql, conn))
                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    // Объекты‐адаптеры умеют взаимодействовать  
                    // с конкретными серверами баз данных  
                    adapter.TableMappings.Add("Table", "dbo.Requisites");
                    adapter.SelectCommand = cmd;
                    DataSet dataSet = new DataSet("dbo.Requisites");
                    // Поместить все строки в набор данных  
                    adapter.Fill(dataSet);
                    return dataSet;
                }

            }
        }

        private void OKbtn_Click(object sender, EventArgs e)
        {
            string connectionString = main.connectionString;
            string commandText;
            //MessageBox.Show(NameTB.Text);
            switch (op) //операция
            {
                case 1: //добавление новой записи
                    commandText = "INSERT INTO dbo.Requisites (Name,Address,Phone) VALUES (@Name,@Address,@Phone);";

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand command = new SqlCommand(commandText, connection);
                        command.Parameters.Add("@NAME", SqlDbType.VarChar);
                        command.Parameters["@NAME"].Value = NameTB.Text;
                        command.Parameters.Add("@Address", SqlDbType.VarChar);
                        command.Parameters["@Address"].Value = AddressTB.Text;
                        command.Parameters.Add("@Phone", SqlDbType.VarChar);
                        command.Parameters["@Phone"].Value = PhoneTB.Text;
                        try
                        {
                            connection.Open();
                            Int32 rowsAffected = command.ExecuteNonQuery();
                            MessageBox.Show(rowsAffected.ToString() + " rows affected by insert");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }
                break;
                case 2:
                    commandText = "UPDATE dbo.Requisites set Name=@Name," +
                                "Address=@Address," +
                                "Phone=@Phone where ID=@ID";                                ;

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        SqlCommand command = new SqlCommand(commandText, connection);
                        command.Parameters.Add("@ID", SqlDbType.VarChar);
                        command.Parameters["@ID"].Value = id;

                        command.Parameters.Add("@NAME", SqlDbType.VarChar);
                        command.Parameters["@NAME"].Value = NameTB.Text;

                        command.Parameters.Add("@Address", SqlDbType.VarChar);
                        command.Parameters["@Address"].Value = AddressTB.Text;

                        command.Parameters.Add("@Phone", SqlDbType.VarChar);
                        command.Parameters["@Phone"].Value = PhoneTB.Text;

                        try
                        {
                            connection.Open();
                            Int32 rowsAffected = command.ExecuteNonQuery();
                            MessageBox.Show(rowsAffected.ToString() + " rows affected by update");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }

                    break;
                case 3: //удаление

                    using (SqlConnection conn = new
                           SqlConnection(connectionString))
                    {

                    }
                    break;

                default:
                    break;
            }

            this.Close();
            this.Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(FNameTBox.Text);
        }

        private void RequisitesEditForm_Load(object sender, EventArgs e)
        {
            /*NameTB.Text = RName;
            AddressTB.Text = Address;
            PhoneTB.Text = Phone;*/
        }
    }
}
