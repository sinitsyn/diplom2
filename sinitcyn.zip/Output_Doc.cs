﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WinFormsApp1
{
    public partial class Output_Doc : Form
    {
        private int op;
        private SqlConnection sqlConnection = null;
        private SqlDataAdapter SqlDataAdapter = null;
        private SqlCommandBuilder SqlCommandBuilder = null;
        private SqlTransaction t;

        string filter;
        DataSet dataSet;
        
        public Output_Doc(int op_cmd)
        {
            op = op_cmd;
            dataSet = CreateDataSet();
            InitializeComponent();
            ODocGridView.DataSource = dataSet.Tables["dbo.Output_Doc"];
            LoadData();
            ODocGridView.Focus();
        }

        private DataSet CreateDataSet(string newSql = "")
        {
            string connectionString = main.connectionString;
            using (SqlConnection conn = new
                   SqlConnection(connectionString))
            {
                conn.Close();

                conn.Open();
                //MessageBox.Show("Успешное подключение !");
                using (SqlCommand cmd = new SqlCommand("SELECT O_D.*,C.FName,C.ID as C_ID FROM dbo.Output_Doc O_D,CLIENTS C WHERE O_D.Client_ID=C.ID " + newSql, conn))
                using (SqlDataAdapter adapter = new SqlDataAdapter())
                {
                    // Объекты‐адаптеры умеют взаимодействовать  
                    // с конкретными серверами баз данных  
                    adapter.TableMappings.Add("Table", "dbo.Output_Doc");
                    adapter.SelectCommand = cmd;
                    DataSet dataSet = new DataSet("dbo.Output_Doc");
                    // Поместить все строки в набор данных  
                    adapter.Fill(dataSet);
                    return dataSet;
                }

            }
        }

        private void LoadData()
        {
            if (op==0)
            {

            }
        }

        private void RecalcSaldo()
        {
            string sqlExpression = "update GOODS set Balance=((select COALESCE(sum(count),0) from Input_Goods IG where IG.Goods_ID=GOODS.ID)-(select COALESCE(sum(count),0) from Output_Goods OG where OG.Goods_ID=GOODS.ID))";
            string connectionString = main.connectionString;
            SqlConnection conn = new SqlConnection(main.connectionString);
            conn.Open();

            try
            {
                SqlCommand command = new SqlCommand(sqlExpression, conn);
                command.Transaction = t;
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void GridR(int cmd)
        {
            string w = "";
            int r = 0;
            if (dataSet.Tables[0].Rows.Count > 0)
                r = ODocGridView.CurrentCell.RowIndex;
            // if (dataSet.Tables[0].Rows.Count > 0) r = ODocGridView.CurrentCell.RowIndex;
            /*ODocGridView.DataSource = null;
            dataSet = CreateDataSet(" " + w); //установка фильтра
            ODocGridView.DataSource = dataSet.Tables["dbo.Output_Doc"];*/
            //ODocGridView.CurrentCell = ODocGridView.Rows[r].Cells[0];
            dataSet = null;
            //IDocGridView.DataSource = null;
            dataSet = CreateDataSet(" " + w); //переоткрытие
            ODocGridView.DataSource = dataSet.Tables["dbo.Output_Doc"];
            switch (cmd)
            {
                case 1:
                    if (ODocGridView.Rows.Count>0) ODocGridView.CurrentCell = ODocGridView.Rows[ODocGridView.RowCount - 1].Cells[1]; //добавление
                    break;
                case 2:
                    if (ODocGridView.Rows.Count > 0) ODocGridView.CurrentCell = ODocGridView.Rows[r].Cells[1];//редактирование
                    break;
                case 3:
                    if (ODocGridView.Rows.Count > 0) ODocGridView.CurrentCell = ODocGridView.Rows[r - 1].Cells[1];//удаление
                    break;
                default:
                    break;
            }

            //Set_ColumnHeader();
        }

        private void Set_ColumnHeader()
        {
            /*переименовывание*/
            /*скрытие*/
            ODocGridView.Focus();
            ODocGridView.Columns["Bill_Num"].DisplayIndex = 0;
            ODocGridView.Columns["Bill_Num"].HeaderText = "Номер";
            ODocGridView.Columns["Data"].DisplayIndex = 1;
            ODocGridView.Columns["Data"].HeaderText = "Дата";
            ODocGridView.Columns["FNAME"].DisplayIndex = 2;
            ODocGridView.Columns["FNAME"].HeaderText = "Клиент";
            ODocGridView.Columns["Sum"].DisplayIndex = 3;
            ODocGridView.Columns["Sum"].HeaderText = "Сумма";
            ODocGridView.Columns["Sum"].CellTemplate.Style.Format = "N2";
            ODocGridView.Columns["VAT"].DisplayIndex = 4;
            ODocGridView.Columns["VAT"].HeaderText = "В.т.ч. НДС";
            ODocGridView.Columns["VAT"].CellTemplate.Style.Format = "N2";
            //ODocGridView.Columns["ID"].DisplayIndex = ODocGridView.Columns.Count - 1;
            //ODocGridView.Columns["Client_ID"].DisplayIndex = ODocGridView.Columns.Count - 1;
            //ODocGridView.Columns["C_ID"].DisplayIndex = ODocGridView.Columns.Count - 1;
            ODocGridView.Columns["ID"].Visible = false;
            ODocGridView.Columns["Client_ID"].Visible = false;
            ODocGridView.Columns["C_ID"].Visible = false;
        }



            private void NewBtn_Click(object sender, EventArgs e)
        {
            Output_Doc_Ed O_D_E = new Output_Doc_Ed(0);
            O_D_E.ShowDialog();
            GridR(1);
        }

        private void EditBtn_Click(object sender, EventArgs e)
        {
            ODocGridView.Focus();
            //int id = Convert.ToInt32(ODocGridView.CurrentRow.Cells["ID"].Value.ToString());
            int id = Convert.ToInt32(dataSet.Tables[0].Rows[ODocGridView.CurrentRow.Index]["ID"].ToString());
            Output_Doc_Ed O_D_E = new Output_Doc_Ed(1, id);
            O_D_E.ShowDialog();
            GridR(2);
            //Set_ColumnHeader();
            ODocGridView.Focus();
        }

        private void DelBtn_Click(object sender, EventArgs e)
        {
            /*//int Id = Convert.ToInt32(ODocGridView.CurrentRow.Cells["ID"].Value);
            int Id = Convert.ToInt32(dataSet.Tables[0].Rows[ODocGridView.CurrentRow.Index]["ID"].ToString());
            string connectionString = main.connectionString;
            try
            {
                using (SqlConnection conn = new
                   SqlConnection(main.connectionString))
                {
                    conn.Open();
                    t = conn.BeginTransaction(); //начало транзакции
                    string sqlExpression = "DELETE FROM dbo.Output_GOODS where OUTPUT_DOC_ID = @ID";
              
                    sqlExpression = "DELETE FROM dbo.Output_Doc where ID = @ID";
                    SqlCommand command2 = new SqlCommand(sqlExpression, conn);
                    command2.Transaction = t;
                    // создаем параметр для имени
                    SqlParameter idParam = new SqlParameter("@ID", Id);
                    // добавляем параметр к команде
                    command2.Parameters.Add(idParam);
                    command2.ExecuteNonQuery();
                    t.Commit(); //подтверждение транзакции
                    //RecalcSaldo();
                    GridR(3);
                }
            }


            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }*/
            string sqlExpression;
            try
            {
                int Doc_Id = Convert.ToInt32(dataSet.Tables[0].Rows[ODocGridView.CurrentRow.Index]["ID"].ToString());
                string connectionString = main.connectionString;
                string sql = "SELECT * FROM dbo.Output_Goods where Output_Doc_Id=" + Doc_Id.ToString();
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    // Создаем объект DataAdapter
                    SqlDataAdapter adapter = new SqlDataAdapter(sql, connection);
                    // Создаем объект Dataset
                    DataSet ds = new DataSet();
                    // Заполняем Dataset
                    adapter.Fill(ds);
                    // Отображаем данные
                    //IDocGridView.DataSource = ds.Tables[0];

                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        string row_id = ds.Tables[0].Rows[i]["ID"].ToString();
                        string goods_id = ds.Tables[0].Rows[i]["GOODS_ID"].ToString();
                        //MessageBox.Show(d[0].ToString());
                        SqlCommand cmd1 = new SqlCommand("DELETE FROM OUTPUT_GOODS WHERE ID=" + row_id);
                        cmd1.Transaction = t;
                        cmd1.Connection = connection;
                        int rowsAffected = cmd1.ExecuteNonQuery();
                        MessageBox.Show(rowsAffected.ToString() + " rows affected by delete");
                        sqlExpression = "EXEC RECALC_STOCK " + goods_id.ToString();
                        SqlCommand command = new SqlCommand(sqlExpression, connection);
                        command.Transaction = t;
                        rowsAffected = command.ExecuteNonQuery();
                        MessageBox.Show(rowsAffected.ToString() + " rows affected by delete");
                    }

                    sqlExpression = "DELETE FROM dbo.Output_DOC where ID = @ID";
                    SqlCommand command2 = new SqlCommand(sqlExpression, connection);
                    command2.Transaction = t; //команда в транзакцию
                                              // создаем параметр для id документа
                    SqlParameter id_doc_idParam = new SqlParameter("@ID", Doc_Id);
                    // добавляем параметр к команде
                    command2.Parameters.Add(id_doc_idParam);
                    command2.ExecuteNonQuery();


                }

                GridR(2);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void PrintBtn_Click(object sender, EventArgs e)
        {

        }

        
        private void ODocGridView_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            Set_ColumnHeader();
        }
    }
}
