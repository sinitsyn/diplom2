﻿using System;

namespace TestLib
{
    public class SquareCalc
    {
        public double Square(int cmd = -1, int a = 0, int b = 0, int c = 0)
        {
            double p;
            double S; //площадь
            string R;
            const double M_PI = 3.14159265358979323846; //пи

            switch (cmd) { //команды задания
                case 0:
                    S = M_PI * a * a; //площадь круга
                    break;
                case 1:
                    p = ((a + b + c) / 2.0);
                    S = S = Math.Sqrt(p * (p - a)*(p - b)*(p - c)); //площадь треугольника
                    break;
                //легко добавить новые команды и формулы для других фигур
                default:
                    S = 0; //остальные команды
                    break;
            }
            return S;
        }
        public void Print(string St) => Console.WriteLine(St);
    }
}
